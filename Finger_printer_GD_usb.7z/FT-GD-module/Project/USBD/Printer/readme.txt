/*!
    \file  readme.txt
    \brief description of the USB device printer example
*/

/*
    Copyright (C) 2017 GigaDevice

    2017-02-10, V1.0.0, firmware for GD32F30x
*/

  The demo provide a printer device.

  To test the demo, you can run printer demo,then you check it from device manager.