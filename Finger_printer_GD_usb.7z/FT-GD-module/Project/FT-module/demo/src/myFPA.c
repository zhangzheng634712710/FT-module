#ifndef MYFPA_C_
#define MYFPA_C_

#include "myFPA.h"
#include "stdlib.h"
#include "math.h"

//7*7分成8个方向，坐标在左上
const signed char  g_D_778[8][7][2] = {
	-3, 0,  -2, 0,  -1, 0,   0, 0,   1, 0,   2, 0,   3, 0,  //0 度
	-3, 2,  -2, 1,  -1, 1,   0, 0,   1,-1,   2,-1,   3,-2,	//22.5
	-3, 3,  -2, 2,  -1, 1,   0, 0,   1,-1,   2,-2,   3,-3,	//45
	-2, 3,  -1, 2,  -1, 1,   0, 0,   1,-1,   1,-2,   2,-3,  //67.5
	 0, 3,   0, 2,   0, 1,   0, 0,   0,-1,   0,-2,   0,-3,	//90
	-2,-3,  -1,-2,  -1,-1,   0, 0,   1, 1,   1, 2,   2, 3,  //112.5
	-3,-3,  -2,-2,  -1,-1,   0, 0,   1, 1,   2, 2,   3, 3,  //135
	-3,-2,  -2,-1,  -1,-1,   0, 0,   1, 1,   2, 1,   3, 2,  //157.5
}; 

//判断图片质量,同时返回图片的信息
void myImageQuality(unsigned char* image, unsigned char *reVal)
{

	unsigned short i = 0, j = 0, k = 0, n = 0;

	unsigned char* lpSrc = NULL;
	
	unsigned short countMax = 0, grayMax = 0;
	
	unsigned int   lCount[256] = { 0 };           //灰度直方图
	
	unsigned char nblk = 4;
	
	unsigned int mean[8] = { 0 };                //存储7*7矩阵中八条线的灰度平均值
	unsigned int var[8]  = { 0 };                //存储7*7矩阵中八条线的灰度方差 
	
	unsigned int varmax = 0, varmin = 0, meanmax = 0, meanmin = 0;
	unsigned int cnt = 0;
	unsigned int varRange = 0, RangeCnt = 0;
	unsigned int count = 0;
	unsigned int AreaRatio = 0;
	
	for (j = 0; j < G_HEIGHT; j = j + nblk)
	{
		for (i = 0; i < G_WIDTH; i = i + nblk)
		{
			lpSrc = image + (j + 2)*G_WIDTH + i + 2;
			for (k = 0; k < 8; k++)
			{
				mean[k] = 0;
				var[k] = 0;
				cnt = 0;
				for (n = 0; n < 7; n++)                                                                              
				{
					if (j + 2 + g_D_778[k][n][1] >= 0 && j + 2 + g_D_778[k][n][1] < G_HEIGHT
						&& i + 2 + g_D_778[k][n][0] >= 0 && i + 2 + g_D_778[k][n][0] < G_WIDTH)
					{
						mean[k] = mean[k] + *(lpSrc + g_D_778[k][n][1] * G_WIDTH + g_D_778[k][n][0]);
						cnt++;
					}
				}
				mean[k] = mean[k] / cnt;                                                                       //求像素点在7x7的矩阵内的八个方向上各自的均值 （注意起始点的位置）

				cnt = 0;
				for (n = 0; n < 7; n++)
				{
					if (j + 2 + g_D_778[k][n][1] >= 0 && j + 2 + g_D_778[k][n][1] < G_HEIGHT
						&& i + 2 + g_D_778[k][n][0] >= 0 && i + 2 + g_D_778[k][n][0] < G_WIDTH)
					{
						var[k] = var[k] + (*(lpSrc + g_D_778[k][n][1] * G_WIDTH + g_D_778[k][n][0]) - mean[k])*(*(lpSrc + g_D_778[k][n][1] * G_WIDTH + g_D_778[k][n][0]) - mean[k]);
						cnt++;
					}
				}
				var[k] = var[k] / cnt;                                                                         //求像素点在7x7的矩阵内的八个方向上各自的方差 （注意起始点的位置）
			}

			varmax = var[0];
			varmin = var[0];
			meanmax = mean[0]; 
			meanmin = mean[0];
			for (k = 1; k < 8; k++)
			{
				if (var[k] > varmax)
					varmax = var[k];
				if (var[k] < varmin)
					varmin = var[k];
				if (mean[k] > meanmax)
					meanmax = mean[k];
				if (mean[k] < meanmin)
					meanmin = mean[k];
			}                                                                                                  //求像素点在7x7的矩阵内的八个方向上最大及最小的均值和方差 （注意起始点的位置）
						
			if (meanmax < 252 || varmax - varmin > 2)
			{
				varRange = varRange + varmax - varmin;
				RangeCnt++;
				for (k = 0; k < nblk; k++)
				{
					for (n = 0; n < nblk; n++)
					{
						if (j + k >= 0 && j + k < G_HEIGHT && i + n >= 0 && i + n < G_WIDTH)
							count++;
					}
				}
			}
		}		
	}

	AreaRatio = count * 100 / TOTAL_LENGTH;                                                                   //求面积比
	varRange = varRange / RangeCnt;                                                                           //求所有点最大方差和最小方差的平均值
	
	for (j = 0; j < G_HEIGHT; j++)
	{
		for (i = 0; i < G_WIDTH; i++)
		{
				lpSrc = image + j * G_WIDTH + i;
				lCount[*(lpSrc)]++;
		}
	}                                                                                                        //求mask之后的图像的直方图lCount[256]

	for (i = 0; i < 255; i++)
	{
		if (countMax < lCount[i])
		{
			countMax = lCount[i];
			grayMax = i;
		}
	}                                                                                                        //求直方图中点数最多的灰度值

	reVal[2] = AreaRatio;  //面积比例
	reVal[3] = grayMax;    //hist最大的灰度，判断干湿手指
	reVal[4] = varRange;   //方向场方差范围，清晰程度

	if (AreaRatio < AreaTH)
	{
		reVal[0] = 0xff;
		reVal[1] = 201; // 面积过小
	}
	if (varRange < DirVarTh)
	{
		reVal[0] = 0xff;
		reVal[1] = 204; // 图像模糊
		return;
	}
	reVal[0] = 0x01;
	return;
}

 //归一化到指定的均值方差范围内
//输入参数：
//	输入图像 unsigned char* lpDIBBits
//输出参数：
//	输出图像 unsigned char* lpDataOut  归一化图像数据
//备注:
void myImageNormalize(unsigned char *lpDIBBits, unsigned char *lpDataOut)
{
	// 指向源图像的指针
	unsigned char *lpSrc = NULL;
	unsigned char *lpRst = NULL;

	// 临时变量
	unsigned short i = 0, j = 0;
	
	unsigned char orgMean = 0;
	unsigned int    val = 0;
	
	unsigned int coeff = 0;

	// 灰度映射表
	unsigned short lCount[256] = { 0 };

	// 图像每行的字节数
	unsigned short	lLineBytes = G_WIDTH;

	// 图像归一后的均值和方差
	unsigned char destMean = 128;                                        //输出图像每一个pixel为8个bit，灰度范围为0到255，要将图像的均值归一到中值128，
	unsigned int  destVar = 10000;                                       //方差归一到10000（经验值）

	// 重置计数为0
	for (i = 0; i < 256; i++) 
		lCount[i] = 0;

	// 计算各个灰度值的计数
	for (i = 0; i < G_HEIGHT; i++)
	{
		for (j = 0; j < G_WIDTH; j++)
		{
			lpSrc = (unsigned char *)lpDIBBits + lLineBytes * i + j;
			lCount[*(lpSrc)]++;
		}
	}                                                                    //求直方图lCount[256]

	val = 0;
	// 当前图像均值orgMean
	for (i = 1; i<255; i++)
	{
		val += i * lCount[i];
	}
	
	val = val / (G_HEIGHT*G_WIDTH);
	orgMean = (unsigned char)val;                                                               //求图像均值

	// 当前图像标准差orgSigma
	val = 0;
	for (i = 0; i<255; i++)
	{
		val += lCount[i] * (i - orgMean)*(i - orgMean);
	}
	val = val / (G_HEIGHT*G_WIDTH);                                                             //求图像的方差                                                                         

	coeff = (int)sqrt(destVar / val);                                                           //为什么要用(destVar / val)？  //将图像扩展到方差为destVar的范围

	for (i = 0; i<G_HEIGHT; i++)
	{
		for (j = 0; j<G_WIDTH; j++)
		{
			lpSrc = (unsigned char *)lpDIBBits + lLineBytes * i + j;
			lpRst = (unsigned char *)lpDataOut + lLineBytes * i + j;
			*lpRst = destMean + coeff * ((*lpSrc) - orgMean);                                     //扩大图像的细节？在destMean上下浮动？
		}
	}
	return;
#if 0 //统计时间

#endif
}

 
/*均值滤波 逐点均衡化 得到高频信息图*/
//输入参数：
//	输入图像   unsigned char *guiyihuaBmp 归一化图像数据
//  滤波器大小 unsigned int varfilter
//输出参数：
//	输出图像   unsigned char *pOutput  均衡化图像数据
signed char mySmoothFilter(unsigned char *guiyihuaBmp, unsigned char *pOutput, unsigned int varfilter)
{
	unsigned int i = 0;
	unsigned int j = 0;
	int tpnum = 0;
	int s = 0;
	unsigned int subcript = 0; /*数组下标*/

	int min_value = 0;
	int tsize = 5;
	int block = 0;
	int value_num = 0;
	int leftx = 0;
	int rightx = 0;
	int upy = 0;
	int downy = 0;
	int tempaver = 0;
	int historam_num = 0;
	int ii = 0;
	int jj = 0;

	int *x1 = NULL;
	int *x2 = NULL;
	int *BoxImage = NULL;
	int *BoxImage1 = NULL;
	int *Bmp_temp = NULL; 

	unsigned char *pOutputTemp = NULL;
	unsigned char Output = 0;

	x1 = (int*)malloc((G_HEIGHT + 8)*(G_WIDTH + 8) * sizeof(int));
	if (x1 == NULL)
	{
		return ;
	}
	
	x2 = (int*)malloc((G_HEIGHT + 4)*(G_WIDTH + 4) * sizeof(int));
	if (x2 == NULL)
	{
		if (x1 != NULL) free(x1); x1 = NULL;
		return ;
	}

	Bmp_temp = (int*)malloc(TOTAL_LENGTH * sizeof(int));
	if (Bmp_temp == NULL)
	{
		if (x1 != NULL) free(x1); x1 = NULL;
		if (x2 != NULL) free(x2); x2 = NULL;
		return ;
	}

	BoxImage = (int*)malloc((G_HEIGHT + 8)*(G_WIDTH + 8) * sizeof(int));
	if (BoxImage == NULL)
	{
		if (x1 != NULL) free(x1); x1 = NULL;
		if (x2 != NULL) free(x2); x2 = NULL;
		if (Bmp_temp != NULL) free(Bmp_temp); Bmp_temp = NULL;
		return ;
	}
	memset(BoxImage, 0, (G_HEIGHT + 8)*(G_WIDTH + 8) * sizeof(int));

	BoxImage1 = (int*)malloc((G_HEIGHT + 4)*(G_WIDTH + 4) * sizeof(int));
	if (BoxImage1 == NULL)
	{
		if (x1 != NULL) free(x1); x1 = NULL;
		if (x2 != NULL) free(x2); x2 = NULL;
		if (Bmp_temp != NULL) free(Bmp_temp); Bmp_temp = NULL;
		if (BoxImage != NULL) free(BoxImage); BoxImage = NULL;
		return ;
	}
	memset(BoxImage1, 0, (G_HEIGHT + 4)*(G_WIDTH + 4) * sizeof(int));
 
	for (i = 0; i < G_HEIGHT; i++)
	{
		for (j = 0; j < G_WIDTH; j++)
		{
			subcript = i * G_WIDTH + j;
			x1[(i + 4)*(G_WIDTH + 8) + j + 4] = guiyihuaBmp[subcript];
		}
	}                                                                                    //复制原始的图像数据至buffer X1的中间

	for (j = 0; j < G_WIDTH; j++)
	{
		subcript = (G_HEIGHT - 1)*G_WIDTH + j;                                           
		x1[j + 4] = guiyihuaBmp[j];
		x1[1 * (G_WIDTH + 8) + j + 4] = guiyihuaBmp[j];
		x1[2 * (G_WIDTH + 8) + j + 4] = guiyihuaBmp[j];
		x1[3 * (G_WIDTH + 8) + j + 4] = guiyihuaBmp[j];
		x1[(G_HEIGHT + 4) * (G_WIDTH + 8) + j + 4] = guiyihuaBmp[subcript];
		x1[(G_HEIGHT + 5) * (G_WIDTH + 8) + j + 4] = guiyihuaBmp[subcript];
		x1[(G_HEIGHT + 6) * (G_WIDTH + 8) + j + 4] = guiyihuaBmp[subcript];
		x1[(G_HEIGHT + 7) * (G_WIDTH + 8) + j + 4] = guiyihuaBmp[subcript];
	}
	for (i = 0; i < (G_HEIGHT + 8); i++)
	{
		subcript = i * (G_WIDTH + 8) + 4;
		x1[i * (G_WIDTH + 8) + 0] = x1[subcript];
		x1[i * (G_WIDTH + 8) + 1] = x1[subcript];
		x1[i * (G_WIDTH + 8) + 2] = x1[subcript];
		x1[i * (G_WIDTH + 8) + 3] = x1[subcript];

		subcript = i * (G_WIDTH + 8) + G_WIDTH + 3;
		x1[i * (G_WIDTH + 8) + G_WIDTH + 4] = x1[subcript];
		x1[i * (G_WIDTH + 8) + G_WIDTH + 5] = x1[subcript];
		x1[i * (G_WIDTH + 8) + G_WIDTH + 6] = x1[subcript];
		x1[i * (G_WIDTH + 8) + G_WIDTH + 7] = x1[subcript];
	}                                                                                    //用原始图像边缘的值填充周边空出来的区域，补齐X1
	
	//优化后的积分图
	BoxImage[0] = x1[0];
	for (j = 1; j < G_WIDTH + 8; j++)
	{
		BoxImage[j] = BoxImage[j-1] + x1[j];
	}
	for (i = 1; i < G_HEIGHT +  8; i++)
	{
		int nSum = 0;
		for ( j = 0; j <G_WIDTH + 8; j++)
		{
			nSum += x1[i*(G_WIDTH + 8)+j];
			BoxImage[i*(G_WIDTH + 8)+j] = BoxImage[(i-1)*(G_WIDTH + 8)+j] + nSum;
		}
	}                                                                                    //计算X1的积分矩阵BoxImage

	tpnum = 81;                                                                                                                                //为什么是81？
	s = BoxImage[(varfilter - 1) * (G_WIDTH + 8) + varfilter - 1];
	Bmp_temp[0] = (s + (tpnum >> 1)) / tpnum;

	for (i = 1; i < G_HEIGHT; i++) /*第一列差分*/
	{
		s = BoxImage[(i + varfilter - 1) * (G_WIDTH + 8) + varfilter - 1] - BoxImage[(i - 1) * (G_WIDTH + 8) + varfilter - 1];
		Bmp_temp[i * G_WIDTH] = (s + (tpnum >> 1)) / tpnum;
	}

	for (j = 1; j < G_WIDTH; j++)/*第一行差分*/
	{
		s = BoxImage[(varfilter - 1) * (G_WIDTH + 8) + j + varfilter - 1] - BoxImage[(varfilter - 1) * (G_WIDTH + 8) + j - 1];
		Bmp_temp[j] = (s + (tpnum >> 1)) / tpnum;
	}

	for (i = 1; i < G_HEIGHT; i++) /*差分图*/
	{
		for (j = 1; j < G_WIDTH; j++)
		{
			s = BoxImage[(i + varfilter - 1) * (G_WIDTH + 8) + j + varfilter - 1] - BoxImage[(i - 1) * (G_WIDTH + 8) + j + varfilter - 1]
				- BoxImage[(i + varfilter - 1) * (G_WIDTH + 8) + j - 1] + BoxImage[(i - 1) * (G_WIDTH + 8) + j - 1];
			Bmp_temp[i * G_WIDTH + j] = (s + (tpnum >> 1)) / tpnum;
		}
	}

	/*均值平滑 均值滤波的结果*/
	for (i = 0; i < G_HEIGHT; i++)
	{
		for (j = 0; j < G_WIDTH; j++)
		{
			x2[(i + 2) * (G_WIDTH + 4) + j + 2] = Bmp_temp[i * G_WIDTH + j];
		}
	}

	for (j = 0; j < G_WIDTH; j++)
	{
		x2[j + 2] = Bmp_temp[j];
		x2[1 * (G_WIDTH + 4) + j + 2] = Bmp_temp[j];
		subcript = (G_HEIGHT - 1) * G_WIDTH + j;
		x2[(G_HEIGHT + 2) * (G_WIDTH + 4) + j + 2] = Bmp_temp[subcript];
		x2[(G_HEIGHT + 3) * (G_WIDTH + 4) + j + 2] = Bmp_temp[subcript];
	}

	for (i = 0; i < (G_HEIGHT + 4); i++)
	{
		subcript = i * (G_WIDTH + 4) + 2;
		x2[i * (G_WIDTH + 4) + 0] = x2[subcript];
		x2[i * (G_WIDTH + 4) + 1] = x2[subcript];
		subcript = i * (G_WIDTH + 4) + G_WIDTH + 1;
		x2[i * (G_WIDTH + 4) + G_WIDTH + 2] = x2[subcript];
		x2[i * (G_WIDTH + 4) + G_WIDTH + 3] = x2[subcript];
	}



	//优化后的积分图
	BoxImage1[0] = x2[0];
	for (j = 1; j < G_WIDTH + 4; j++)
	{
		BoxImage1[j] = BoxImage1[j - 1] + x2[j];
	}
	for (i = 1; i < G_HEIGHT + 4; i++)
	{
		int nSum = 0;
		for (j = 0; j <G_WIDTH + 4; j++)
		{
			nSum += x2[i*(G_WIDTH + 4) + j];
			BoxImage1[i*(G_WIDTH + 4) + j] = BoxImage1[(i - 1)*(G_WIDTH + 4) + j] + nSum;
		}
	}

	tpnum = 25; 
	varfilter = 5; 
	s = BoxImage1[(varfilter - 1) * (G_WIDTH + 4) + varfilter - 1];
	Bmp_temp[0] = (s + (tpnum >> 1)) / tpnum;

	for (i = 1; i < G_HEIGHT; i++)
	{
		s = BoxImage1[(i + varfilter - 1) * (G_WIDTH + 4) + varfilter - 1] - BoxImage1[(i - 1) * (G_WIDTH + 4) + varfilter - 1];
		Bmp_temp[i * G_WIDTH] = (s + (tpnum >> 1)) / tpnum;
	}

	for (j = 1; j < G_WIDTH; j++)
	{
		s = BoxImage1[(varfilter - 1) * (G_WIDTH + 4) + j + varfilter - 1] - BoxImage1[(varfilter - 1) * (G_WIDTH + 4) + j - 1];
		Bmp_temp[j] = (s + (tpnum >> 1)) / tpnum;
	}

	for (i = 1; i < G_HEIGHT; i++)
	{
		for (j = 1; j < G_WIDTH; j++)
		{
			s = BoxImage1[(i + varfilter - 1) * (G_WIDTH + 4) + j + varfilter - 1] - BoxImage1[(i - 1) * (G_WIDTH + 4) + j + varfilter - 1]
				- BoxImage1[(i + varfilter - 1) * (G_WIDTH + 4) + j - 1] + BoxImage1[(i - 1) * (G_WIDTH + 4) + j - 1];
			Bmp_temp[i * G_WIDTH + j] = (s + (tpnum >> 1)) / tpnum;
		}
	}

	/*得到高频信息图*/
	min_value = 65535;

	for (i = 0; i < G_HEIGHT; i++)
	{
		for (j = 0; j < G_WIDTH; j++)
		{
			subcript = i * G_WIDTH + j;
			guiyihuaBmp[subcript] -= Bmp_temp[subcript];
			if (min_value >= guiyihuaBmp[subcript])
			{
				min_value = guiyihuaBmp[subcript];
			}
		}
	}                                                                  //用原图减去均衡之后的图，均值滤波相当于低通滤波，相减之后就剩下原图的高频部分
	/*数据调整到0以上*/
	for (i = 0; i < G_HEIGHT; i++)//高频信息图全部大于0
	{
		for (j = 0; j < G_WIDTH; j++)
		{
			subcript = i * G_WIDTH + j;
			guiyihuaBmp[subcript] -= min_value;
			Bmp_temp[subcript] = 0;
		}
	}                                                                  //所有的数据调整到0以上

	/*逐点均衡化*/
	tsize = 5;
	block = tsize * 2;
	value_num = (block + 1) * (block + 1);
	for (i = 0; i < G_HEIGHT; i++)
	{
		for (j = 0; j < G_WIDTH; j++)
		{
			leftx = j - tsize;
			rightx = j + tsize;
			upy = i - tsize;
			downy = i + tsize;
			if (leftx < 0)
			{
				leftx = 0;
				rightx = tsize * 2;
			}
			if (rightx >= G_WIDTH)
			{
				rightx = G_WIDTH - 1;
				leftx = G_WIDTH - 2 * tsize - 1;

			}
			if (upy < 0)
			{
				upy = 0;
				downy = tsize * 2;
			}
			if (downy >= G_HEIGHT)
			{
				downy = G_HEIGHT - 1;
				upy = G_HEIGHT - 1 - 2 * tsize;
			}                                                                               //移动11x11的方框至图像内部

			subcript = i * G_WIDTH + j;
			tempaver = guiyihuaBmp[subcript];
			historam_num = 0;
			for (ii = upy; ii <= downy; ii++)
			{
				for (jj = leftx; jj <= rightx; jj++)
				{
					if (guiyihuaBmp[ii * G_WIDTH + jj] <= tempaver)
					{
						historam_num++;
					}
				}
			}                                                                              //统计11x11的方框中比某像素点灰度值低的点的数量
			Bmp_temp[subcript] = (historam_num * 295 + (value_num >> 1)) / value_num;
			Bmp_temp[subcript] -= 5;
			if (Bmp_temp[subcript] > 255)
			{
				Bmp_temp[subcript] = 255;
			}
			if (Bmp_temp[subcript] < 0)
			{
				Bmp_temp[subcript] = 0;
			}
		}
	}
	for (i = 0; i < G_HEIGHT; i++)
	{
		for (j = 0; j < G_WIDTH; j++)
		{
			subcript = i * G_WIDTH + j;
			pOutput[subcript] = Bmp_temp[subcript];
		}
	}

	if (x1 != NULL) free(x1); x1 = NULL;
	if (x2 != NULL) free(x2); x2 = NULL;
	if (Bmp_temp != NULL) free(Bmp_temp); Bmp_temp = NULL;
	if (BoxImage != NULL) free(BoxImage); BoxImage = NULL;
	if (BoxImage1 != NULL) free(BoxImage1); BoxImage1 = NULL;

	return ;
}


//功能：图像前端处理 得到描述值和特征点个数、极小值个数
//输入参数：
//  图像数据       unsigned char* pImageBuf
//输出参数：
//	极小值个数     unsigned int *leastnum
//  描述值数组     signed short *describdata
//	描述值个数     unsigned int DescribNum
signed char myFingerPreProcess(unsigned char* pImageBuf,unsigned int *DescribNum,unsigned int *leastnum,signed short *describdata)
{
	/********  存储图像质量检测时得到的图像信息  ********/
	unsigned char reVal[6] = {0};	
	
	/**************  归一化之后的图像指针  **************/
	unsigned char *bmpdata = 0;	
	
  //第一步图像质量检测
	myImageQuality(pImageBuf, reVal);
	if (reVal[0] == 255)
	{
		return Image_quality_low;
	}
	
	//第二步图像归一化	
	bmpdata = (unsigned char *)malloc((G_HEIGHT+8)*(G_WIDTH+8));
	if(!bmpdata)
	{
		return Malloc_failed;
	}
	myImageNormalize(pImageBuf, bmpdata);	
	
	
	
	return Func_success;
}

//功能：指纹注册功能函数
signed char myFingerEnroll(unsigned char *pImageBuf, unsigned short fingerid)
{
	unsigned int interestnum = 0; 			//描述值个数
	unsigned int leastnum = 0;    			//极小值个数
	signed short *intrestpoint = NULL; 	//描述子
	
	signed char outcome = 0;

	intrestpoint = (signed short *)malloc((MAX_MINUTIAE *COLMNUM) * sizeof(signed short));  //
	if (intrestpoint == NULL)
	{
		return Malloc_failed;
	}

	//指纹前端处理 
	outcome = myFingerPreProcess(pImageBuf, &interestnum, &leastnum, intrestpoint);
	if(!outcome)
	{
		free(intrestpoint);
		return outcome;
	}
	return Func_success;
}


#endif
