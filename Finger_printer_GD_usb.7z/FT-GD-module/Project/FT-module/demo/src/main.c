/*!
    \file  main.c
    \brief construct a USB custom HID device
*/

/*
    Copyright (C) 2017 GigaDevice

    2017-02-10, V1.0.0, firmware for GD32F30x
*/

#include "usbd_std.h"
#include "custom_hid_core.h"
#include "systick.h"
#include "fingerchipspifunc.h"
#include "database.h"

#include "myFPA.h"

#define USB_PULLUP                      GPIOB
#define USB_PULLUP_PIN                  GPIO_PIN_2
#define RCC_AHBPeriph_GPIO_PULLUP       RCU_GPIOB

usbd_core_handle_struct  usb_device_dev =
{
    .dev_desc = (uint8_t *)&device_descripter,
    .config_desc = (uint8_t *)&configuration_descriptor,
    .strings = usbd_strings,
    .class_init = custom_hid_init,
    .class_deinit = custom_hid_deinit,
    .class_req_handler = custom_hid_req_handler,
    .class_data_handler = custom_hid_data_handler
};

FPC_1020_HANDLE_TypeDef fpc1020am_func_set = 
{
	.spics                    = fpc1020am_spics_ctl,
	.spi_transmit_n_bytes		  = spi_dma_transfer_receive_data,
	.irq_state								= fpc1020_irq_state_get,
	.chipreset								=	fpc1020am_reset_ctl,
	.delayms									= delay_1ms
};

void rcu_config(void);
void key_config(void);
void led_config(void);
void gpio_config(void);
void nvic_config(void);
void com_config(void);

/*!
    \brief      main routine
    \param[in]  none
    \param[out] none
    \retval     none
*/
int main(void)
{
		uint8_t *data=NULL;//,i
	
    /* system clocks configuration */
    rcu_config();
	
	  systick_config();
	
	  /* com configuration */
	  gd_eval_com_init(EVAL_COM1);
	
		gd_eval_spi_init();
	
		fpc1020_irq_init(CTL_IRQ);
	
	  gd_eval_ctl_pin_init(CTL_RSTN);
	
		fpc_func_register(&fpc1020am_func_set);
	
	  fpc1020am_init();
	
		database_init();

//    /* GPIO configuration */
    gpio_config();

    /* USB device configuration */
    usbd_core_init(&usb_device_dev);

    /* NVIC configuration */
    nvic_config();

    /* enabled USB pull-up */
    gpio_bit_set(USB_PULLUP, USB_PULLUP_PIN);

    /* now the usb device is connected */
    usb_device_dev.status = USBD_CONNECTED;

		delay_1ms(100);

		data = (unsigned char *)malloc(192*192);
		
		detect_and_capture_image(data,192*192);

		myFingerEnroll(data,1);

    while (1)
		{
			  if (USBD_CONFIGURED == usb_device_dev.status) 
				{
//					for(i=0;i<100;i++)
//					{
//						data[i] = i;		
//						delay_1ms(5);
//            custom_hid_report_send (&usb_device_dev, data+i, 1);
//					}
        }
		}
}

/*!
    \brief      configure the different system clocks
    \param[in]  none
    \param[out] none
    \retval     none
*/
void rcu_config(void)
{
    /* enable USB pull-up pin clock */ 
    rcu_periph_clock_enable(RCC_AHBPeriph_GPIO_PULLUP);

    /* enable the power clock */
    rcu_periph_clock_enable(RCU_PMU);

#ifndef USE_IRC48M
    rcu_ck48m_clock_config(RCU_CK48MSRC_CKPLL);

    /* configure USB model clock from PLL clock */
    rcu_usb_clock_config(RCU_CKUSB_CKPLL_DIV3_5);
#else
    /* enable IRC48M clock */
    rcu_osci_on(RCU_IRC48M);

    /* wait till IRC48M is ready */
    while (SUCCESS != rcu_osci_stab_wait(RCU_IRC48M)) {
    }

    rcu_ck48m_clock_config(RCU_CK48MSRC_IRC48M);
#endif

    /* enable USB APB1 clock */
    rcu_periph_clock_enable(RCU_USBD);
}

/*!
    \brief      configure the keys
    \param[in]  none
    \param[out] none
    \retval     none
*/
void key_config(void)
{
    /* keys configuration */
    gd_eval_key_init(KEY_USER2, KEY_MODE_EXTI);
    gd_eval_key_init(KEY_WAKEUP, KEY_MODE_EXTI);
}

/*!
    \brief      configure the leds
    \param[in]  none
    \param[out] none
    \retval     none
*/
void led_config(void)
{
    /* initialize LEDs */
    gd_eval_led_init(LED2);
    gd_eval_led_init(LED3);
    gd_eval_led_init(LED4);
    gd_eval_led_init(LED5);
}

/*!
    \brief      configure the gpio peripheral
    \param[in]  none
    \param[out] none
    \retval     none
*/
void gpio_config(void)
{
    /* configure usb pull-up pin */
    gpio_init(USB_PULLUP, GPIO_MODE_OUT_PP, GPIO_OSPEED_50MHZ, USB_PULLUP_PIN);
}

/*!
    \brief      configure interrupt priority
    \param[in]  none
    \param[out] none
    \retval     none
*/
void nvic_config(void)
{
    /* 1 bit for pre-emption priority, 3 bits for subpriority */
    nvic_priority_group_set(NVIC_PRIGROUP_PRE1_SUB3);

    /* enable the USB low priority interrupt */
    nvic_irq_enable(USBD_LP_CAN0_RX0_IRQn, 1, 0);
}
