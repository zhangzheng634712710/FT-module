#include <stdint.h>
#include "flash.h"
#include "gd32f30x_fmc.h"


static FLASH_STATE whole_page_erase(uint32_t page_start_addr)
{
	fmc_flag_clear(FMC_FLAG_BANK0_END | FMC_FLAG_BANK0_WPERR | FMC_FLAG_BANK0_PGERR );
	if(fmc_page_erase(page_start_addr)!=FMC_READY)
		return FLASH_ERROR;
	if(page_start_addr<large_page_start_addr)
	{
		fmc_flag_clear(FMC_FLAG_BANK0_END | FMC_FLAG_BANK0_WPERR | FMC_FLAG_BANK0_PGERR );
		if(fmc_page_erase(page_start_addr+(PAGESIZE/2))!=FMC_READY)
			return FLASH_ERROR;		
	}
	return FLASH_OK;	
}

static FLASH_STATE flash_write_one_page(uint8_t *data,uint32_t start_addr,uint32_t lenth)
{
	uint32_t page_start_addr,offset,i;
	uint8_t *buf = NULL;
	if((start_addr<FLASH_database_start_addr)||(start_addr+lenth>=FLASH_database_start_addr+Flash_database_lenth)||lenth>PAGESIZE) 
		return FLASH_ERROR;
	
	page_start_addr = get_page_start_addr(start_addr);
	offset = start_addr - page_start_addr;
	if(start_addr+lenth>page_start_addr+PAGESIZE)
		return FLASH_ERROR;
	
	buf = malloc(PAGESIZE);
	if(!buf) return FLASH_ERROR;
	
	/* unlock the flash program/erase controller */
	fmc_unlock();
	
	Flash_read(buf,page_start_addr,PAGESIZE);
	if(FLASH_ERROR==whole_page_erase(page_start_addr))
	{
		fmc_lock();
		free(buf);
		return FLASH_ERROR;
	}
	
	for(i=0;i<lenth;i++)
	{
		*(buf+offset+i) = *(data+i);
	}
	
	for(i=0;i<PAGESIZE;i+=4)
	{
		fmc_flag_clear(FMC_FLAG_BANK0_END | FMC_FLAG_BANK0_WPERR | FMC_FLAG_BANK0_PGERR );
		if(FMC_READY != fmc_word_program(page_start_addr+i,*((uint32_t*)(buf+i))))
		{
			fmc_lock();
			free(buf);
			return FLASH_ERROR;			
		}
		if(*((uint32_t*)(page_start_addr+i)) != *((uint32_t*)(buf+i)))
		{
			fmc_lock();
			free(buf);
			return FLASH_ERROR;			
		}
	}
	fmc_lock();
	free(buf);
	return FLASH_OK;
}

FLASH_STATE Flash_read(uint8_t *buffer,uint32_t flash_addr,uint32_t len)
{
	for(;len!=0;len--)
	{
		*buffer = *((uint8_t*)flash_addr);
	  buffer++;
		flash_addr++;
	}
	return FLASH_OK;
}

FLASH_STATE Flash_write(uint8_t *buffer,uint32_t flash_addr,uint32_t len)
{
	uint32_t offset;
	while(len>0)
	{
		offset = get_next_page_start_addr(flash_addr) - flash_addr;
		if(offset>=len)
		{
			if(FLASH_ERROR==flash_write_one_page(buffer,flash_addr,len))
			{
				return FLASH_ERROR;
			}
			len=0;
			buffer += len;
			flash_addr += len;
		}
		else
		{
			if(FLASH_ERROR==flash_write_one_page(buffer,flash_addr,offset))
			{
				return FLASH_ERROR;				
			}
			len-=offset;
			buffer += offset;
			flash_addr += offset;
		}
	}
	return FLASH_OK;
}

