#ifndef DATABASE_H
#define DATABASE_H

#include <stdint.h>
#include "flash.h"
#include <stdbool.h>

#define align_front(addr,mask)  (((addr)+(mask))&(~((mask)-1)))

#define DB_base_addr		    FLASH_database_start_addr
//#define DB_header_addr			database_base_addr
//#define DB_header_len			(sizeof(DB_header_typedef))
//#define DB_ft_header_addr		DB_header_addr+DB_header_len
//#define DB_ft_max_number		150
//#define DB_one_ft_header_len	(sizeof(DB_ft_header_typedef))
//#define DB_ft_header_len        (DB_ft_max_number*DB_one_ft_header_len)
//#define DB_storage_map_addr		(DB_ft_header_addr+DB_ft_header_len)
//#define DB_storage_map_len		(sizeof(DB_storage_block_typedef)*DB_ft_max_number)
//#define DB_ft_data_addr			(DB_storage_map_addr+DB_storage_map_len)

#define FT_DATABASE_LEN         (sizeof(FT_DATABASE_typedef))               //实际指纹库的头的大小
#define FT_DATABASE_DEFAULT_LEN	8192                                        //指纹数据库的头预留的空间大小
#define DB_ft_block_size		    4096                                        //一枚指纹数据预留的空间

//#if (FT_DATABASE_DEFAULT_LEN < FT_DATABASE_LEN)
//	#error "指纹库的header预留的空间太小!"
//#endif

#define FT_data_addr              DB_base_addr+FT_DATABASE_DEFAULT_LEN       //存放指纹数据的起始地址
//#define FT_data_addr            (align_front(FLASH_database_start_addr+FT_DATABASE_LEN,DB_ft_block_size))  //存放指纹数据的起始地址，以4k对齐

#define FT_data_block_max_number			150                                         // 需要根据每一枚指纹数据的大小来做决定
#define DB_ft_max_number							(FT_data_block_max_number/10*9)             // 需小于block数量的大小

#if FT_data_addr+(DB_ft_block_size*FT_data_block_max_number) > Flash_database_end_addr
	#error "指纹数据的大小超过了存储区的大小，尝试更改block的数量!"
#endif

#define DATABASE_FLAG			0x55AAAA55

typedef enum
{
    FT_INFO_EMPTY = 0,
    FT_INFO_USING,
    FT_INFO_USED,
}FT_INFO_FLAG_typedef; 

typedef enum 
{
    BLOCK_EMPTY = 0,
    BLOCK_USING,
    BLOCK_USED
}DB_block_map_info_typedef; 

typedef struct DB_info_s
{
	uint32_t                DB_flag;
	uint16_t                DB_ft_number;
	struct DB_ft_info_s     *DB_first_ft_info;
  uint16_t                DB_last_ft_info_number;
}DB_info_typedef;

typedef struct DB_ft_info_s
{
  FT_INFO_FLAG_typedef    ft_info_flag;
	uint16_t                FT_id;
	uint8_t                 *FT_data;	
	uint16_t                FT_data_len;	
	struct DB_ft_info_s     *DB_prev_ft_info;
	struct DB_ft_info_s     *DB_next_ft_info;
	uint16_t                DB_ft_info_num;	
	uint16_t                DB_ft_block_num;	
}DB_ft_info_typedef;

typedef struct 
{
    DB_info_typedef                 DB_info;
    DB_ft_info_typedef              DB_ft_info[DB_ft_max_number];
    DB_block_map_info_typedef       DB_block_map_info[FT_data_block_max_number];
}FT_DATABASE_typedef;

bool database_reinit(void);
bool database_init(void);
bool database_insert(uint16_t ft_id,uint8_t *ft_data,uint16_t data_len);
bool is_ft_id_in_database(uint16_t id);
uint16_t get_next_unused_ft_id(void);
bool delete_ft_id_in_database(uint16_t id);

#endif

