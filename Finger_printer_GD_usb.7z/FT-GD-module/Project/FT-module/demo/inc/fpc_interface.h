#ifndef FPC_INTERFACE_H
#define FPC_INTERFACE_H

#include <stdint.h>
#include "fingerchipspifunc.h"

#define LARGE_SENSOR

#if defined LARGE_SENSOR
	#define SENSOR_COLUMN               192
	#define SENSOR_ROW                  192
#elif defined SMALL_SENSOR
	#define SENSOR_COLUMN         			96
	#define SENSOR_ROW            			96
#else
	#error "please define sensor type!"
#endif

FPC_SENSOR_STATUS FPC_SENSOR_INIT(void);
FPC_SENSOR_STATUS WHETHER_FINGER_IS_ON_CHIP(void);
FPC_SENSOR_STATUS READ_ONE_IMAGE(uint8_t *image_pointer, uint16_t lenth);
FPC_SENSOR_STATUS DETECT_AND_READ_ONE_IMAGE(uint8_t *image_pointer, uint16_t lenth);
//FPC_SENSOR_STATUS BREAK_FROM_CURRENT_STATUS(void);

#endif

