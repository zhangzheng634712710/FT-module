#ifndef MYFPA_H_
#define MYFPA_H_

#include <stdint.h>

/*********************************************************************************************************/
//已修改的地方：
//	1、图像大小G_HEIGHT/G_WIDTH
//	2、特征点数量MAX_MINUTIAE/COLMNUM
//  3、将图像质量检测中的阈值设成宏定义
//	4、将函数的返回值设置成宏定义
/*********************************************************************************************************/

#define     MAXMINUTIANUM			60			// 最大特征点数

//图像大小
#define G_HEIGHT           192
#define G_WIDTH            192
#define TOTAL_LENGTH       (G_HEIGHT*G_WIDTH)   //指纹总数

#define OFFSET_X 40
#define OFFSET_Y 40

#define CYCLE_ANGLE        256 //256             360度
#define CYCLE_ANGLE_HALF   128 //CYCLE_ANGLE/2   180度
#define CYCLE_ANGLE_QUATER 64

//cos表大小
#define cos_parts_num 9        //cos份数
#define D_PI     512           //3141592 //CYCLE_ANGLE/2  360弧度
#define D_PI_2   256           //CYCLE_ANGLE/2   180弧度
#define D_PI_4   128           //CYCLE_ANGLE/2   90弧度

//cos表倍数
#define cos_num 10                  //cos放大倍数
#define cos_num2 (2<<(cos_num-1))   //cos放大数的一半

//atan表大小
#define K_ATAN_NUM 256            //atan 表大小num
#define atan_num 8                //atan移位数num
#define atan_threold 29335        //2048倍对应234680，58670对应512，29335对应256


#define MAX_MINUTIAE	  178      //98  大面积特征点数178个 小面积特征点数98个
#define COLMNUM         20       //描述值数组一行包含多少列数据

#define	WetTH       		70
#define	DryTH       		200
#define	DirVarTh    		100
#define	AreaTH      	  60

#define Func_success         1
#define Image_quality_low		-2
#define Malloc_failed				-3


typedef struct tagMinutiae { 
  int    x;				               // 横坐标
  int    y;				               // 纵坐标
  int    Direction;		           // 方向
  double reliability;            // 质量
  int	Triangle[3];	             // 特征点为中心外接圆半径为定值的正三角形三个顶点的方向
  int    Type;			             // 类型
} MINUTIA, *MINUTIAPTR; 

// 指纹特征(模板)结构
typedef struct tagFeature{
	int		MinutiaNum;					             // 特征点数
	MINUTIA		MinutiaArr[MAXMINUTIANUM];	 // 特征点数组V
} FEATURE, *FEATUREPTR;

typedef struct tagMatchResult { 
  int    Similarity; 
  int    Rotation; 
  int    TransX;
  int    TransY;
  int	   MMCount;
} MATCHRESULT, *PMATCHRESULT; 


//功能：图像前端处理 得到描述值和特征点个数、极小值个数
signed char myFingerPreProcess(unsigned char* pImageBuf, unsigned int *DescribNum, unsigned int *leastnum, signed short *describdata);

//功能：将图像归一化到指定的均值方差范围内
void myImageNormalize(unsigned char *lpDIBBits, unsigned char *lpDataOut);

//功能：指纹注册功能函数
signed char myFingerEnroll(unsigned char *pImageBuf, unsigned short fingerid);

#endif

