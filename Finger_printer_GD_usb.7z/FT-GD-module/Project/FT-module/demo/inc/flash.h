#ifndef _FLASH_H
#define _FLASH_H

#include <stdint.h>

#define FLASH_database_start_addr					0x08040000
#define Flash_database_lenth              0xc0000
#define PAGESIZE                          4096
#define large_page_start_addr             0x08080000
#define Flash_database_end_addr						(FLASH_database_start_addr+Flash_database_lenth)

#define get_page_start_addr(addr)         (((addr))&(~(PAGESIZE-1)))
#define get_next_page_start_addr(addr)    (((addr)+(PAGESIZE))&(~(PAGESIZE-1)))

typedef enum
{
	FLASH_ERROR = 0x00,
	FLASH_OK    = 0x01
}FLASH_STATE;

FLASH_STATE Flash_read(uint8_t *buffer,uint32_t flash_addr,uint32_t len);
FLASH_STATE Flash_write(uint8_t *buffer,uint32_t flash_addr,uint32_t len);

#endif
