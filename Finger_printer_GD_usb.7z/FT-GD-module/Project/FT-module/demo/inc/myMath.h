#ifndef MYMATH_H_
#define MYMATH_H_

//以某点为中心划分nPart个角度，对应的坐标生成
int devideCycle_XY(int* pDSiteX, int* pDSiteY, int nPart ,int r);

#endif
