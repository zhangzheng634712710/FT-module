#include "database.h"
#include "flash.h"
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

static uint16_t get_next_empty_block_num(void);
static uint16_t get_next_empty_ft_info(void);
static uint16_t get_ft_number_by_ft_id(uint16_t id);
static uint16_t get_block_number_by_ft_id(uint16_t id);

bool database_reinit(void)
{
	FT_DATABASE_typedef *buffer = (FT_DATABASE_typedef*)malloc(FT_DATABASE_LEN);
	if(!buffer) return false;
    memset(buffer,0,FT_DATABASE_LEN);
	//init FR DATABASE
	buffer->DB_info.DB_flag = DATABASE_FLAG;
	buffer->DB_info.DB_ft_number = 0;                       //指纹的数量
	buffer->DB_info.DB_first_ft_info = NULL;
	buffer->DB_info.DB_last_ft_info_number = 0;                  
	if(Flash_write((uint8_t *)buffer,DB_base_addr,FT_DATABASE_LEN))
	{
		free(buffer);
		return true;
	}
	else
	{
		free(buffer);
		return false;
	}
}

bool database_init(void)
{
    if(((FT_DATABASE_typedef *)DB_base_addr)->DB_info.DB_flag==DATABASE_FLAG)
        return true;
    else
        return database_reinit();
}

bool database_insert(uint16_t ft_id,uint8_t *ft_data,uint16_t data_len)
{
    uint16_t temp_ft,temp_block;
		FT_DATABASE_typedef *buffer = (FT_DATABASE_typedef*)malloc(FT_DATABASE_LEN);
		if(!buffer) return false;
    memcpy((uint8_t *)buffer,(uint8_t *)DB_base_addr,FT_DATABASE_LEN);
    temp_block = get_next_empty_block_num();   //get_first_empty_block_num();
		if(Flash_write(ft_data,FT_data_addr+(DB_ft_block_size*temp_block),data_len))
    {
				buffer->DB_block_map_info[temp_block]=BLOCK_USING;                                        //更改DB_block_map_info
        temp_ft = get_next_empty_ft_info();
			  buffer->DB_ft_info[temp_ft].ft_info_flag = FT_INFO_USING;                                 //更改DB_ft_info区
        buffer->DB_ft_info[temp_ft].FT_id = ft_id;
        buffer->DB_ft_info[temp_ft].FT_data = (uint8_t *)(FT_data_addr+(DB_ft_block_size*temp_block));
        buffer->DB_ft_info[temp_ft].FT_data_len = data_len;
        buffer->DB_ft_info[temp_ft].DB_ft_block_num = temp_block;
        buffer->DB_ft_info[temp_ft].DB_ft_info_num = temp_ft;
        if(buffer->DB_info.DB_ft_number == 0)
        {
            buffer->DB_ft_info[temp_ft].DB_prev_ft_info = NULL;
            buffer->DB_ft_info[temp_ft].DB_next_ft_info = NULL; 
            buffer->DB_info.DB_first_ft_info = (DB_ft_info_typedef *)(&(((FT_DATABASE_typedef *)DB_base_addr)->DB_ft_info[temp_ft]));
            buffer->DB_info.DB_last_ft_info_number = temp_ft;                                            //DB_ft_info链表的最后一个元素的序号
        }
        else
        {
					  buffer->DB_ft_info[buffer->DB_info.DB_last_ft_info_number].DB_next_ft_info = (DB_ft_info_typedef *)(&(((FT_DATABASE_typedef *)DB_base_addr)->DB_ft_info[temp_ft]));
            buffer->DB_ft_info[temp_ft].DB_prev_ft_info = (DB_ft_info_typedef *)(&(((FT_DATABASE_typedef *)DB_base_addr)->DB_ft_info[buffer->DB_info.DB_last_ft_info_number]));
            buffer->DB_ft_info[temp_ft].DB_next_ft_info = NULL;
            buffer->DB_info.DB_last_ft_info_number = temp_ft;
        }
        buffer->DB_info.DB_ft_number++;
        if(Flash_write((uint8_t *)buffer,DB_base_addr,FT_DATABASE_LEN))
        {
            free(buffer);
            return true;
        }
        else
        {
            free(buffer);
            return false;
        }
    }
    else
    {
        free(buffer);
        return false;
    }
}

static uint16_t get_next_empty_ft_info(void)
{
    uint16_t i=0;
    FT_DATABASE_typedef *buffer = (FT_DATABASE_typedef *)DB_base_addr;
    for(;i<DB_ft_max_number;i++)
    {
        if((buffer->DB_ft_info[i].ft_info_flag==FT_INFO_EMPTY)||(buffer->DB_ft_info[i].ft_info_flag==FT_INFO_USED))
            return i;
    }
    return 0;
}
 
static uint16_t get_next_empty_block_num(void)
{
    uint16_t i=0;
    FT_DATABASE_typedef *buffer = (FT_DATABASE_typedef *)DB_base_addr;
    for(;i<DB_ft_max_number;i++)
    {
        if((buffer->DB_block_map_info[i]==BLOCK_EMPTY)||(buffer->DB_block_map_info[i]==BLOCK_USED))
            return i;
    }
    return 0;
}

static uint16_t get_ft_number_by_ft_id(uint16_t id)
{
    DB_ft_info_typedef *db_ft_info = ((FT_DATABASE_typedef *)DB_base_addr)->DB_info.DB_first_ft_info;
	  if(db_ft_info==NULL) return 0;
	  while(true)
		{
			if(db_ft_info->FT_id==id)
				return db_ft_info->DB_ft_info_num;
			if(db_ft_info->DB_next_ft_info == NULL)
				return 0;
			else
				db_ft_info = db_ft_info->DB_next_ft_info;
		}
}

static uint16_t get_block_number_by_ft_id(uint16_t id)
{
    DB_ft_info_typedef *db_ft_info = ((FT_DATABASE_typedef *)DB_base_addr)->DB_info.DB_first_ft_info;
	  if(db_ft_info==NULL) return 0;
	  while(true)
		{
			if(db_ft_info->FT_id==id)
				return db_ft_info->DB_ft_block_num;
			if(db_ft_info->DB_next_ft_info == NULL)
				return 0;
			else
				db_ft_info = db_ft_info->DB_next_ft_info;
		}
}

bool is_ft_id_in_database(uint16_t id)
{
    DB_ft_info_typedef *db_ft_info = ((FT_DATABASE_typedef *)DB_base_addr)->DB_info.DB_first_ft_info;
    while(true)
    {
        if((db_ft_info->FT_id == id)&&(db_ft_info->ft_info_flag == FT_INFO_USING))
            return true;
        if(db_ft_info->DB_next_ft_info == NULL)
            return false;
    }
}

uint16_t get_next_unused_ft_id(void)
{
    uint16_t i;
    for(i=1;i<UINT16_MAX;i++)
    {
        if(is_ft_id_in_database(i))
            return i;
    }
    return false;
}

bool delete_ft_id_in_database(uint16_t id)
{
    DB_ft_info_typedef *temp_db_ft_info=NULL;
		uint16_t ft_info_num = get_ft_number_by_ft_id(id);
		uint16_t ft_block_num = get_block_number_by_ft_id(id);	
		FT_DATABASE_typedef *buffer = (FT_DATABASE_typedef*)malloc(FT_DATABASE_LEN);
		if(!buffer) return false;
    memcpy((uint8_t *)buffer,(uint8_t *)DB_base_addr,FT_DATABASE_LEN);
	  buffer->DB_block_map_info[ft_block_num] = BLOCK_USED;
	  buffer->DB_ft_info[ft_info_num].ft_info_flag = FT_INFO_USED;
		if(buffer->DB_ft_info[ft_info_num].DB_prev_ft_info==NULL)
		{
			temp_db_ft_info = buffer->DB_ft_info[ft_info_num].DB_next_ft_info;
			buffer->DB_ft_info[temp_db_ft_info->DB_ft_info_num].DB_prev_ft_info = NULL;
		  buffer->DB_info.DB_first_ft_info = temp_db_ft_info;
		}
		else if(buffer->DB_ft_info[ft_info_num].DB_next_ft_info==NULL)
		{
			temp_db_ft_info = buffer->DB_ft_info[ft_info_num].DB_prev_ft_info;
			buffer->DB_ft_info[temp_db_ft_info->DB_ft_info_num].DB_next_ft_info = NULL;
			buffer->DB_info.DB_last_ft_info_number = temp_db_ft_info->DB_ft_info_num;
		}
		else
		{
			temp_db_ft_info = buffer->DB_ft_info[ft_info_num].DB_next_ft_info;
			buffer->DB_ft_info[temp_db_ft_info->DB_ft_info_num].DB_prev_ft_info = buffer->DB_ft_info[ft_info_num].DB_prev_ft_info;
			temp_db_ft_info = buffer->DB_ft_info[ft_info_num].DB_prev_ft_info;
			buffer->DB_ft_info[temp_db_ft_info->DB_ft_info_num].DB_next_ft_info = buffer->DB_ft_info[ft_info_num].DB_next_ft_info;			
		}
	  buffer->DB_info.DB_ft_number--;
		
		//当指纹数量为0时，DB_first_ft_info和DB_last_ft_info_number清零
		if(buffer->DB_info.DB_ft_number==0)
		{
			buffer->DB_info.DB_first_ft_info = NULL;
			buffer->DB_info.DB_last_ft_info_number = 0;
		}
		
		if(Flash_write((uint8_t *)buffer,DB_base_addr,FT_DATABASE_LEN))
		{
				free(buffer);
				return true;
		}
		else
		{
				free(buffer);
				return false;
		}		
}

//    temp_db_ft_info = buffer->DB_info.DB_first_ft_info;
//    while(true)
//    {
//        if(temp_db_ft_info->ft_info_flag != FT_INFO_USING)
//        {
//            free(buffer);
//            return false;
//        }
//        else
//        {
//            if(temp_db_ft_info->FT_id == id)
//            {
//                buffer->DB_block_map_info[temp_db_ft_info->DB_ft_block_num] = BLOCK_USED;
//                temp_db_ft_info->ft_info_flag = FT_INFO_USED;
//                if(temp_db_ft_info->DB_prev_ft_info ==NULL)
//                {
//                    temp_db_ft_info->DB_next_ft_info->DB_prev_ft_info = NULL;
//                    buffer->DB_info.DB_first_ft_info = temp_db_ft_info->DB_next_ft_info;
//                }
//                else if(temp_db_ft_info->DB_next_ft_info == NULL)
//                {
//                    temp_db_ft_info->DB_prev_ft_info->DB_next_ft_info = NULL;   
//                    buffer->DB_info.DB_last_ft_info_number = get_ft_number_by_ft_id(temp_db_ft_info->DB_prev_ft_info->FT_id);
//                }
//                else
//                {
//                    temp_db_ft_info->DB_prev_ft_info->DB_next_ft_info = temp_db_ft_info->DB_next_ft_info;   
//                    temp_db_ft_info->DB_next_ft_info->DB_prev_ft_info = temp_db_ft_info->DB_prev_ft_info;   
//                }
//                buffer->DB_info.DB_ft_number--;
//            }
//            else
//                temp_db_ft_info = temp_db_ft_info->DB_next_ft_info;
//        }
//    }
