#include "myMath.h"
#include <math.h>

#define PI					3.1415926

//以某点为中心划分nPart个角度，对应的坐标生成
//以某点为中心划分nPart个角度，对应的坐标生成
int devideCycle_XY(int* pDSiteX, int* pDSiteY, int nPart ,int r)
{
	int k1 = 0;
	int k2 = 0;
	double sita = 0;
	double tmp = 0;

	for(k1 = 0;k1<nPart;k1++)
	{
		sita = (double)k1*PI/nPart;
			for(k2 = -r;k2<=r;k2++)
			{
				//pDsite[k1][k2+r][0] = r*cos(sita);
				tmp = k2*cos(sita);
				if (tmp>0)
				    *(pDSiteX + k1*(2*r+1)+(k2+r)) = (int)(tmp+0.5);
				else
					*(pDSiteX + k1*(2*r+1)+(k2+r)) = (int)(tmp-0.5);

				//pDsite[k1][k2+r][1] = r*sin(sita);
				tmp = k2*sin(sita);
				if (tmp>0)
				    *(pDSiteY + k1*(2*r+1)+(k2+r)) = (int)(tmp+0.5);
				else
					*(pDSiteY + k1*(2*r+1)+(k2+r)) = (int)(tmp-0.5);

			}
	}
	return 0;
}
