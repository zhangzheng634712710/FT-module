#include "fingerchipspifunc.h"
//#include "stdlib.h"


static FPC_1020_HANDLE_TypeDef *fpc1020am_handle = 0;

/* 在一个SPICS拉低的时间内，发送并接受lenth个字节，接受的数据写回dataarry指向的地址 */
static void fingerchip_send_data(unsigned char *dataarry,unsigned short lenth)
{
	fpc1020am_handle->spics(CS_DOWN);
	fpc1020am_handle->spi_transmit_n_bytes(dataarry,lenth);
	fpc1020am_handle->spics(CS_UP);
}

/* sensor 进入休眠模式 */
static void enter_deep_sleep_mode(void)
{
	unsigned char temp = 0x2c;
	fingerchip_send_data(&temp,1);
}

/* sensor 从休眠模式唤醒，进入idle模式 */
static void enter_idle_mode(void)
{
	unsigned char send_data[2]={0,0};
	unsigned char temp=0;
	send_data[0] = 0x34; 
	fingerchip_send_data(send_data,1);
  do
  {
			fpc1020am_handle->delayms(1);
		  temp++;
	}
	while((!(fpc1020am_handle->irq_state()))&&(temp<5));	
	if(temp>=5) return;
	send_data[0] = 0x1c; send_data[1] = 0x00; 
	fingerchip_send_data(send_data,2);
}

/* spi reset irq time 功能注册 */
void fpc_func_register(FPC_1020_HANDLE_TypeDef *sensor_handle)
{
	fpc1020am_handle = sensor_handle;
}

/* 芯片初始化，然后进入休眠 */
void fpc1020am_init(void)
{
//	unsigned char *temp = 0;
	unsigned char init_data[3]={0,0,0};
	fpc1020am_handle->chipreset(CHIP_RESET);
	fpc1020am_handle->delayms(5);
	fpc1020am_handle->chipreset(CHIP_SET);
	fpc1020am_handle->delayms(1);

//  测试通讯
//	init_data[0] = 0xfc; init_data[1] = 0x00; init_data[2] = 0x00; 
//	fingerchip_send_data(init_data,3);

	init_data[0] = 0xf8;
	fingerchip_send_data(init_data,1);
	fpc1020am_handle->delayms(1);
	init_data[0] = 0x1c; init_data[1] = 0x00; 
	fingerchip_send_data(init_data,2);
	init_data[0] = 0x8c; init_data[1] = 0x32; 
	fingerchip_send_data(init_data,2);
	init_data[0] = 0xa0; init_data[1] = 0x07; init_data[2] = 0x03; 
	fingerchip_send_data(init_data,3);
	init_data[0] = 0xdc; init_data[1] = 0x00; init_data[2] = 0x01; 
	fingerchip_send_data(init_data,3);
	enter_deep_sleep_mode();
	
//	temp = malloc(192*192);
//	(*temp) = wether_finger_is_on_chip();
//	capture_image(temp,192*192);
//	detect_and_capture_image(temp,192*192);
}

/* 判断手指是否按压在芯片上 */
FPC_SENSOR_STATUS wether_finger_is_on_chip(void)
{
	unsigned char send_data[3]={0,0,0};
  unsigned char temp=0;	
	
	enter_idle_mode();
	
	send_data[0] = 0x20; 
	fingerchip_send_data(send_data,1);
  do
  {
			fpc1020am_handle->delayms(1);
		  temp++;
	}
	while((!(fpc1020am_handle->irq_state()))&&(temp<20));
	if (temp>=20) 
	{
		enter_deep_sleep_mode();
		return FPC_SENSOR_ERROR;
	}
	send_data[0] = 0x1c; send_data[1] = 0x00; 
	fingerchip_send_data(send_data,2);
	
	enter_deep_sleep_mode();
	if ((send_data[1]&0x01) == 0x01) return FPC_SENSOR_DETECTED;
	else return FPC_SENSOR_NOT_DETECTED;
	
//	send_data[0] = 0xD4; send_data[1] = 0x00; send_data[2] = 0x00; 
//	fingerchip_send_data(send_data,3);
//	if (send_data[2]&0x60 == 0x60) return FPC_SENSOR_DETECTED;
//	else return FPC_SENSOR_NOT_DETECTED;
}	

/* 捕获一张图像（不检测手指是否按压在芯片上）*/
FPC_SENSOR_STATUS capture_image(unsigned char *image_data,unsigned short lenth)
{
	unsigned char send_data[2]={0,0};
  unsigned char temp=0;	
	
	enter_idle_mode();
	
	send_data[0] = 0xc0; 
	fingerchip_send_data(send_data,1);
  do
  {
			fpc1020am_handle->delayms(1);
		  temp++;
	}
	while((!(fpc1020am_handle->irq_state()))&&(temp<30));
	if (temp>=20) 
	{
		enter_deep_sleep_mode();
		return FPC_SENSOR_ERROR;
	}
	send_data[0] = 0x1c; send_data[1] = 0x00; 
	fingerchip_send_data(send_data,2);
	if((send_data[1]&0x20) != 0x20)
	{
		enter_deep_sleep_mode();
		return FPC_SENSOR_ERROR;
	}
	
	fpc1020am_handle->spics(CS_DOWN);
	send_data[0] = 0xc4; send_data[1] = 0x00; 
	fpc1020am_handle->spi_transmit_n_bytes(send_data,2);
  fpc1020am_handle->spi_transmit_n_bytes(image_data,lenth);
	fpc1020am_handle->spics(CS_UP);
	
	send_data[0] = 0x1c; send_data[1] = 0x00; 
	fingerchip_send_data(send_data,2);
	
	enter_deep_sleep_mode();
	if((send_data[1]&0x04) == 0x04) return FPC_SENSOR_ERROR;	
  else return FPC_SENSOR_OK;
}

/* 等待手指按压，并获取一张指纹图像，若手指在5秒钟之内未按压，则退出，不再捕获图像 */
FPC_SENSOR_STATUS detect_and_capture_image(unsigned char *image_data,unsigned short lenth)
{
	unsigned char send_data[2]={0,0};
  unsigned short temp=0;
		
	enter_idle_mode();
	
	send_data[0] = 0x28; 
	fingerchip_send_data(send_data,1);
	do
  {
			fpc1020am_handle->delayms(1);
		  temp++;
	}
	while((!(fpc1020am_handle->irq_state()))&&(temp<5000));
	if (temp>=5000) 
	{
		enter_deep_sleep_mode();
		return FPC_SENSOR_NOT_DETECTED;
	}

	send_data[0] = 0x1c; send_data[1] = 0x00; 
	fingerchip_send_data(send_data,2);
	
	if((send_data[1]&0x01) != 0x01)
	{
		enter_deep_sleep_mode();
		return FPC_SENSOR_ERROR;
	}	
	
	send_data[0] = 0xc0; 
	fingerchip_send_data(send_data,1);
	
	temp = 0;
  do
  {
			fpc1020am_handle->delayms(1);
		  temp++;
	}
	while((!(fpc1020am_handle->irq_state()))&&(temp<30));
	if (temp>=30) 
	{
		enter_deep_sleep_mode();
		return FPC_SENSOR_ERROR;
	}
	send_data[0] = 0x1c; send_data[1] = 0x00; 
	fingerchip_send_data(send_data,2);
	if((send_data[1]&0x20) != 0x20)
	{
		enter_deep_sleep_mode();
		return FPC_SENSOR_ERROR;
	}
	
	send_data[0] = 0xc4; send_data[1] = 0x00; 	
	
	fpc1020am_handle->spics(CS_DOWN);
	fpc1020am_handle->spi_transmit_n_bytes(send_data,2);
  fpc1020am_handle->spi_transmit_n_bytes(image_data,lenth);
	fpc1020am_handle->spics(CS_UP);
	
	send_data[0] = 0x1c; send_data[1] = 0x00; 
	fingerchip_send_data(send_data,2);
	
	enter_deep_sleep_mode();
	if((send_data[1]&0x04) == 0x04) return FPC_SENSOR_ERROR;	
  else return FPC_SENSOR_OK;	
}

