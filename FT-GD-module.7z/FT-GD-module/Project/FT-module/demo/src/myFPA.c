#ifndef MYFPA_C_
#define MYFPA_C_

#include "custom_hid_core.h"

#include "myFPA.h"
#include "stdlib.h"
#include "string.h"
#include "math.h"

#if (defined(PC_IMAGE_DEBUG))
	extern usbd_core_handle_struct  usb_device_dev ;
	struct {
		uint8_t orgmean;
		uint32_t var;
		uint32_t coeff;
	}nomalize_para;
	
	struct {
		uint32_t image_quality_test;
		uint32_t image_nomalize_test;
		uint32_t image_smooth_filter1;
		uint32_t image_smooth_filter2;
		uint32_t image_smooth_filter3;
	}process_time;
#endif
	
extern volatile uint32_t time;

const unsigned short g_p_off_11x11[121] = {
	0   , 1   , 2   , 3   , 4   , 5   , 6   , 7   , 8   , 9   , 10  ,
	192 , 193 , 194 , 195 , 196 , 197 , 198 , 199 , 200 , 201 , 202 ,
	384 , 385 , 386 , 387 , 388 , 389 , 390 , 391 , 392 , 393 , 394 ,
  576 , 577 , 578 , 579 , 580 , 581 , 582 , 583 , 584 , 585 , 586 ,
  768 , 769 , 770 , 771 , 772 , 773 , 774 , 775 , 776 , 777 , 778 ,
  960 , 961 , 962 , 963 , 964 , 965 , 966 , 967 , 968 , 969 , 970 ,
  1152, 1153, 1154, 1155, 1156, 1157, 1158, 1159, 1160, 1161, 1162,
  1344,	1345, 1346, 1347, 1348, 1349, 1350, 1351, 1352, 1353, 1354,
	1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1546,
	1728, 1729, 1730, 1731, 1732, 1733, 1734, 1735, 1736, 1737, 1738,
	1920, 1921, 1922, 1923, 1924, 1925, 1926, 1927, 1928, 1929, 1930,
};

const unsigned short g_p_off_9x9[9] = {
	   0,  192,  384,  576,  768,  960, 1152, 1344, 1536
};

const unsigned short g_p_off_9x9_5x5[25] = {
	0   , 2   , 4   , 6   , 8   ,  
	384 , 386 , 388 , 390 , 392 , 
  768 , 770 , 772 , 774 , 776 ,  
  1152, 1154, 1156, 1158, 1160, 
	1536, 1538, 1540, 1542, 1544, 
};
const unsigned short g_p_off_4x4[16] = {
	0   , 1   , 2   , 3   ,
	192 , 193 , 194 , 195 ,
	384 , 385 , 386 , 387 , 
  576 , 577 , 578 , 579 , 
};
const signed int g_p_l_9[9] = {
	-1, 191, 383, 575, 767, 959, 1151, 1343, 1535,
};
const signed int g_p_r_9[9] = {
	8, 200, 392, 584, 776, 968, 1160, 1352, 1544,
};
const signed int g_p_u_9[9] = {
	-192, -191, -190, -189, -188, -187, -186, -185, -184,
};
const signed int g_p_d_9[9] = {
	1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544,
};
//7*7分成8个方向，坐标在左上
const unsigned short  g_D_778[8][7] = {
  576 , 577 , 578 , 579 , 580 , 581 , 582 ,
  960 ,	769 , 770 , 579 , 388 , 389 , 198 ,
	1152, 961 , 770 , 579 , 388 , 197 , 6   ,
	1153, 962 , 770 , 579 , 388 , 196 , 5   ,
	3   , 195 , 387 , 579 , 771 , 963 , 1155,
	1   , 194 , 386 , 579 , 772 , 964 , 1157,
	0   , 193 , 386 , 579 , 772 , 965 , 1158,
	192 , 385 , 386 , 579 , 772 , 773 , 966
};

//7*7分成8个方向，坐标在左上
//const signed char  g_D_778[8][7][2] = {
//	-3, 0,  -2, 0,  -1, 0,   0, 0,   1, 0,   2, 0,   3, 0,  //0 度
//	-3, 2,  -2, 1,  -1, 1,   0, 0,   1,-1,   2,-1,   3,-2,	//22.5
//	-3, 3,  -2, 2,  -1, 1,   0, 0,   1,-1,   2,-2,   3,-3,	//45
//	-2, 3,  -1, 2,  -1, 1,   0, 0,   1,-1,   1,-2,   2,-3,  //67.5
//	 0, 3,   0, 2,   0, 1,   0, 0,   0,-1,   0,-2,   0,-3,	//90
//	-2,-3,  -1,-2,  -1,-1,   0, 0,   1, 1,   1, 2,   2, 3,  //112.5
//	-3,-3,  -2,-2,  -1,-1,   0, 0,   1, 1,   2, 2,   3, 3,  //135
//	-3,-2,  -2,-1,  -1,-1,   0, 0,   1, 1,   2, 1,   3, 2,  //157.5
//};

//图像反色
void image_inverte(unsigned char *data,uint16_t lenth)
{
	uint16_t i;
	for(i=0;i<lenth;i++)
		*(data+i) = 255 - *(data+i);
}

//判断图片质量,同时返回图片的信息
void myImageQuality(unsigned char* image, unsigned char *reVal)
{

	signed short i = 0, j = 0, k = 0;

	unsigned char* lpSrc = NULL;
	
	unsigned char nblk = 4;
	
	unsigned int mean[8] = { 0 };                //存储7*7矩阵中八条线的灰度平均值
	unsigned int var[8]  = { 0 };                //存储7*7矩阵中八条线的灰度方差 
	
	unsigned int varmax = 0, varmin = 0, meanmax = 0 ;// meanmin = 0;

	unsigned int varRange = 0, RangeCnt = 0;
	unsigned int count = 0;
	unsigned int AreaRatio = 0;

	#if (defined(PC_IMAGE_DEBUG))
		time = 0;
	#endif
	
	for (j = 0; j < G_HEIGHT-nblk; j = j + nblk)
	{
		for (i = 0; i < G_WIDTH-nblk; i = i + nblk)
		{
			lpSrc = image + (j*G_WIDTH) + i;
			for (k = 0; k < 8; k++)
			{
				mean[k] = 0;
				var[k] = 0;
				mean[k] += *(lpSrc+g_D_778[k][0]);
				mean[k] += *(lpSrc+g_D_778[k][1]);
				mean[k] += *(lpSrc+g_D_778[k][2]);
				mean[k] += *(lpSrc+g_D_778[k][3]);
				mean[k] += *(lpSrc+g_D_778[k][4]);
				mean[k] += *(lpSrc+g_D_778[k][5]);
				mean[k] += *(lpSrc+g_D_778[k][6]);
				mean[k] = mean[k] / 7;                                                                       //求像素点在7x7的矩阵内的八个方向上各自的均值 （注意起始点的位置）

				var[k] += ((*(lpSrc+g_D_778[k][0]))-mean[k]) * ((*(lpSrc+g_D_778[k][0]))-mean[k]);
				var[k] += ((*(lpSrc+g_D_778[k][1]))-mean[k]) * ((*(lpSrc+g_D_778[k][1]))-mean[k]);
				var[k] += ((*(lpSrc+g_D_778[k][2]))-mean[k]) * ((*(lpSrc+g_D_778[k][2]))-mean[k]);
				var[k] += ((*(lpSrc+g_D_778[k][3]))-mean[k]) * ((*(lpSrc+g_D_778[k][3]))-mean[k]);
				var[k] += ((*(lpSrc+g_D_778[k][4]))-mean[k]) * ((*(lpSrc+g_D_778[k][5]))-mean[k]);
				var[k] += ((*(lpSrc+g_D_778[k][5]))-mean[k]) * ((*(lpSrc+g_D_778[k][5]))-mean[k]);
				var[k] += ((*(lpSrc+g_D_778[k][6]))-mean[k]) * ((*(lpSrc+g_D_778[k][6]))-mean[k]);
				var[k] = var[k] / 7;                                                                         //求像素点在7x7的矩阵内的八个方向上各自的方差 （注意起始点的位置）
			}
			varmax = var[0];
			varmin = var[0];
			meanmax = mean[0]; 
//			meanmin = mean[0];
			
			for (k = 1; k < 8; k++)
			{
				if (var[k] > varmax)
					varmax = var[k];
				if (var[k] < varmin)
					varmin = var[k];
				if (mean[k] > meanmax)
					meanmax = mean[k];
//				if (mean[k] < meanmin)
//					meanmin = mean[k];
			}                                                                                                  //求像素点在7x7的矩阵内的八个方向上最大及最小的均值和方差 （注意起始点的位置）

			if (meanmax < 252 || varmax - varmin > 2)
			{
				varRange = varRange + varmax - varmin;
				RangeCnt++;
				count+=16;
			}
		}		
	}

	AreaRatio = count * 100 / TOTAL_LENGTH;                                                                   //求面积比
	varRange = varRange / RangeCnt;                                                                           //求所有点最大方差和最小方差的平均值                                                                                                       //求直方图中点数最多的灰度值

	reVal[1] = AreaRatio;  //面积比例
//	reVal[2] = varRange;   //方向场方差范围，清晰程度

	if ((AreaRatio < AreaTH)||(varRange < DirVarTh))
	{
		reVal[0] = 0xff;
	}
	else
	{
		reVal[0] = 0x01;
	}
	
	#if (defined(PC_IMAGE_DEBUG))
		process_time.image_quality_test = time;
	#endif
	
	return;
}

 //归一化到指定的均值方差范围内
//输入参数：
//	输入图像 unsigned char* lpDIBBits
//输出参数：
//	输出图像 unsigned char* lpDataOut  归一化图像数据
//备注:
void myImageNormalize(unsigned char *lpDIBBits)//, unsigned char *lpDataOut
{
	// 临时变量
	unsigned short i = 0, j = 0;
	
	unsigned char orgMean = 0;
	signed int    val = 0;
	
	unsigned int coeff = 0;
	
	unsigned int count = 0;

	// 灰度映射表
	unsigned short lCount[256] = { 0 };

	// 图像归一后的均值和方差
	unsigned char destMean = 128;                                        //输出图像每一个pixel为8个bit，灰度范围为0到255，要将图像的均值归一到中值128，
	unsigned int  destVar = 10000;                                       //方差归一到10000（经验值）
	
	signed short temp = 0;
	
	#if (defined(PC_IMAGE_DEBUG))
		time = 0;
	#endif	

	// 重置计数为0
	memset(lCount,0,256*sizeof(unsigned short));

	// 计算各个灰度值的数量
	i = G_HEIGHT * G_WIDTH;
	for (j = 0; j < i; j++)
	{
		(lCount[(*(lpDIBBits+j))])++;
	}                                                                  //求直方图lCount[256]

	val = 0;count = 0;
	// 当前图像均值orgMean
	for (i = 0; i<252; i++)
	{
		val += i * lCount[i];
		count += lCount[i];
	}
	val = val / count;
	orgMean = (unsigned char)val;                                                               //求图像均值

	// 当前图像标准差orgSigma
	val = 0;
	for (i = 0; i<252; i++)
	{
		val += lCount[i] * (i - orgMean)*(i - orgMean);
	}
	val = val / count;                                                             							//求图像的方差                                                                         

	coeff = (signed int)sqrt(destVar / val);                                                           //为什么要用(destVar / val)？  //将图像扩展到方差为destVar的范围
	
	if(coeff<2)
		coeff = 2;                          // coeff = 0 图片会变成纯色
																				// coeff = 1 图片会在原来的灰度基础上整体做偏移
	                                      // 要有归一的效果，coeff至少要大于等于2

	i = G_HEIGHT * G_WIDTH;
	for (j = 0; j < i; j++)
	{
		if((*(lpDIBBits+j))<252)
		{
			temp = destMean + coeff * ((*(lpDIBBits+j)) - orgMean);
			if(temp<0)
				*(lpDIBBits+j) = 0;
			else if(temp>255)
				*(lpDIBBits+j) = 255;
			else
				*(lpDIBBits+j) = (unsigned char)temp;                                       //扩大图像的细节？在destMean上下浮动？
		}
		else
		{
				*(lpDIBBits+j) = 255;
		}
	}
	
	#if (defined(PC_IMAGE_DEBUG))
		process_time.image_nomalize_test = time;
		nomalize_para.orgmean = orgMean;
		nomalize_para.var = val;
		nomalize_para.coeff = coeff;
	#endif

}

/*************************************************************************************/
 
//均值滤波 逐点均衡化 得到高频信息图//
//输入参数：
//	输入图像   unsigned char *guiyihuaBmp 归一化图像数据
//  滤波器大小 unsigned int varfilter
//输出参数：
//	输出图像   unsigned char *pOutput  均衡化图像数据
signed char mySmoothFilter(unsigned char *guiyihuaBmp,  unsigned int varfilter)
{
	signed int i = 0;
	signed int j = 0;
	signed int ii = 0;
//	signed int jj = 0;
	
	unsigned int tpnum = varfilter*varfilter;
	unsigned int sum = 0;
	unsigned int sum_temp = 0;

	int min_value = 0;
	int value_num = 0;
	int temp = 0;
	int historam_num = 0;
	
	unsigned char *pOutput=NULL;
	unsigned char *pSrc = NULL;	
	unsigned char *pDes = NULL;
	unsigned char *temp_p = NULL;
	
	unsigned char tempaver = 0;
//	unsigned char tempvalue = 0;
	

	#if (defined(PC_IMAGE_DEBUG))
		time = 0;
	#endif	
	
	pOutput = (unsigned char *)malloc(G_HEIGHT*G_WIDTH);
	if(!pOutput)
	{
		return Malloc_failed;
	}
	memset(pOutput,255,G_HEIGHT*G_WIDTH);
	
	pSrc = guiyihuaBmp;	
	pDes = pOutput+ ((4 * G_WIDTH) + 4);
	
	// 计算第一个方框的值
	sum_temp = 0;
	
	for(i=0;i<varfilter;i++)
	{
		  temp_p = guiyihuaBmp+g_p_off_9x9[i];

			sum_temp += *(temp_p);
			sum_temp += *(temp_p+1);
			sum_temp += *(temp_p+2);
			sum_temp += *(temp_p+3);
			sum_temp += *(temp_p+4);
			sum_temp += *(temp_p+5);
			sum_temp += *(temp_p+6);
			sum_temp += *(temp_p+7);	
			sum_temp += *(temp_p+8);			
	}
	sum = sum_temp;	
	(*pDes) = (sum_temp + (tpnum >> 1)) / tpnum;
	pSrc++;	
	pDes++;

	// 计算第一行所有方框的值，并求均值
	for(j=1;j<G_WIDTH-varfilter;j++)
	{
		sum_temp += *(pSrc+g_p_r_9[0]);
		sum_temp += *(pSrc+g_p_r_9[1]);
		sum_temp += *(pSrc+g_p_r_9[2]);
		sum_temp += *(pSrc+g_p_r_9[3]);
		sum_temp += *(pSrc+g_p_r_9[4]);
		sum_temp += *(pSrc+g_p_r_9[5]);
		sum_temp += *(pSrc+g_p_r_9[6]);
		sum_temp += *(pSrc+g_p_r_9[7]);
		sum_temp += *(pSrc+g_p_r_9[8]);
		
		sum_temp -= *(pSrc+g_p_l_9[0]);
		sum_temp -= *(pSrc+g_p_l_9[1]);
		sum_temp -= *(pSrc+g_p_l_9[2]);
		sum_temp -= *(pSrc+g_p_l_9[3]);
		sum_temp -= *(pSrc+g_p_l_9[4]);
		sum_temp -= *(pSrc+g_p_l_9[5]);
		sum_temp -= *(pSrc+g_p_l_9[6]);
		sum_temp -= *(pSrc+g_p_l_9[7]);
		sum_temp -= *(pSrc+g_p_l_9[8]);

		(*pDes) = (sum_temp + (tpnum >> 1)) / tpnum;
		pSrc++;	
		pDes++;
	}
	
	// 计算第二行以后所有方框的值，并求均值
	for (i = 1; i < G_HEIGHT-varfilter; i++)
	{
		// 将指针更新到guiyihuaBmp图像和pOutput图像每一行的起点
		pSrc += varfilter;
		pDes += varfilter;
		
		// 利用上一行第一个方框的和求取本行第一个方框的和及均值
		sum += *(pSrc+g_p_d_9[0]);
		sum += *(pSrc+g_p_d_9[1]);
		sum += *(pSrc+g_p_d_9[2]);
		sum += *(pSrc+g_p_d_9[3]);
		sum += *(pSrc+g_p_d_9[4]);
		sum += *(pSrc+g_p_d_9[5]);
		sum += *(pSrc+g_p_d_9[6]);
		sum += *(pSrc+g_p_d_9[7]);
		sum += *(pSrc+g_p_d_9[8]);
		
		sum -= *(pSrc+g_p_u_9[0]);
		sum -= *(pSrc+g_p_u_9[1]);
		sum -= *(pSrc+g_p_u_9[2]);
		sum -= *(pSrc+g_p_u_9[3]);
		sum -= *(pSrc+g_p_u_9[4]);
		sum -= *(pSrc+g_p_u_9[5]);
		sum -= *(pSrc+g_p_u_9[6]);
		sum -= *(pSrc+g_p_u_9[7]);
		sum -= *(pSrc+g_p_u_9[8]);
		
		sum_temp = sum;	
		(*pDes) = (sum_temp + (tpnum >> 1)) / tpnum;
		pSrc++;	
		pDes++;
		
		// 计算本行剩余所有方框的值，并求均值
		for (j = 1; j < G_WIDTH-varfilter; j++)
		{
			sum_temp += *(pSrc+g_p_r_9[0]);
			sum_temp += *(pSrc+g_p_r_9[1]);
			sum_temp += *(pSrc+g_p_r_9[2]);
			sum_temp += *(pSrc+g_p_r_9[3]);
			sum_temp += *(pSrc+g_p_r_9[4]);
			sum_temp += *(pSrc+g_p_r_9[5]);
			sum_temp += *(pSrc+g_p_r_9[6]);
			sum_temp += *(pSrc+g_p_r_9[7]);
			sum_temp += *(pSrc+g_p_r_9[8]);
			
			sum_temp -= *(pSrc+g_p_l_9[0]);
			sum_temp -= *(pSrc+g_p_l_9[1]);
			sum_temp -= *(pSrc+g_p_l_9[2]);
			sum_temp -= *(pSrc+g_p_l_9[3]);
			sum_temp -= *(pSrc+g_p_l_9[4]);
			sum_temp -= *(pSrc+g_p_l_9[5]);
			sum_temp -= *(pSrc+g_p_l_9[6]);
			sum_temp -= *(pSrc+g_p_l_9[7]);
			sum_temp -= *(pSrc+g_p_l_9[8]);

			(*pDes) = (sum_temp + (tpnum >> 1)) / tpnum;
			pSrc++;	
			pDes++;			
		}
	}
	
	#if (defined(PC_IMAGE_DEBUG))
		process_time.image_smooth_filter1 = time;	
	#endif
	
//	#if (defined(PC_IMAGE_DEBUG))
//		custom_hid_report_recive(&usb_device_dev);
//	#endif
//	#if (defined(PC_IMAGE_DEBUG))
//		custom_hid_report_send(&usb_device_dev, pOutput, 192*192);
//	#endif
//	#if (defined(PC_IMAGE_DEBUG))
//		custom_hid_report_recive(&usb_device_dev);
//	#endif	

	#if (defined(PC_IMAGE_DEBUG))
		time = 0;
	#endif	
	
	//求取最小值
	min_value = 255;
	i = G_HEIGHT*G_WIDTH;
	for (j = 0; j < i; j++)
	{
		  temp = (signed int)(*(guiyihuaBmp+j)) - (signed int)(*(pOutput+j)) ;
			if(temp < min_value)
				min_value = temp;
	}
	for (j = 0; j < i; j++)
	{
		temp = (((signed int)(*(guiyihuaBmp+j)) - (signed int)(*(pOutput+j))) - min_value);
		//所有的数据调整到0以上
		if(temp>255) 
			*(pOutput + j) = 255;
		else
		  *(pOutput + j) = (unsigned char)temp;
	}

	#if (defined(PC_IMAGE_DEBUG))
		process_time.image_smooth_filter2 = time;
	#endif
	
//	#if (defined(PC_IMAGE_DEBUG))
//		custom_hid_report_recive(&usb_device_dev);
//	#endif
//	#if (defined(PC_IMAGE_DEBUG))
//		custom_hid_report_send(&usb_device_dev, pOutput, 192*192);
//	#endif
//	#if (defined(PC_IMAGE_DEBUG))
//		custom_hid_report_recive(&usb_device_dev);
//	#endif		
	
	#if (defined(PC_IMAGE_DEBUG))
		time = 0;
	#endif	

	//逐点均衡化//
	value_num = varfilter * varfilter;
	temp = (varfilter/2)*G_WIDTH + (varfilter/2);
	
	pSrc = pOutput;	
	pDes = guiyihuaBmp+ ((4 * G_WIDTH) + 4);
	
	memset(guiyihuaBmp,255,G_HEIGHT*G_WIDTH);
	
	for (i = 0; i < G_HEIGHT-varfilter; i++)
	{
		for (j = 0; j < G_WIDTH-varfilter; j++)
		{
			tempaver = *(pSrc+temp);
			historam_num = 0;
			
			for (ii = 0; ii < 9; ii++)
			{
				temp_p = pSrc+g_p_off_9x9[ii];
				if (*temp_p <= tempaver) historam_num++;
				if (*(temp_p+1) <= tempaver) historam_num++;				
				if (*(temp_p+2) <= tempaver) historam_num++;				
				if (*(temp_p+3) <= tempaver) historam_num++;				
				if (*(temp_p+4) <= tempaver) historam_num++;				
				if (*(temp_p+5) <= tempaver) historam_num++;				
				if (*(temp_p+6) <= tempaver) historam_num++;				
				if (*(temp_p+7) <= tempaver) historam_num++;
				if (*(temp_p+8) <= tempaver) historam_num++;
			}
			
			
//			for (ii = 0; ii < value_num; ii++)
//			{
//				if (*(pSrc+g_p_off_9x9[ii]) <= tempaver)
//				{
//					historam_num++;
//				}
//			}                                                                              //统计9x9的方框中比某像素点灰度值低的点的数量
			
			*pDes = (historam_num * 255 + (value_num >> 1)) / value_num ;
			pSrc++;
			pDes++;
		}
		pSrc += varfilter;
		pDes += varfilter;
	}
	
	#if (defined(PC_IMAGE_DEBUG))
		process_time.image_smooth_filter3 = time;
	#endif	
	
	free(pOutput);
	return Func_success;
}

/*************************************************************************************/

/*************************************************************************************
 
//均值滤波 逐点均衡化 得到高频信息图//
//输入参数：
//	输入图像   unsigned char *guiyihuaBmp 归一化图像数据
//  滤波器大小 unsigned int varfilter
//输出参数：
//	输出图像   unsigned char *pOutput  均衡化图像数据
signed char mySmoothFilter(unsigned char *guiyihuaBmp,  unsigned int varfilter)
{
	signed int i = 0;
	signed int j = 0;
	signed int ii = 0;
	signed int jj = 0;
	
	unsigned int tpnum = varfilter*varfilter;
	unsigned int sum = 0;
	unsigned int sum_temp = 0;

	int min_value = 0;
	int tsize = 5;
	int block = 0;
	int value_num = 0;
	int temp = 0;
	int tempaver = 0;
	int historam_num = 0;
	
	int idex=0;
	
	unsigned char *pOutput=NULL;
	unsigned char *pSrc = NULL;	
	unsigned char *pDes = NULL;
	
	pOutput = (unsigned char *)malloc(G_HEIGHT*G_WIDTH);
	if(!pOutput)
	{
		return Malloc_failed;
	}
//	memset(pOutput,255,G_HEIGHT*G_WIDTH);
	
	pSrc = guiyihuaBmp;	
	pDes = pOutput+ ((4 * G_WIDTH) + 4);
	
	// 计算第一个方框的值
	sum_temp = 0;
	for(i=0;i<varfilter;i++)
	{
		for(j=0;j<varfilter;j++)
		{
			sum_temp += *(guiyihuaBmp + g_p_off[i][j]);
		}
	}
	sum = sum_temp;	
	(*pDes) = (sum_temp + (tpnum >> 1)) / tpnum;
	pSrc++;	
	pDes++;

	// 计算第一行所有方框的值，并求均值
	for(j=1;j<G_WIDTH-varfilter;j++)
	{
		sum_temp += *(pSrc+g_p_r_9[0]);
		sum_temp += *(pSrc+g_p_r_9[1]);
		sum_temp += *(pSrc+g_p_r_9[2]);
		sum_temp += *(pSrc+g_p_r_9[3]);
		sum_temp += *(pSrc+g_p_r_9[4]);
		sum_temp += *(pSrc+g_p_r_9[5]);
		sum_temp += *(pSrc+g_p_r_9[6]);
		sum_temp += *(pSrc+g_p_r_9[7]);
		sum_temp += *(pSrc+g_p_r_9[8]);
		
		sum_temp -= *(pSrc+g_p_l_9[0]);
		sum_temp -= *(pSrc+g_p_l_9[1]);
		sum_temp -= *(pSrc+g_p_l_9[2]);
		sum_temp -= *(pSrc+g_p_l_9[3]);
		sum_temp -= *(pSrc+g_p_l_9[4]);
		sum_temp -= *(pSrc+g_p_l_9[5]);
		sum_temp -= *(pSrc+g_p_l_9[6]);
		sum_temp -= *(pSrc+g_p_l_9[7]);
		sum_temp -= *(pSrc+g_p_l_9[8]);

		(*pDes) = (sum_temp + (tpnum >> 1)) / tpnum;
		pSrc++;	
		pDes++;
	}
	
	// 计算第二行以后所有方框的值，并求均值
	for (i = 1; i < G_HEIGHT-varfilter; i++)
	{
		// 将指针更新到guiyihuaBmp图像和pOutput图像每一行的起点
		pSrc += varfilter;
		pDes += varfilter;
		
		// 利用上一行第一个方框的和求取本行第一个方框的和及均值
		sum += *(pSrc+g_p_d_9[0]);
		sum += *(pSrc+g_p_d_9[1]);
		sum += *(pSrc+g_p_d_9[2]);
		sum += *(pSrc+g_p_d_9[3]);
		sum += *(pSrc+g_p_d_9[4]);
		sum += *(pSrc+g_p_d_9[5]);
		sum += *(pSrc+g_p_d_9[6]);
		sum += *(pSrc+g_p_d_9[7]);
		sum += *(pSrc+g_p_d_9[8]);
		
		sum -= *(pSrc+g_p_u_9[0]);
		sum -= *(pSrc+g_p_u_9[1]);
		sum -= *(pSrc+g_p_u_9[2]);
		sum -= *(pSrc+g_p_u_9[3]);
		sum -= *(pSrc+g_p_u_9[4]);
		sum -= *(pSrc+g_p_u_9[5]);
		sum -= *(pSrc+g_p_u_9[6]);
		sum -= *(pSrc+g_p_u_9[7]);
		sum -= *(pSrc+g_p_u_9[8]);
		
		sum_temp = sum;	
		(*pDes) = (sum_temp + (tpnum >> 1)) / tpnum;
		pSrc++;	
		pDes++;
		
		// 计算本行剩余所有方框的值，并求均值
		for (j = 1; j < G_WIDTH-varfilter; j++)
		{
			sum_temp += *(pSrc+g_p_r_9[0]);
			sum_temp += *(pSrc+g_p_r_9[1]);
			sum_temp += *(pSrc+g_p_r_9[2]);
			sum_temp += *(pSrc+g_p_r_9[3]);
			sum_temp += *(pSrc+g_p_r_9[4]);
			sum_temp += *(pSrc+g_p_r_9[5]);
			sum_temp += *(pSrc+g_p_r_9[6]);
			sum_temp += *(pSrc+g_p_r_9[7]);
			sum_temp += *(pSrc+g_p_r_9[8]);
			
			sum_temp -= *(pSrc+g_p_l_9[0]);
			sum_temp -= *(pSrc+g_p_l_9[1]);
			sum_temp -= *(pSrc+g_p_l_9[2]);
			sum_temp -= *(pSrc+g_p_l_9[3]);
			sum_temp -= *(pSrc+g_p_l_9[4]);
			sum_temp -= *(pSrc+g_p_l_9[5]);
			sum_temp -= *(pSrc+g_p_l_9[6]);
			sum_temp -= *(pSrc+g_p_l_9[7]);
			sum_temp -= *(pSrc+g_p_l_9[8]);

			(*pDes) = (sum_temp + (tpnum >> 1)) / tpnum;
			pSrc++;	
			pDes++;			
		}
	}
	
	
	
	#if (defined(PC_IMAGE_DEBUG))
		process_time.image_smooth_filter1 = time;	
	#endif
	
	#if (defined(PC_IMAGE_DEBUG))
		custom_hid_report_recive(&usb_device_dev);
	#endif
	#if (defined(PC_IMAGE_DEBUG))
		custom_hid_report_send(&usb_device_dev, pOutput, 192*192);
	#endif
	#if (defined(PC_IMAGE_DEBUG))
		custom_hid_report_recive(&usb_device_dev);
	#endif		
	
	//求取最小值
	min_value = 255;
	i = G_HEIGHT*G_WIDTH;
	for (j = 0; j < i; j++)
	{
		  temp = (signed int)(*(guiyihuaBmp+j)) - (signed int)(*(pOutput+j)) ;
			if(temp < min_value)
				min_value = temp;
	}
	for (j = 0; j < i; j++)
	{
		temp = (((signed int)(*(guiyihuaBmp+j)) - (signed int)(*(pOutput+j))) - min_value);
		//所有的数据调整到0以上
		if(temp>255) 
			*(pOutput + j) = 255;
		else
		  *(pOutput + j) = (unsigned char)temp;
	}
	
	#if (defined(PC_IMAGE_DEBUG))
		custom_hid_report_recive(&usb_device_dev);
	#endif
	#if (defined(PC_IMAGE_DEBUG))
		custom_hid_report_send(&usb_device_dev, pOutput, 192*192);
	#endif
	#if (defined(PC_IMAGE_DEBUG))
		custom_hid_report_recive(&usb_device_dev);
	#endif		
	
	time = 0;

	//逐点均衡化//
	tsize = 4;
	block = tsize * 2;
	value_num = (block + 1) * (block + 1);
	for (i = 4; i < G_HEIGHT-4; i++)
	{
		for (j = 4; j < G_WIDTH-4; j++)
		{
			tempaver = pOutput[i * G_WIDTH + j];
			historam_num = 0;
			
			for (ii = -4; ii <= 4; ii++)
			{
				for (jj = -4; jj <= 4; jj++)
				{
					if (pOutput[(ii+i) * G_WIDTH + jj+j] <= tempaver)
					{
						historam_num++;
					}
				}
			}                                                                              //统计9x9的方框中比某像素点灰度值低的点的数量
			
			tempaver = (historam_num * 255 + (value_num >> 1)) / value_num ;
			guiyihuaBmp[i * G_WIDTH + j] = tempaver;
			
		}
	}

	free(pOutput);
	return Func_success;
}

*************************************************************************************/

/*************************************************************************************
//均值滤波 逐点均衡化 得到高频信息图//
//输入参数：
//	输入图像   unsigned char *guiyihuaBmp 归一化图像数据
//  滤波器大小 unsigned int varfilter
//输出参数：
//	输出图像   unsigned char *pOutput  均衡化图像数据
signed char mySmoothFilter(unsigned char *guiyihuaBmp,  unsigned int varfilter)
{
	signed short i = 0;
	signed short j = 0;
	signed short ii = 0;
	signed short jj = 0;
	signed short uplimit = varfilter-(varfilter/2);
	signed short dowmlimit = (varfilter/2)-varfilter+1;
	unsigned short temp_i = 0;
	unsigned short temp_j = 0;
	
	unsigned int tpnum = varfilter*varfilter;
	unsigned int s = 0;

	int min_value = 0;
	int tsize = 5;
	int block = 0;
	int value_num = 0;
	int leftx = 0;
	int rightx = 0;
	int upy = 0;
	int downy = 0;
	int temp = 0;
	int tempaver = 0;
	int historam_num = 0;
	
	int idex=0;
	
	unsigned char *pOutput=NULL;
	
	pOutput = (unsigned char *)malloc(G_HEIGHT*G_WIDTH);
	if(!pOutput)
	{
		return Malloc_failed;
	}
	
	for (i = 4; i < G_HEIGHT-4; i++)
	{
		for (j = 4; j < G_WIDTH-4; j++)
		{
			s = 0;
			for(ii=dowmlimit;ii<uplimit;ii++)
			{
				//for(jj=dowmlimit;jj<uplimit;)
				{
					jj=dowmlimit;
					idex = (i+ii)*G_WIDTH+j;
					s += guiyihuaBmp[(idex+jj)]; jj++;
					s += guiyihuaBmp[(idex+jj)]; jj++;
					s += guiyihuaBmp[(idex+jj)]; jj++;
					s += guiyihuaBmp[(idex+jj)]; jj++;
					s += guiyihuaBmp[(idex+jj)]; jj++;
					s += guiyihuaBmp[(idex+jj)]; jj++;
					s += guiyihuaBmp[(idex+jj)]; jj++;
					s += guiyihuaBmp[(idex+jj)]; jj++;
					s += guiyihuaBmp[(idex+jj)]; jj++;
				}
			}
			pOutput[i * G_WIDTH + j] = (s + (tpnum >> 1)) / tpnum;
		}
	} 
	
#if (defined(PC_IMAGE_DEBUG))
	process_time.image_quality_test = time;
#endif	
	
	//求取最小值
	min_value = 255;
	for (i = 0; i < G_HEIGHT; i++)
	{
		for (j = 0; j < G_WIDTH; j++)
		{
			if(min_value > (((int)guiyihuaBmp[i * G_WIDTH + j]) - ((int)(pOutput[i * G_WIDTH + j]))))
				min_value = ((int)guiyihuaBmp[i * G_WIDTH + j]) - ((int)(pOutput[i * G_WIDTH + j]));
		}
	}
	
	for (i = 0; i < G_HEIGHT; i++)
	{
		for (j = 0; j < G_WIDTH; j++)
		{
			temp = (((int)guiyihuaBmp[i * G_WIDTH + j]) - ((int)(pOutput[i * G_WIDTH + j])) - min_value);
			//所有的数据调整到0以上
			if(temp>255)
				temp = 255;
			pOutput[i * G_WIDTH + j] = (unsigned char)temp;
		}
	}

	//逐点均衡化//
	tsize = 4;
	block = tsize * 2;
	value_num = (block + 1) * (block + 1);
	for (i = 4; i < G_HEIGHT-4; i++)
	{
		for (j = 4; j < G_WIDTH-4; j++)
		{
//			leftx = j - tsize;
//			rightx = j + tsize;
//			upy = i - tsize;
//			downy = i + tsize;
//			if (leftx < 0)
//			{
//				leftx = 0;
//				rightx = tsize * 2;
//			}
//			if (rightx >= G_WIDTH)
//			{
//				rightx = G_WIDTH - 1;
//				leftx = G_WIDTH - 2 * tsize - 1;
//			}
//			if (upy < 0)
//			{
//				upy = 0;
//				downy = tsize * 2;
//			}
//			if (downy >= G_HEIGHT)
//			{
//				downy = G_HEIGHT - 1;
//				upy = G_HEIGHT - 1 - 2 * tsize;
//			}                                                                               //移动11x11的方框至图像内部

			tempaver = pOutput[i * G_WIDTH + j];
			historam_num = 0;
			
			for (ii = -4; ii <= 4; ii++)
			{
				for (jj = -4; jj <= 4; jj++)
				{
					if (pOutput[(ii+i) * G_WIDTH + jj+j] <= tempaver)
					{
						historam_num++;
					}
				}
			}                                                                              //统计11x11的方框中比某像素点灰度值低的点的数量
			
			tempaver = (historam_num * 255 + (value_num >> 1)) / value_num ;

			if (tempaver > 255)
			{
				guiyihuaBmp[i * G_WIDTH + j] = 255;
			}
			else
			{
				guiyihuaBmp[i * G_WIDTH + j] = tempaver;
			}
		}
	}

	free(pOutput);
	return Func_success;
}

**********************************************************************************/


//功能：图像前端处理 得到描述值和特征点个数、极小值个数
//输入参数：
//  图像数据       unsigned char* pImageBuf
//输出参数：
//	极小值个数     unsigned int *leastnum
//  描述值数组     signed short *describdata
//	描述值个数     unsigned int DescribNum
signed char myFingerPreProcess(unsigned char* pImageBuf,unsigned int *DescribNum,unsigned int *leastnum,signed short *describdata)
{
	/********  存储图像质量检测时得到的图像信息  ********/
	unsigned char reVal[6] = {0, 0, 0, 0, 0, 0};	
	
//	/**************  归一化之后的图像指针  **************/
//	unsigned char *NomalizeImage = 0;	
	
//	/************** 均值滤波之后的图像指针 **************/
//	unsigned char *SmoothFilterImage = 0;	
	

  //第一步图像质量检测
	myImageQuality(pImageBuf, reVal);
	if (reVal[0] == 255)
	{
		return Image_quality_low;
	}
	
	// 图像归一化之后的数据写回原始图像数组
	myImageNormalize(pImageBuf);
	
	#if (defined(PC_IMAGE_DEBUG))
		custom_hid_report_recive(&usb_device_dev);
	#endif
	#if (defined(PC_IMAGE_DEBUG))
		custom_hid_report_send(&usb_device_dev, pImageBuf, 192*192);
	#endif
	#if (defined(PC_IMAGE_DEBUG))
		custom_hid_report_recive(&usb_device_dev);
	#endif	
	
	
	//第三步图像均值滤波,将滤波之后的图像写回原始数组
	mySmoothFilter(pImageBuf,9);
	
	#if (defined(PC_IMAGE_DEBUG))
		custom_hid_report_recive(&usb_device_dev);
	#endif
	#if (defined(PC_IMAGE_DEBUG))
		custom_hid_report_send(&usb_device_dev, pImageBuf, 192*192);
	#endif
	#if (defined(PC_IMAGE_DEBUG))
		custom_hid_report_recive(&usb_device_dev);
	#endif	
	
	return Func_success;
}

//功能：指纹注册功能函数
signed char FingerEnroll(unsigned char *pImageBuf, unsigned short fingerid)
{
	unsigned int interestnum = 0; 			//描述值个数
	unsigned int leastnum = 0;    			//极小值个数
	signed short *intrestpoint = NULL; 	//描述子
	
	signed char outcome = 0;

	intrestpoint = (signed short *)malloc((MAX_MINUTIAE *COLMNUM) * sizeof(signed short));  //
	if (intrestpoint == NULL)
	{
		return Malloc_failed;
	}

	//指纹前端处理 
	outcome = myFingerPreProcess(pImageBuf, &interestnum, &leastnum, intrestpoint);
	if(Func_success != outcome)
	{
		free(intrestpoint);
		return outcome;
	}
	free(intrestpoint);
	return Func_success;
}


#endif
