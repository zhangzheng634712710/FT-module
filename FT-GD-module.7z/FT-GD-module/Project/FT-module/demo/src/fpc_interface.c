#include "fpc_interface.h"

FPC_SENSOR_STATUS FPC_SENSOR_INIT(void)
{
	fpc1020am_init();
	return FPC_SENSOR_OK;
}

FPC_SENSOR_STATUS WHETHER_FINGER_IS_ON_CHIP(void)
{
	return (FPC_SENSOR_STATUS)wether_finger_is_on_chip();
}

FPC_SENSOR_STATUS READ_ONE_IMAGE(uint8_t *image_pointer,uint16_t lenth)
{
	return (FPC_SENSOR_STATUS)capture_image(image_pointer,lenth);
}

FPC_SENSOR_STATUS DETECT_AND_READ_ONE_IMAGE(uint8_t *image_pointer,uint16_t lenth)
{
	return (FPC_SENSOR_STATUS)detect_and_capture_image(image_pointer,lenth);
}
	
