/* Include my libraries here */
#ifndef FINGERCHIPSPIFUNC_H_
#define FINGERCHIPSPIFUNC_H_

#define CS_UP						1
#define CS_DOWN					0
#define CHIP_SET				1
#define CHIP_RESET			0

typedef enum 
{
	FPC_SENSOR_OK = 0,
	FPC_SENSOR_ERROR,
	FPC_SENSOR_DETECTED,
  FPC_SENSOR_NOT_DETECTED,
}FPC_SENSOR_STATUS;


/*******************************************************************************************************************************/
// FPC 1020am moudle功能函数的依赖接口，若要使用FPC sensor的功能函数，需先在外部实现这些依赖接口，然后再注册进来，
// 注册函数为 fpc_func_register(FPC_1020_HANDLE_TypeDef *sensor_handle)
/*******************************************************************************************************************************/
typedef struct {
                                                                          /* SPI CS 管脚操作函数     1：表示将管脚拉高，0：表示将管脚拉低 */
	void (*spics)(unsigned char up_or_down);

                                                                          /* SPI 收发函数  发送n个字节，同时接受n个字节 写回同一个buffer地址 */
	void (*spi_transmit_n_bytes)(unsigned char *buffer,unsigned short len);

                                                                          /* 获取指纹sensor irq管脚状态的函数    返回1，表示管脚为高电平，返回0，表示管脚为低电平， */
	unsigned char (*irq_state)(void);

                                                                          /* 芯片复位管脚操作函数    1：表示将管脚拉高，0：表示将管脚拉低 */
	void (*chipreset)(unsigned char set_or_reset);

                                                                          /* 毫秒延时函数声明  num：延时时间 */
	void (*delayms)(unsigned int num);

}FPC_1020_HANDLE_TypeDef;


/* spi reset irq time 功能注册 */
void fpc_func_register(FPC_1020_HANDLE_TypeDef *sensor_handle);

/*******************************************************************************************************************************/
// FPC 1020am moudle功能函数，若要使用这些功能函数，需先注册底层的依赖函数
/*******************************************************************************************************************************/

/* 芯片初始化，然后进入休眠 */
void fpc1020am_init(void);

/* 判断手指是否按压在芯片上 */
FPC_SENSOR_STATUS wether_finger_is_on_chip(void);

/* 捕获一张图像（不检测手指是否按压在芯片上）*/
FPC_SENSOR_STATUS capture_image(unsigned char *image_data,unsigned short lenth);

/* 等待手指按压，并获取一张指纹图像，若手指在5秒钟之内未按压，则退出，不再捕获图像 */
FPC_SENSOR_STATUS detect_and_capture_image(unsigned char *image_data,unsigned short lenth);

#endif
