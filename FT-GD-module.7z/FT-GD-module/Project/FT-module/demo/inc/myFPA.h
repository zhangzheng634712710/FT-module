#ifndef MYFPA_H_
#define MYFPA_H_

#include <stdint.h>

/*********************************************************************************************************/
//已修改的地方：
//	1、图像大小G_HEIGHT/G_WIDTH
//	2、特征点数量MAX_MINUTIAE/COLMNUM
//  3、将图像质量检测中的阈值设成宏定义
//	4、将函数的返回值设置成宏定义
/*********************************************************************************************************/

#define     MAXMINUTIANUM			60			// 最大特征点数

//图像大小
#define G_HEIGHT           192
#define G_WIDTH            192
#define TOTAL_LENGTH       (G_HEIGHT*G_WIDTH)   //指纹总数

#define	WetTH       		70
#define	DryTH       		200
#define	DirVarTh    		100
#define	AreaTH      	  60

#define Func_success         1
#define Image_quality_low	  -2
#define Malloc_failed		    -3
#define Param_error         -4 


//图像反色
void image_inverte(unsigned char *data,uint16_t lenth);

//功能：图像前端处理 得到描述值和特征点个数、极小值个数
signed char myFingerPreProcess(unsigned char* pImageBuf, unsigned int *DescribNum, unsigned int *leastnum, signed short *describdata);

//功能：将图像归一化到指定的均值方差范围内
void myImageNormalize(unsigned char *lpDIBBits); //, unsigned char *lpDataOut

/*均值滤波 逐点均衡化 得到高频信息图*/
signed char mySmoothFilter(unsigned char *guiyihuaBmp, unsigned int varfilter);

//功能：指纹注册功能函数
signed char FingerEnroll(unsigned char *pImageBuf, unsigned short fingerid);

#endif

