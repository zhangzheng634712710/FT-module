#include "Matrix_int.h"
#include <stdio.h>
#include <stdlib.h>
#include "public.h"

#define equal(a, b) (a==b)

static void swap(int *a, int *b)
{
	int m;
	m = *a;
	*a = *b;
	*b = m;
}

static void perm_int(int list[], int k, int m, int* p, Matrix_int* mat, int* det)
{
	int i;

	if (k > m)
	{
		int res = mat->element[0][list[0]];

		for (i = 1; i < mat->row; i++) {
			res *= mat->element[i][list[i]];
		}

		if (*p & 1) { /*%2 - > &1*/
					  //odd is negative
			*det -= res;
		}
		else {
			//even is positive
			*det += res;
		}
	}
	else {
		// if the element is 0, we don't need to calculate the value for this permutation
		if (!equal(mat->element[k][list[k]], 0))
			perm_int(list, k + 1, m, p, mat, det);
		for (i = k + 1; i <= m; i++)
		{
			if (equal(mat->element[k][list[i]], 0))
				continue;
			swap(&list[k], &list[i]);
			*p += 1;
			perm_int(list, k + 1, m, p, mat, det);
			swap(&list[k], &list[i]);
			*p -= 1;
		}
	}
}

Matrix_int* MatCreate_int(Matrix_int* mat, int row, int col)
{
	int i;

	mat->element = (int**)malloc(row * sizeof(int*));
	if (mat->element == NULL) 
	{
		return NULL;
	}
	for (i = 0; i < row; i++) 
	{
		mat->element[i] = (int*)malloc(col * sizeof(int));
		if (mat->element[i] == NULL) 
		{
			int j;
			for (j = 0; j < i; j++)
				free(mat->element[j]);
			free(mat->element);
			return NULL;
		}
	}

	mat->row = row;
	mat->col = col;

	return mat;
}

Matrix_int* MatSetVal_int(Matrix_int* mat, int* val)
{
	int row, col;

	for (row = 0; row < mat->row; row++) 
	{
		for (col = 0; col < mat->col; col++) 
		{
			mat->element[row][col] = val[col + row * mat->col];
		}
	}

	return mat;
}

void MatDelete_int(Matrix_int* mat)
{
	int i;

	for (i = 0; i<mat->row; i++)
		free(mat->element[i]);
	free(mat->element);
}

void MatDump_int(const Matrix_int* mat)
{
	int row, col;
	if (mat == NULL)
	{
		return;
	}
	printf("Mat %dx%d:\n", mat->row, mat->col);
	for (row = 0; row < mat->row; row++) 
	{
		for (col = 0; col < mat->col; col++) 
		{
			printf("%d\t", mat->element[row][col]);
		}
		printf("\n");
	}
}

// return det(mat)
int MatDet_int(Matrix_int* mat)
{
	int det = 0;
	int plarity = 0;
	int *list;
	int i;

	if (mat->row != mat->col) 
	{
		return 0;
	}


	list = (int*)malloc(sizeof(int)*mat->col);
	if (list == NULL) {
		return 0;
	}
	for (i = 0; i < mat->col; i++)
		list[i] = i;

	perm_int(list, 0, mat->row - 1, &plarity, mat, &det);
	free(list);

	return det;
}


// dst = adj(src)
Matrix_int* MatAdj_int(Matrix_int* src, Matrix_int* dst)
{
	Matrix_int smat;
	int row, col;
	int i, j, r, c;
	int det;

	if (src->row != src->col || src->row != dst->row || src->col != dst->col) 
	{
		return NULL;
	}

	MatCreate_int(&smat, src->row - 1, src->col - 1);

	for (row = 0; row < src->row; row++) 
	{
		for (col = 0; col < src->col; col++) 
		{
			r = 0;
			for (i = 0; i < src->row; i++) 
			{
				if (i == row)
					continue;
				c = 0;
				for (j = 0; j < src->col; j++) 
				{
					if (j == col)
						continue;
					smat.element[r][c] = src->element[i][j];
					c++;
				}
				r++;
			}
			det = MatDet_int(&smat);
			if ((row + col) & 1)/*% 2 -> &1*/
				det = -det;
			dst->element[col][row] = det;
		}
	}

	MatDelete_int(&smat);

	return dst;
}

// dst = src^(-1) /*odet Ϊ dst�и����ķ�ĸ,�����ĸʹdst�е�����������*/
Matrix_int* MatInv_int(Matrix_int* src, Matrix_int* dst, int *odet)
{
	Matrix_int adj_mat;
	int det;
	int row, col;


	if (src->row != src->col || src->row != dst->row || src->col != dst->col) 
	{
		return NULL;
	}

	MatCreate_int(&adj_mat, src->row, src->col);
	MatAdj_int(src, &adj_mat);
	det = MatDet_int(src);

	if (equal(det, 0)) 
	{
		MatDelete_int(&adj_mat);
		return NULL;
	}

	for (row = 0; row < src->row; row++) 
	{
		for (col = 0; col < src->col; col++)
			dst->element[row][col] = adj_mat.element[row][col];
	}

	*odet = det;

	MatDelete_int(&adj_mat);

	return dst;
}

/* dst = src1 * src2 */
Matrix_int* MatMul_int(Matrix_int* src1, Matrix_int* src2, Matrix_int* dst)
{
	int row, col;
	int i;
	int temp;

	if (src1->col != src2->row || src1->row != dst->row || src2->col != dst->col) 
	{
		return NULL;
	}

	for (row = 0; row < dst->row; row++) 
	{
		for (col = 0; col < dst->col; col++) 
		{
			temp = 0;
			for (i = 0; i < src1->col; i++) {
				temp += src1->element[row][i] * src2->element[i][col];
			}
			dst->element[row][col] = temp;
		}
	}

	return dst;
}

void MatCopy_int(Matrix_int* src, Matrix_int* dst)
{
	int row, col;
	if (src->row != dst->row || src->col != dst->col) 
	{
		return;
	}

	for (row = 0; row < src->row; row++) 
	{
		for (col = 0; col < src->col; col++)
			dst->element[row][col] = src->element[row][col];
	}
}

