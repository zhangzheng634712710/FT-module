#include "binarize.h"
#include "table_int.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "public.h"

//#define sround(x) ((int) (((x)<0) ? (x)-0.5 : (x)+0.5))
//#define trunc_dbl_precision(x, scale) ((double) (((x)<0.0) \
//                 ? ((int)(((x)*(scale))-0.5))/(scale) \
//                 : ((int)(((x)*(scale))+0.5))/(scale)))
//#ifndef M_PI
//#define M_PI		3.14159265358979323846	/* pi */
//#endif
#define NUM_DIRECTIONS          16
#define START_DIR_ANGLE         90 //(double)(M_PI/2.0)    /* 90 degrees */

/* Designates that rotated grid offsets should be relative */
/* to the grid's center.                                   */
#define RELATIVE2CENTER          0

/* Designates that rotated grid offsets should be relative */
/* to the grid's origin.                                   */
#define RELATIVE2ORIGIN          1

/* Truncate floating point precision by multiply, rounding, and then */
/* dividing by this value.  This enables consistant results across   */
/* different computer architectures.                                 */
#define TRUNC_SCALE          16384

#define DIRBIN_GRID_W            7 /*���ж�ֵ�����㴰�ڵĿ���(����)*/
#define DIRBIN_GRID_H            9 /*���ж�ֵ�����㴰�ڵĸ߶�(����)*/
#define DIRBIN_GRID_DIG          11 //sqrt(7*7 + 9*9)

/* Designates passed argument as undefined. */
#define UNDEFINED               -1

/* Map value for not well-defined directions */
#define INVALID_DIR             255

/* Definitions for 8-bit binary pixel intensities. */
#define WHITE_PIXEL            255
#define BLACK_PIXEL              0

/* Number of passes through the resulting binary image where holes */
/* of pixel length 1 in horizontal and vertical runs are filled.   */

#define NUM_FILL_HOLES           3


void Hybrid_binarize(unsigned char *idata, int width, int height, unsigned char *direction_map, unsigned char *bdata)
{
	/* ���� 0~180�� ת��Ϊ 0 ~15������, 90���Ӧ0*/
	int half_dir_num = NUM_DIRECTIONS/2;
	unsigned char max_dir_index = NUM_DIRECTIONS - 1;
	for (int y = 0; y < height; y++)
	{
		for (int x = 0; x < width; x++)
		{
			int index = y * width + x;
			unsigned char currdata = direction_map[index];
			if (currdata == 180) currdata = 0;
			
			if (currdata >= 0 && currdata <= 90)
			{
				direction_map[index] = (half_dir_num - (currdata* NUM_DIRECTIONS - 90) / 180)& max_dir_index;
			}
			else if (currdata > 90 && currdata < 180)
			{
				direction_map[index] = (NUM_DIRECTIONS + half_dir_num - (currdata * NUM_DIRECTIONS - 90) / 180)& max_dir_index;
			}
		}
	}

	/*pad_uchar_image*/
	/*bits_8to6*/
	//bits_8to6(idata, width, height);

	/*init_rotgrids*/
	ROTGRIDS *dirbingrids = NULL;
	int maxpad = UNDEFINED;
	int dirbin_grid_w = DIRBIN_GRID_W;
	int dirbin_grid_h = DIRBIN_GRID_H;
	int ret = init_rotgrids(&dirbingrids, width, height, maxpad, /*����4kB�ڴ�ռ�*/
		START_DIR_ANGLE, NUM_DIRECTIONS,dirbin_grid_w, dirbin_grid_h,RELATIVE2CENTER);
	if (ret) 
	{
		return;
	}

	/* binarize_V2 */
	/* Binarize input image based on NMAP information. */
	int bw = 0, bh = 0;
	ret = binarize_cal(&bdata, &bw, &bh, idata, width, height, direction_map, width, height, dirbingrids);

	/* Deallocate working memory. */
	free_rotgrids(dirbingrids);

	return;
}

int init_rotgrids(ROTGRIDS **optr, const int iw, const int ih, const int ipad,
	const int start_dir_angle, const int ndirs,const int grid_w, const int grid_h, const int relative2)
{
	ROTGRIDS *rotgrids;
	int theta, pi_offset;
	int dir, ix, iy, grid_size, pw, grid_pad, min_dim;
	int *grid;
	int cs, sn;
	int cx, cy;
	int fxm, fym, fx, fy;
	int ixt, iyt;
	int pad, diag;

	/* Allocate structure */
	rotgrids = (ROTGRIDS *)malloc(sizeof(ROTGRIDS));
	if (rotgrids == (ROTGRIDS *)NULL) return(-30);
	
	/* Set rotgrid attributes */
	rotgrids->ngrids = ndirs;
	rotgrids->grid_w = grid_w;
	rotgrids->grid_h = grid_h;
	rotgrids->start_angle = start_dir_angle;
	rotgrids->relative2 = relative2;

	/* Compute pad based on diagonal of the grid */
	//diag = sqrt((double)((grid_w*grid_w) + (grid_h*grid_h)));
	diag = DIRBIN_GRID_DIG;
	switch (relative2) {
	case RELATIVE2CENTER:
		/* Assumption: all grid centers reside in valid/allocated memory. */
		//pad = (diag - 1) / (double)2.0;
		pad = (diag - 1) >> 1;
		/* Need to truncate precision so that answers are consistent */
		/* on different computer architectures when rounding doubles. */
		//pad = trunc_dbl_precision(pad, TRUNC_SCALE);
		//grid_pad = sround(pad);
		grid_pad = pad;
		break;
	case RELATIVE2ORIGIN:
		/* Assumption: all grid origins reside in valid/allocated memory. */
		min_dim = min(grid_w, grid_h);
		/* Compute pad as difference between the smallest grid dimension */
		/* and the diagonal distance of the grid. */
		//pad = (diag - min_dim) / (double)2.0;
		pad = (diag - min_dim) >> 1;
		/* Need to truncate precision so that answers are consistent */
		/* on different computer architectures when rounding doubles. */
		//pad = trunc_dbl_precision(pad, TRUNC_SCALE);
		//grid_pad = sround(pad);
		grid_pad = pad;
		break;
	default:
		free(rotgrids);
		return(-31);
	}

	if (ipad == UNDEFINED)
		rotgrids->pad = grid_pad;
	else 
	{
		if (ipad < grid_pad) 
		{
			free(rotgrids);
			return(-32);
		}
		rotgrids->pad = ipad;
	}
	/* Total number of points in grid */
	grid_size = grid_w * grid_h;

	/* Compute width of "padded" image */
	pw = iw/* + (rotgrids->pad << 1)*/;

	/* Center coord of grid (0-oriented). */
	cx = (grid_w - 1) >>1;
	cy = (grid_h - 1) >>1;

	/* Allocate list of rotgrid pointers */
	rotgrids->grids = (int **)malloc(ndirs * sizeof(int *));
	if (rotgrids->grids == (int **)NULL) 
	{
		free(rotgrids);
		return(-33);
	}

	/* Pi_offset is the offset in radians from which angles are to begin. */
	pi_offset = start_dir_angle;
	/* if ndirs == 16, incr = 11.25 degrees */
	//pi_incr = M_PI / (double)ndirs;  

    /* For each direction to rotate a grid ... */
	for (dir = 0, theta = pi_offset; dir < ndirs; dir++/*, theta += pi_incr*/) 
	{
		theta = pi_offset + ((dir * 180)>>4); /*ndirs == 16*/
		/* Allocate a rotgrid �ڴ湲 7 * 9 * 16 * 4 = 4KB */
		rotgrids->grids[dir] = (int *)malloc(grid_size * sizeof(int));
		if (rotgrids->grids[dir] == (int *)NULL) 
		{
			/* Free memory allocated to this point. */
			 for (int _j = 0; _j < dir; _j++)
			 {
				free(rotgrids->grids[_j]);
			 }
			free(rotgrids);
			return(-34);
		}

		/* Set pointer to current grid */
		grid = rotgrids->grids[dir];

		/* Compute cos and sin of current angle */
		cs = cos_int_table[theta];// cos(theta);
		sn = sin_int_table[theta];// sin(theta);

		/* This next section of nested FOR loops precomputes a         */
		/* rotated grid.  The rotation is set up to rotate a GRID_W X  */
		/* GRID_H grid on its center point at C=(Cx,Cy). The current   */
		/* pixel being rotated is P=(Ix,Iy).  Therefore, we have a     */
		/* rotation transformation of point P about pivot point C.     */
		/* The rotation transformation about a pivot point in matrix   */
		/* form is:                                                    */
		/*
		+-                                                       -+
		          |             cos(T)                   sin(T)           0 |
		[Ix Iy 1] |            -sin(T)                   cos(T)           0 |
		          | (1-cos(T))*Cx + Cy*sin(T)  (1-cos(T))*Cy - Cx*sin(T)  1 |
		+-                                                       -+
		*/
		/* Multiplying the 2 matrices and combining terms yeilds the */
		/* equations for rotated coordinates (Rx, Ry):               */
		/*        Rx = Cx + (Ix - Cx)*cos(T) - (Iy - Cy)*sin(T)      */
		/*        Ry = Cy + (Ix - Cx)*sin(T) + (Iy - Cy)*cos(T)      */
		/*                                                           */
		/* Care has been taken to ensure that (for example) when     */
		/* BLOCKSIZE==24 the rotated indices stay within a centered  */
		/* 34X34 area.                                               */
		/* This is important for computing an accurate padding of    */
		/* the input image.  The rotation occurs "in-place" so that  */
		/* outer pixels in the grid are mapped at times from         */
		/* adjoining blocks.  As a result, to keep from accessing    */
		/* "unknown" memory or pixels wrapped from the other side of */
		/* the image, the input image should first be padded by      */
		/* PAD=round((DIAG - BLOCKSIZE)/2.0) where DIAG is the       */
		/* diagonal distance of the grid.                            */
		/* For example, when BLOCKSIZE==24, Dx=34, so PAD=5.         */

		/* Foreach each y coord in block ... */
		for (iy = 0; iy < grid_h; ++iy) 
		{
			/* Compute rotation factors dependent on Iy (include constant) */
			fxm = -1 * (((iy - cy) * sn));
			fym = ((iy - cy) * cs);

			/* If offsets are to be relative to the grids origin, then */
			/* we need to subtract CX and CY.                          */
			if (relative2 == RELATIVE2ORIGIN) 
			{
				fxm += cx << SIN_COS_SCAL_BIT;
				fym += cy << SIN_COS_SCAL_BIT;
			}

			/* foreach each x coord in block ... */
			for (ix = 0; ix < grid_w; ++ix) {

				/* Now combine factors dependent on Iy with those of Ix */
				fx = (fxm + ((ix - cx) * cs)) >> SIN_COS_SCAL_BIT;
				fy = (fym + ((ix - cx) * sn)) >> SIN_COS_SCAL_BIT;
				/* Need to truncate precision so that answers are consistent */
				/* on different computer architectures when rounding doubles. */
				//fx = trunc_dbl_precision(fx, TRUNC_SCALE);
				//fy = trunc_dbl_precision(fy, TRUNC_SCALE);
				//ixt = sround(fx);
				//iyt = sround(fy);
				ixt = fx;
				iyt = fy;

				/* Store the current pixels relative   */
				/* rotated offset.  Make sure to       */
				/* multiply the y-component of the     */
				/* offset by the "padded" image width! */
				*grid++ = ixt + (iyt * pw);
			}/* ix */
		}/* iy */
	}/* dir */

	*optr = rotgrids;

	return 0;
}

void free_rotgrids(ROTGRIDS *rotgrids)
{
	int i;
	for (i = 0; i < rotgrids->ngrids; i++)
		free(rotgrids->grids[i]);
	free(rotgrids->grids);
	free(rotgrids);
}

int binarize_cal(unsigned char **odata, int *ow, int *oh, unsigned char *pdata, const int pw, const int ph,
	unsigned char *direction_map, const int mw, const int mh, const ROTGRIDS *dirbingrids)
{
	int i, bw, bh, ret; /* return code */

	/* 1. Binarize the padded input image using directional block info. */
	ret = binarize_image_cal(odata, &bw, &bh, pdata, pw, ph, direction_map, mw, mh, dirbingrids);
	if (ret) return ret;

	/* 2. Fill black and white holes in binary image. */
	/* LFS scans the binary image, filling holes, 3 times. */
	bw = pw;
	bh = ph;
	for (i = 0; i < NUM_FILL_HOLES; i++)
		fill_holes_bin(*odata, bw, bh);

	/* Return binarized input image. */
	return 0;
}

int binarize_image_cal(unsigned char **odata, int *ow, int *oh, unsigned char *pdata, const int pw, const int ph,
	unsigned char *direction_map, const int mw, const int mh, const ROTGRIDS *dirbingrids)
{
	int ix, iy, bw, bh, bx, by, mapval,pad;
	unsigned char *bdata, *bptr;
	unsigned char *pptr, *spptr;

	bw = pw /*- (dirbingrids->pad << 1)*/;
	bh = ph /*- (dirbingrids->pad << 1)*/;

	bdata = *odata;

	bptr = bdata;
	pad = dirbingrids->pad;
	spptr = pdata/* + (pad * pw) + pad*/;

	for (iy = 0; iy < bh; iy++)
	{
		/* Set pixel pointer to start of next row in grid. */
		pptr = spptr;
		for (ix = 0; ix < bw; ix++)
		{
			/* Compute which block the current pixel is in. */
			bx = ix;
			by = iy;
			/* Get corresponding value in Direction Map. */
			mapval = *(direction_map + (by*mw) + bx);
			/* If current block has has INVALID direction ... */
			if (mapval == INVALID_DIR)
				/* Set binary pixel to white (255). */
				*(bptr + (by*bw) + bx) = WHITE_PIXEL;
			/* Otherwise, if block has a valid direction ... */
			else if (bx < pad || by < pad || bx >= bw - pad || by >= bh - pad)
				*(bptr + (by*bw) + bx) = WHITE_PIXEL;
			else /*if(mapval >= 0)*/
				 /* Use directional binarization based on block's direction. */
				*(bptr + (by*bw) + bx) = dir_binarize(pptr, mapval, dirbingrids,pw,ph);         //code hot pot

			/* Bump input and output pixel pointers. */
			pptr++;
			//bptr++;
		}
		/* Bump pointer to the next row in padded input image. */
		spptr += pw;
	}

	return(0);
}

int dir_binarize(const unsigned char *pptr, const int idir, const ROTGRIDS *dirbingrids, int pw, int ph)
{
	int gx, gy, gi, cy;
	int rsum, gsum, csum = 0;
	int *grid;
	int dcy;

	/* Assign nickname pointer. */
	grid = dirbingrids->grids[idir];
	/* Calculate center (0-oriented) row in grid. */
	dcy = (dirbingrids->grid_h - 1) >>1;
	/* Need to truncate precision so that answers are consistent */
	/* on different computer architectures when rounding doubles. */
	//dcy = trunc_dbl_precision(dcy, TRUNC_SCALE);
	//cy = sround(dcy);
	cy = dcy;
	/* Initialize grid's pixel offset index to zero. */
	gi = 0;
	/* Initialize grid's pixel accumulator to zero */
	gsum = 0;

	/* Foreach row in grid ... */
	for (gy = 0; gy < dirbingrids->grid_h; gy++) {
		/* Initialize row pixel sum to zero. */
		rsum = 0;
		/* Foreach column in grid ... */
		for (gx = 0; gx < dirbingrids->grid_w; gx++) {
			/* Accumulate next pixel along rotated row in grid. */
			rsum += *(pptr + grid[gi]);
			/* Bump grid's pixel offset index. */
			gi++;
		}
		/* Accumulate row sum into grid pixel sum. */
		gsum += rsum;
		/* If current row is center row, then save row sum separately. */
		if (gy == cy)
			csum = rsum;
	}

	/* If the center row sum treated as an average is less than the */
	/* total pixel sum in the rotated grid ...                      */
	if ((csum * dirbingrids->grid_h) < gsum)
		/* Set the binary pixel to BLACK. */
		return(BLACK_PIXEL);
	else
		/* Otherwise set the binary pixel to WHITE. */
		return(WHITE_PIXEL);
}

void fill_holes_bin(unsigned char *bdata, const int iw, const int ih)
{
	int ix, iy, iw2;
	unsigned char *lptr, *mptr, *rptr, *tptr, *bptr, *sptr;

	/* 1. Fill 1-pixel wide holes in horizontal runs first ... */
	sptr = bdata + 1;
	/* Foreach row in image ... */
	for (iy = 0; iy < ih; iy++) {
		/* Initialize pointers to start of next line ... */
		lptr = sptr - 1;   /* Left pixel   */
		mptr = sptr;     /* Middle pixel */
		rptr = sptr + 1;   /* Right pixel  */
						   /* Foreach column in image (less far left and right pixels) ... */
		for (ix = 1; ix < iw - 1; ix++) {
			/* Do we have a horizontal hole of length 1? */
			if ((*lptr != *mptr) && (*lptr == *rptr)) {
				/* If so, then fill it. */
				*mptr = *lptr;
				/* Bump passed right pixel because we know it will not */
				/* be a hole.                                          */
				lptr += 2;
				mptr += 2;
				rptr += 2;
				/* We bump ix once here and then the FOR bumps it again. */
				ix++;
			}
			else {
				/* Otherwise, bump to the next pixel to the right. */
				lptr++;
				mptr++;
				rptr++;
			}
		}
		/* Bump to start of next row. */
		sptr += iw;
	}

	/* 2. Now, fill 1-pixel wide holes in vertical runs ... */
	iw2 = iw << 1;
	/* Start processing column one row down from the top of the image. */
	sptr = bdata + iw;
	/* Foreach column in image ... */
	for (ix = 0; ix < iw; ix++) {
		/* Initialize pointers to start of next column ... */
		tptr = sptr - iw;   /* Top pixel     */
		mptr = sptr;      /* Middle pixel  */
		bptr = sptr + iw;   /* Bottom pixel  */
							/* Foreach row in image (less top and bottom row) ... */
		for (iy = 1; iy < ih - 1; iy++) {
			/* Do we have a vertical hole of length 1? */
			if ((*tptr != *mptr) && (*tptr == *bptr)) {
				/* If so, then fill it. */
				*mptr = *tptr;
				/* Bump passed bottom pixel because we know it will not */
				/* be a hole.                                           */
				tptr += iw2;
				mptr += iw2;
				bptr += iw2;
				/* We bump iy once here and then the FOR bumps it again. */
				iy++;
			}
			else {
				/* Otherwise, bump to the next pixel below. */
				tptr += iw;
				mptr += iw;
				bptr += iw;
			}
		}
		/* Bump to start of next column. */
		sptr++;
	}
}

void bits_8to6(unsigned char *idata, const int iw, const int ih)
{
	int i, isize;
	unsigned char *iptr;

	isize = iw * ih;
	iptr = idata;
	for (i = 0; i < isize; i++) {
		/* Divide every pixel value by 4 so that [0..256) -> [0..64) */
		*iptr++ >>= 2;
	}
}

