#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <stdlib.h>
#include <math.h>
#include "public.h"

#define VL_BUILD_Hybrid_DLL
#include "Hybrid.h"
#include "table_int.h"
#include "cv_sift_int.h"
#include "Matrix_int.h"
#include "preprocess.h"
#include "binaryMap.h"
#include "public.h"

#if USE_FLOAT_DOUBLE

#include "sae_surf.h"
#include "myFPA.h"
#include "LibAFIS.h"
#include "List.h"
#include "cv_sift.h"
#include "Matrix.h"
#include "table.h"

#else

#include "type_def.h"

#endif

#if PC_IMAGE_DEBUG
  NOMALIZE_PARA nomalize_para;
#endif

#if TIME_COUNTER | WHOLE_TIME_COUNTER
  PROCESS_TIME process_time;
#endif

/**********************���幦�ܺ���**************************/
#if USE_FLOAT_DOUBLE
/*��ȡŷ����þ���������������*/
static int Hybrid_get_colsest_pair(float *desc11, int num11, float *desc21, int num21, int *matchpair);
/*�������ŷ����þ���*/
static int Hybrid_desc_dist_f_table(float *desc1, float *desc2, int d);
/*������ɸѡ,��������������ͼ��νṹɸѡ�������*/
static int Hybrid_filter_feat(MINUTIA *match_kp, int pair_num, float A[6], int* resultPair);
#endif

/*获取细节点*/
static void Hybrid_getFeatPoint_both(unsigned char *imgdata, int width, int height, 
	FEATURE *feature0, FEATURE *feature1, binaryMap* featMask);

/*腐蚀操作*/
static void Hybrid_Erosion(binaryMap* data, int width, int height, int iterator);

static int Hybrid_get_closest_pair_int(unsigned char *desc11, int num11, unsigned char *desc21, int num21, unsigned char *matchpair);

/*查表计算欧几里得距离*/
static int Hybrid_desc_dist_uc_table(unsigned char *desc1, unsigned char *desc2, int d);

/*sigma = 1 的高斯模糊, 整形运算*/
int INT_GaussSmooth(unsigned char *pUnchImg, unsigned char *pUnchSmthdImg, int nWidth, int nHeight);

//牛顿迭代开平方根
static int SqrtNiudun(unsigned int intx);

//static int Get_sqrt_root_from_table(int dx, int dy);

/**********************�ӿ�ʵ��**************************/
#if USE_FLOAT_DOUBLE

/**********************************************************************************
										��������
***********************************************************************************/

int Hybrid_enroll_fp(unsigned char *imgdata, int width, int height, 
	void *feat1, void *feat2, float *desc1[5], float *desc2[5])
{
	FEATURE *feature1 = (FEATURE *)feat1;
	FEATURE *feature2 = (FEATURE *)feat2;
	int dsize = descriptorSize;

	unsigned char* mask = NULL;
	mask = (unsigned char*)malloc(width * height * sizeof(unsigned char));
	memset(mask, 0, width * height * sizeof(unsigned char));
	int* bmpdata = NULL;
	bmpdata = (int*)malloc(width * height * sizeof(int));
	memset(bmpdata, 0, width * height * sizeof(int));
	myDynamicEqualize(imgdata, imgdata, width, height);
	myGetMask(imgdata, mask, width, height, 250, 2, 5);
	myImageNormalize(imgdata, mask, (int *)bmpdata);
	mySmoothFilter((int *)bmpdata, imgdata, 2);
	free(bmpdata);

	for (int i = 0; i < 5; i++)
	{
		feature1[i].MinutiaNum = feature2[i].MinutiaNum = 0;
	}

	binaryMap binMask = binaryMap_Construct(width, height);
	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j < height; j++)
		{
			if (mask[j*width + i] == 255) binaryMap_SetBit(&binMask, i, j, 1);
		}
	}
	free(mask);

	Hybrid_getFeatPoint_both(imgdata,width, height, feature1, feature2, &binMask);

	/*��ϸ�ڵ�Ϊ���İ뾶radius����4����*/
	int radius = 15; /*�����㵽���������*/
	feature1[1].MinutiaNum = feature1[2].MinutiaNum = feature1[3].MinutiaNum = feature1[4].MinutiaNum = feature1[0].MinutiaNum;
	for (int i = 0; i < feature1[0].MinutiaNum; i++)
	{
		int x0 = feature1[0].MinutiaArr[i].x;
		int y0 = feature1[0].MinutiaArr[i].y;

		for (int j = 0; j < 4; j++)
		{
			int sita = feature1[0].MinutiaArr[i].Direction + j * 90;
			if (sita > 360) sita -= 360;
			feature1[j + 1].MinutiaArr[i].Direction = sita;
			float fsita = sita * PI / 180.0f;
			int x = (int)(x0 + radius * cos(fsita) + 0.5f);
			int y = (int)(y0 + radius * sin(fsita) + 0.5f);

			feature1[j + 1].MinutiaArr[i].x = x;
			feature1[j + 1].MinutiaArr[i].y = y;
		}
	}
	feature2[1].MinutiaNum = feature2[2].MinutiaNum = feature2[3].MinutiaNum = feature2[4].MinutiaNum = feature2[0].MinutiaNum;
	for (int i = 0; i < feature2[0].MinutiaNum; i++)
	{
		int x0 = feature2[0].MinutiaArr[i].x;
		int y0 = feature2[0].MinutiaArr[i].y;

		for (int j = 0; j < 4; j++)
		{
			int sita = feature2[0].MinutiaArr[i].Direction + j * 90;
			if (sita > 360) sita -= 360;
			feature2[j + 1].MinutiaArr[i].Direction = sita;
			float fsita = sita * PI / 180.0f;
			int x = (int)(x0 + radius * cos(fsita) + 0.5f);
			int y = (int)(y0 + radius * sin(fsita) + 0.5f);

			feature2[j + 1].MinutiaArr[i].x = x;
			feature2[j + 1].MinutiaArr[i].y = y;
		}
	}

	SIFT_DET self;
	self.nOctaveLayers = 1;
	self.sigma = 1.6;

	myGaussSmooth(imgdata, imgdata, width, height, 0.2);

	int num1 = feature1[0].MinutiaNum;
	for (int i = 0; i < 5; i++)
	{
		KeyPoint* kp11 = (KeyPoint*)malloc(num1 * sizeof(KeyPoint));
		memset(kp11, 0, num1 * sizeof(KeyPoint));
		desc1[i] = (float*)malloc(num1 * descriptorSize * sizeof(float));
		memset(desc1[i], 0, num1 * descriptorSize * sizeof(float));
		for (int j = 0; j < num1; j++)
		{
			kp11[j].angle = feature1[i].MinutiaArr[j].Direction;
			kp11[j].octave = 0;
			kp11[j].size = SIFT_SIZE;
			kp11[j].x = feature1[i].MinutiaArr[j].x;
			kp11[j].y = feature1[i].MinutiaArr[j].y;
		}
		SIFT_DescriptorExtractor(&self, imgdata, NULL, width, height, kp11, num1, desc1[i]);
		free(kp11);
	}

	int num2 = feature2[0].MinutiaNum;
	for (int i = 0; i < 5; i++)
	{
		KeyPoint* kp12 = (KeyPoint*)malloc(num2 * sizeof(KeyPoint));
		memset(kp12, 0, num2 * sizeof(KeyPoint));
		desc2[i] = (float*)malloc(num2 * descriptorSize * sizeof(float));
		memset(desc2[i], 0, num2 * descriptorSize * sizeof(float));
		for (int j = 0; j < num2; j++)
		{
			kp12[j].angle = feature2[i].MinutiaArr[j].Direction;
			kp12[j].octave = 0;
			kp12[j].size = SIFT_SIZE;
			kp12[j].x = feature2[i].MinutiaArr[j].x;
			kp12[j].y = feature2[i].MinutiaArr[j].y;
		}
		SIFT_DescriptorExtractor(&self, imgdata, NULL, width, height, kp12, num2, desc2[i]);
		free(kp12);
	}
	return 0;
}

int Hybrid_match_fp(unsigned char *imgdata, int width, int height,
	void *feat11, void *feat12, float *desc11[5], float *desc12[5])
{
	FEATURE *feature11 = (FEATURE *)feat11;
	FEATURE *feature12 = (FEATURE *)feat12;

	FEATURE feature21[5];
	FEATURE feature22[5];
	float *desc21[5];
	float *desc22[5];

	Hybrid_enroll_fp(imgdata, width, height, feature21, feature22, desc21, desc22);

	int num11, num12, num21, num22;
	num11 = feature11[0].MinutiaNum;
	num12 = feature12[0].MinutiaNum;
	num21 = feature21[0].MinutiaNum;
	num22 = feature22[0].MinutiaNum;

	MINUTIA *matchPair_kp = (MINUTIA*)malloc(2 * (num11 + num21 + num12 + num22) * 5 * sizeof(MINUTIA));
	int *matchweight = (int*)malloc((num11 + num21 + num12 + num22) * 5 * sizeof(int));
	memset(matchweight, 0, (num11 + num21 + num12 + num22) * 5 * sizeof(int));
	int mmp = 0;
	int *paircount1 = (int*)malloc(num11 * num21 * sizeof(int));
	memset(paircount1, 0, num11 * num21 * sizeof(int));

	int *matchpair = (int*)malloc(2 * (num11 + num21) * sizeof(int));
	for (int m = 0; m < 5; m++)
	{
		memset(matchpair, 0, 2 * (num11 + num21) * sizeof(int));
		int pairnum = Hybrid_get_colsest_pair(desc11[m], num11, desc21[m], num21, matchpair);
		for (int n = 0; n < pairnum; n++)
		{
			int i = matchpair[n << 1];
			int j = matchpair[(n << 1) + 1];
			paircount1[i*num21 + j] ++;
		}
	}
	free(matchpair);
	matchpair = NULL;
	free(desc21[0]); free(desc21[1]); free(desc21[2]); free(desc21[3]); free(desc21[4]);

	for (int i = 0; i < num11; i++)
	{
		for (int j = 0; j < num21; j++)
		{
			if (paircount1[i*num21 + j] >= MINUTIA_MATCH_THR)
			{
				matchPair_kp[mmp << 1] = feature11[0].MinutiaArr[i];
				matchPair_kp[(mmp << 1) + 1] = feature21[0].MinutiaArr[j];
				matchweight[mmp] = paircount1[i*num21 + j];
				mmp++;
			}
		}
	}
	free(paircount1); paircount1 = NULL;

	int *paircount2 = (int*)malloc(num12 * num22 * sizeof(int));
	memset(paircount2, 0, num12 * num22 * sizeof(int));

	matchpair = (int*)malloc(2 * (num12 + num22) * sizeof(int));
	for (int m = 0; m < 5; m++)
	{
		memset(matchpair, 0, 2 * (num12 + num22) * sizeof(int));
		int pairnum = Hybrid_get_colsest_pair(desc12[m], num12, desc22[m], num22, matchpair);
		for (int n = 0; n < pairnum; n++)
		{
			int i = matchpair[n << 1];
			int j = matchpair[(n << 1) + 1];
			paircount2[i*num22 + j] ++;
		}
	}
	free(matchpair);
	matchpair = NULL;
	free(desc22[0]); free(desc22[1]); free(desc22[2]); free(desc22[3]); free(desc22[4]);

	for (int i = 0; i < num12; i++)
	{
		for (int j = 0; j < num22; j++)
		{
			if (paircount2[i*num22 + j] >= MINUTIA_MATCH_THR)
			{
				matchPair_kp[mmp << 1] = feature12[0].MinutiaArr[i];
				matchPair_kp[(mmp << 1) + 1] = feature22[0].MinutiaArr[j];
				matchweight[mmp] = paircount2[i*num22 + j];
				mmp++;
			}
		}
	}
	free(paircount2);

	float A[6];
	int* resultPair = (int*)malloc(2 * mmp * sizeof(int));
	memset(resultPair, 0, 2 * mmp * sizeof(int));
	int resultnum = Hybrid_filter_feat(matchPair_kp, mmp, A, resultPair);

	int score = 0;
	for (int i = 0; i < resultnum; i++)
	{
		int j = resultPair[2 * i];
		int k = resultPair[2 * i + 1];
		score += matchweight[j / 2];
	}

	free(resultPair);
	free(matchPair_kp);
	free(matchweight);

	return score;
}

int Hybrid_enroll_match_fp(unsigned char *imgdata1, int width1, int height1,
	unsigned char *imgdata2, int width2, int height2)
{
	FEATURE feature11[5];
	FEATURE feature12[5];
	float *desc11[5];
	float *desc12[5];

	int ret = Hybrid_enroll_fp(imgdata1, width1, height1,
		feature11, feature12, desc11, desc12);

	int matchret = Hybrid_match_fp(imgdata2, width2, height2,
		feature11, feature12, desc11, desc12);

	free(desc11[0]); free(desc11[1]); free(desc11[2]); free(desc11[3]); free(desc11[4]);
	free(desc12[0]); free(desc12[1]); free(desc12[2]); free(desc12[3]); free(desc12[4]);

	return matchret;
}
#endif


/**********************************************************************************
整形运算
***********************************************************************************/

/*提取特征与描述子*/

int Hybrid_enroll_fp_int(unsigned char *imgdata, int width, int height, 
	void *feat1, void *feat2, unsigned char *desc1[NUM_IN_ONE_GROUP], unsigned char *desc2[NUM_IN_ONE_GROUP])
{
	FEATURE *feature1[NUM_IN_ONE_GROUP];
	FEATURE *feature2[NUM_IN_ONE_GROUP];
	FEATURE featSampPt1[SAMPLE_POINT_NUM];
	FEATURE featSampPt2[SAMPLE_POINT_NUM];
	feature1[0] = (FEATURE *)feat1;
	feature2[0] = (FEATURE *)feat2;
	for (int i = 1; i < NUM_IN_ONE_GROUP; i++)
	{
		feature1[i] = &featSampPt1[i - 1];
		feature2[i] = &featSampPt2[i - 1];
	}
//	int dsize = descriptorSize;
	if (imgdata == NULL) return -1;

#if TIME_COUNTER | WHOLE_TIME_COUNTER
	memset(&process_time,0,sizeof(PROCESS_TIME));
#endif
	
	#if TIME_COUNTER
		time = 0;
	#endif	
	
	//图像直方图均衡
	Hybrid_DynamicEqualize(imgdata, imgdata, width, height);
	
	#if TIME_COUNTER
		process_time.hybrid_equalize = time;	
	#endif
	
	#if PC_IMAGE_DEBUG
		custom_hid_report_recive(&usb_device_dev);
		custom_hid_report_send(&usb_device_dev, imgdata, 192*192);
		custom_hid_report_recive(&usb_device_dev);
	#endif

	#if TIME_COUNTER
		time = 0;
	#endif

	binaryMap binMask = binaryMap_Construct(width, height);

	//获取MASK
	unsigned char* mask = NULL;
	mask = (unsigned char*)malloc(width * height * sizeof(unsigned char));
	if (mask == NULL) 
		return -1;
	memset(mask, 0, width * height * sizeof(unsigned char));
	Hybrid_GetMask(imgdata, mask, width, height, 250, 2);//, 4

//	binaryMap binMask = binaryMap_Construct(width, height);
	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j < height; j++)
		{
			if (mask[j*width + i] == 255) binaryMap_SetBit(&binMask, i, j, 1);
		}
	}
	
	#if TIME_COUNTER
		process_time.hybird_get_mask = time;	
	#endif
	
	#if PC_IMAGE_DEBUG
		custom_hid_report_recive(&usb_device_dev);
		custom_hid_report_send(&usb_device_dev, mask, 192*192);
		custom_hid_report_recive(&usb_device_dev);
	#endif		
	
	free(mask);		
	
	#if TIME_COUNTER
		time = 0;
	#endif	

  //图像归一化
	Hybrid_ImageNormalize(imgdata, width, height);

	#if TIME_COUNTER
		process_time.hybird_nomalize = time;	
	#endif

	#if PC_IMAGE_DEBUG
		custom_hid_report_recive(&usb_device_dev);
		custom_hid_report_send(&usb_device_dev, imgdata, 192*192);
		custom_hid_report_recive(&usb_device_dev);
	#endif

	#if TIME_COUNTER
		time = 0;
	#endif
	
  //图像均值滤波和逐点均衡
	Hybrid_SmoothFilter(imgdata, width, height, 9);

	#if TIME_COUNTER
		process_time.hybird_smooth_filter = process_time.image_smooth_filter1 + 
		                                    process_time.image_smooth_filter2 +
																				process_time.image_smooth_filter3 ;	
	#endif

	#if PC_IMAGE_DEBUG
		custom_hid_report_recive(&usb_device_dev);
		custom_hid_report_send(&usb_device_dev, imgdata, 192*192);
		custom_hid_report_recive(&usb_device_dev);
	#endif

//	#if TIME_COUNTER
//		time = 0;
//	#endif

//	binaryMap binMask = binaryMap_Construct(width, height);
//	for (int i = 0; i < width; i++)
//	{
//		for (int j = 0; j < height; j++)
//		{
//			if (mask[j*width + i] == 255) binaryMap_SetBit(&binMask, i, j, 1);
//		}
//	}
//	free(mask);	

	for (int i = 0; i < NUM_IN_ONE_GROUP; i++)
	{
		feature1[i]->MinutiaNum = feature2[i]->MinutiaNum = 0;
	}
	
	/*1在白色谷线上，2在黑色脊线上*/
	Hybrid_getFeatPoint_both(imgdata, width, height, feature1[0], feature2[0], &binMask);

	binaryMap_Destruct(&binMask);
	
	#if PC_IMAGE_DEBUG
		custom_hid_report_recive(&usb_device_dev);
		custom_hid_report_send(&usb_device_dev, imgdata, 192*192);
		custom_hid_report_recive(&usb_device_dev);
	#endif
	
	#if TIME_COUNTER
		time = 0;
	#endif	
	
	INT_GaussSmooth(imgdata, imgdata, width, height);
	
	#if TIME_COUNTER
		process_time.hybrid_gausssmooth = time;
	#endif
	
	#if PC_IMAGE_DEBUG
		custom_hid_report_recive(&usb_device_dev);
		custom_hid_report_send(&usb_device_dev, imgdata, 192*192);
		custom_hid_report_recive(&usb_device_dev);
	#endif
	
#if 0 /*Adjust Direction*/
	for (int i = 0; i < feature1[0].MinutiaNum; i++)
	{
		int ptx = feature1[0].MinutiaArr[i].x;
		int pty = feature1[0].MinutiaArr[i].y;
		int ori = feature1[0].MinutiaArr[i].Direction;
		ori = Adjust_Angle(imgdata, width, height, ptx, pty, ori);

		feature1[0].MinutiaArr[i].Direction = ori;
	}

	for (int i = 0; i < feature2[0].MinutiaNum; i++)
	{
		int ptx = feature2[0].MinutiaArr[i].x;
		int pty = feature2[0].MinutiaArr[i].y;
		int ori = feature2[0].MinutiaArr[i].Direction;
		ori = Adjust_Angle(imgdata, width, height, ptx, pty, ori);
		feature2[0].MinutiaArr[i].Direction = ori;
	}
#endif

	#if TIME_COUNTER
		time = 0;	
	#endif
	
	int radius = 10; /*采样点到特征点距离*/
	for (int i = 1; i < NUM_IN_ONE_GROUP; i++)
	{
		feature1[i]->MinutiaNum = feature1[0]->MinutiaNum;
	}
	for (int i = 0; i < feature1[0]->MinutiaNum; i++)
	{
		int x0 = feature1[0]->MinutiaArr[i].x;
		int y0 = feature1[0]->MinutiaArr[i].y;

		for (int j = 0; j < SAMPLE_POINT_NUM; j++)
		{
			int sita = feature1[0]->MinutiaArr[i].Direction + j * 360/ SAMPLE_POINT_NUM;
			if (sita > 360) sita -= 360;
			feature1[j + 1]->MinutiaArr[i].Direction = sita;
			int sin_t = sin_int_table[sita];
			int cos_t = cos_int_table[sita];
			int x = (x0 + ((radius * cos_t + (1 << (SIN_COS_SCAL_BIT - 1))) >> SIN_COS_SCAL_BIT));
			int y = (y0 + ((radius * sin_t + (1 << (SIN_COS_SCAL_BIT - 1))) >> SIN_COS_SCAL_BIT));

			feature1[j + 1]->MinutiaArr[i].x = x;
			feature1[j + 1]->MinutiaArr[i].y = y;
		}
	}
	for (int i = 1; i < NUM_IN_ONE_GROUP; i++)
	{
		feature2[i]->MinutiaNum = feature2[0]->MinutiaNum;
	}
	for (int i = 0; i < feature2[0]->MinutiaNum; i++)
	{
		int x0 = feature2[0]->MinutiaArr[i].x;
		int y0 = feature2[0]->MinutiaArr[i].y;
		for (int j = 0; j < SAMPLE_POINT_NUM; j++)
		{
			int sita = feature2[0]->MinutiaArr[i].Direction + j * 360 / SAMPLE_POINT_NUM;
			if (sita > 360) sita -= 360;
			feature2[j + 1]->MinutiaArr[i].Direction = sita;
			int sin_t = sin_int_table[sita];
			int cos_t = cos_int_table[sita];
			int x = (x0 + ((radius * cos_t + (1 << (SIN_COS_SCAL_BIT - 1))) >> SIN_COS_SCAL_BIT));
			int y = (y0 + ((radius * sin_t + (1 << (SIN_COS_SCAL_BIT - 1))) >> SIN_COS_SCAL_BIT));

			feature2[j + 1]->MinutiaArr[i].x = x;
			feature2[j + 1]->MinutiaArr[i].y = y;
		}
	}
	
	int num1 = feature1[0]->MinutiaNum;
	desc1[0] = (unsigned char*)malloc(NUM_IN_ONE_GROUP * num1 * descriptorSize * sizeof(unsigned char));
	for (int i = 0; i < NUM_IN_ONE_GROUP; i++)
	{
		KeyPoint_int* kp11 = (KeyPoint_int*)feature1[i]->MinutiaArr;
		desc1[i] = desc1[0] + i * num1 * descriptorSize;
		memset(desc1[i], 0, num1 * descriptorSize * sizeof(unsigned char));
		SIFT_DescriptorExtractor_int(imgdata, width, height, kp11, num1, desc1[i]);
	}

	int num2 = feature2[0]->MinutiaNum;
	desc2[0] = (unsigned char*)malloc(NUM_IN_ONE_GROUP * num2 * descriptorSize * sizeof(unsigned char));
	for (int i = 0; i < NUM_IN_ONE_GROUP; i++)
	{
		KeyPoint_int* kp12 = (KeyPoint_int*)feature2[i]->MinutiaArr;
		desc2[i] = desc2[0] + i * num2 * descriptorSize;
		memset(desc2[i], 0, num2 * descriptorSize * sizeof(unsigned char));
		SIFT_DescriptorExtractor_int(imgdata, width, height, kp12, num2, desc2[i]);
	}
	
	#if TIME_COUNTER
		process_time.others += time;	
	#endif
	
	#if TIME_COUNTER
		process_time.wholetime = process_time.hybrid_equalize +
	                           process_time.hybird_get_mask +
	                           process_time.hybird_nomalize +
														 process_time.hybird_smooth_filter +
														 process_time.hybrid_getfeaturepoint_getort +
														 process_time.hybrid_getfeaturepoint_binarize +
														 process_time.hybrid_getfeaturepoint_erosion +
														 process_time.hybrid_getfeaturepoint_firstthinning +
														 process_time.hybrid_getfeaturepoint_firstfindminutiae +
														 process_time.hybrid_getfeaturepoint_secondthinning +
														 process_time.hybrid_getfeaturepoint_secondfindminutiae +
														 process_time.hybrid_gausssmooth +	
														 process_time.others ;
	#endif
	
	return 0;
}

///*����ģ�嵽�ļ�������ֵ��һ��0-15,1���ֽڴ�2������ֵ*/
//int Hybrid_save_tmp_to_file(char* fpath, void *feat1, void *feat2, unsigned char *desc1[NUM_IN_ONE_GROUP],
//	unsigned char *desc2[NUM_IN_ONE_GROUP])
//{
//	FEATURE *feature1 = (FEATURE *)feat1;
//	FEATURE *feature2 = (FEATURE *)feat2;
//	FILE *fp = NULL;
//	int num1 = feature1->MinutiaNum;
//	int num2 = feature2->MinutiaNum;

//	/*��1�ֽڱ���2λ�����ӵ�ֵ*/
//	unsigned char *new_desc1[NUM_IN_ONE_GROUP] = { NULL };
//	unsigned char *new_desc2[NUM_IN_ONE_GROUP] = { NULL };

//	new_desc1[0] = (unsigned char*)malloc(sizeof(unsigned char) * NUM_IN_ONE_GROUP * num1 * descriptorSize_int / 2);
//	for (int i = 1; i < NUM_IN_ONE_GROUP; i++)
//	{
//		new_desc1[i] = new_desc1[0] + i * num1 * descriptorSize_int / 2;
//	}
//	new_desc2[0] = (unsigned char*)malloc(sizeof(unsigned char) * NUM_IN_ONE_GROUP * num2 * descriptorSize_int / 2);
//	for (int i = 1; i < NUM_IN_ONE_GROUP; i++)
//	{
//		new_desc2[i] = new_desc2[0] + i * num2 * descriptorSize_int / 2;
//	}

//	unsigned char highdata;
//	unsigned char lowdata;
//	for (int i = 0; i < NUM_IN_ONE_GROUP; i++)
//	{
//		for (int j = 0; j < num1; j++)
//		{
//			for (int k = 0; k < descriptorSize_int / 2; k++)
//			{
//				highdata = *(desc1[i] + j * descriptorSize_int + k * 2);
//				lowdata = *(desc1[i] + j * descriptorSize_int + k * 2 + 1);

//				*(new_desc1[i] + j * descriptorSize_int / 2 + k) = (highdata << 4) + lowdata;
//			}
//		}
//	}

//	for (int i = 0; i < NUM_IN_ONE_GROUP; i++)
//	{
//		for (int j = 0; j < num2; j++)
//		{
//			for (int k = 0; k < descriptorSize_int / 2; k++)
//			{
//				highdata = *(desc2[i] + j * descriptorSize_int + k * 2);
//				lowdata = *(desc2[i] + j * descriptorSize_int + k * 2 + 1);

//				*(new_desc2[i] + j * descriptorSize_int / 2 + k) = (highdata << 4) + lowdata;
//			}
//		}
//	}

//	/*д���ļ�*/
//	int ret = fopen_s(&fp, fpath, "wb");
//	if (ret == 0)
//	{
//		fwrite(feature1, sizeof(FEATURE), 1, fp);
//		fwrite(new_desc1[0], sizeof(unsigned char), NUM_IN_ONE_GROUP * num1 * descriptorSize_int / 2, fp);
//		fwrite(feature2, sizeof(FEATURE), 1, fp);
//		fwrite(new_desc2[0], sizeof(unsigned char), NUM_IN_ONE_GROUP * num2 * descriptorSize_int / 2, fp);
//		fclose(fp);
//	}

//	free(new_desc1[0]);
//	free(new_desc2[0]);
//	
//	return 0;
//}

///*���ļ��ж�ȡģ��*/
//int Hybrid_read_tmp_from_file(char* fpath, void *feat1, void *feat2, unsigned char *desc1[NUM_IN_ONE_GROUP],
//	unsigned char *desc2[NUM_IN_ONE_GROUP])
//{
//	FEATURE *feature1 = (FEATURE *)feat1;
//	FEATURE *feature2 = (FEATURE *)feat2;
//	unsigned char *new_desc1[NUM_IN_ONE_GROUP] = { NULL };
//	unsigned char *new_desc2[NUM_IN_ONE_GROUP] = { NULL };
//	FILE *fp = NULL;

//	int iret = fopen_s(&fp, fpath, "rb");
//	if (iret != 0)
//	{
//		return -1;
//	}

//	fseek(fp, 0, SEEK_END);
//	int memlen = ftell(fp);
//	fseek(fp, 0, SEEK_SET);

//	int Readsize = fread_s(feature1, sizeof(FEATURE),  1, sizeof(FEATURE),fp);
//	if (Readsize <= 0 || Readsize != sizeof(FEATURE))
//	{
//		fclose(fp); return -1;
//	}
//	int num1 = feature1->MinutiaNum;
//	int len1 = NUM_IN_ONE_GROUP * num1 * descriptorSize_int;
//	new_desc1[0] = (unsigned char*)malloc(sizeof(unsigned char) * len1 / 2);
//	for (int i = 1; i < NUM_IN_ONE_GROUP; i++)
//	{
//		new_desc1[i] = new_desc1[0] + i * num1 * descriptorSize_int / 2;
//	}
//	desc1[0] = (unsigned char*)malloc(sizeof(unsigned char) * len1);
//	for (int i = 1; i < NUM_IN_ONE_GROUP; i++)
//	{
//		desc1[i] = desc1[0] + i * num1 * descriptorSize_int;
//	}

//	Readsize = fread_s(new_desc1[0], sizeof(unsigned char) * len1 / 2, sizeof(unsigned char), len1 / 2, fp);
//	if (Readsize <= 0 || Readsize != sizeof(unsigned char) * len1 / 2)
//	{
//		free(new_desc1[0]);
//		free(desc1[0]);	
//		fclose(fp); 
//		return -1;
//	}

//	Readsize = fread_s(feature2, sizeof(FEATURE),  1, sizeof(FEATURE), fp);
//	if (Readsize <= 0 || Readsize != sizeof(FEATURE))
//	{
//		free(new_desc1[0]);
//		free(desc1[0]);
//		fclose(fp); return -1;
//	}

//	int num2 = feature2->MinutiaNum;
//	int len2 = NUM_IN_ONE_GROUP * num2 * descriptorSize_int;
//	new_desc2[0] = (unsigned char*)malloc(sizeof(unsigned char) * len2 / 2);
//	for (int i = 1; i < NUM_IN_ONE_GROUP; i++)
//	{
//		new_desc2[i] = new_desc2[0] + i * num2 * descriptorSize_int / 2;
//	}
//	desc2[0] = (unsigned char*)malloc(sizeof(unsigned char) * len2);
//	for (int i = 1; i < NUM_IN_ONE_GROUP; i++)
//	{
//		desc2[i] = desc2[0] + i * num2 * descriptorSize_int;
//	}
//	Readsize = fread_s(new_desc2[0], sizeof(unsigned char) * len2 / 2, sizeof(unsigned char), len2 / 2, fp);
//	if (Readsize <= 0 || Readsize != sizeof(unsigned char) * len2 / 2)
//	{

//		free(new_desc1[0]);
//		free(desc1[0]);
//		free(new_desc2[0]);
//		free(desc2[0]);

//		fclose(fp);
//		return -1;
//	}
//	fclose(fp);

//	unsigned char data;
//	unsigned char highdata;
//	unsigned char lowdata;
//	for (int i = 0; i < NUM_IN_ONE_GROUP; i++)
//	{
//		for (int j = 0; j < num1; j++)
//		{
//			for (int k = 0; k < descriptorSize_int / 2; k++)
//			{
//				data = *(new_desc1[i] + j * descriptorSize_int / 2 + k);
//				lowdata = data & 15;
//				highdata = data >> 4;
//				*(desc1[i] + j * descriptorSize_int + k * 2) = highdata;
//				*(desc1[i] + j * descriptorSize_int + k * 2 + 1) = lowdata;
//			}
//		}
//	}

//	for (int i = 0; i < NUM_IN_ONE_GROUP; i++)
//	{
//		for (int j = 0; j < num2; j++)
//		{
//			for (int k = 0; k < descriptorSize_int / 2; k++)
//			{
//				data = *(new_desc2[i] + j * descriptorSize_int / 2 + k);
//				lowdata = data & 15;
//				highdata = data >> 4;
//				*(desc2[i] + j * descriptorSize_int + k * 2) = highdata;
//				*(desc2[i] + j * descriptorSize_int + k * 2 + 1) = lowdata;
//			}
//		}
//	}

//	free(new_desc1[0]);
//	free(new_desc2[0]);

//	return 0;
//}

/*��ȡ�����������Ӳ�������������������ӽ��бȶ�*/
int Hybrid_match_fp_int(unsigned char *imgdata, int width, int height,
	void *feat11, void *feat12, unsigned char *desc11[NUM_IN_ONE_GROUP], unsigned char *desc12[NUM_IN_ONE_GROUP])
{
	FEATURE *feature11 = (FEATURE *)feat11;
	FEATURE *feature12 = (FEATURE *)feat12;

	FEATURE feature21;
	FEATURE feature22;
	unsigned char *desc21[NUM_IN_ONE_GROUP];
	unsigned char *desc22[NUM_IN_ONE_GROUP];
	int ret = Hybrid_enroll_fp_int(imgdata, width, height,&feature21, &feature22, desc21, desc22);
	if (ret == -1) return -1;

	int num11, num12, num21, num22;
	num11 = feature11[0].MinutiaNum;
	num12 = feature12[0].MinutiaNum;
	num21 = feature21.MinutiaNum;
	num22 = feature22.MinutiaNum;

	int minutiae_match_thr = 0;

	MINUTIA *matchPair_kp = (MINUTIA*)malloc(2 * (num11 * num21 + num12 * num22) * sizeof(MINUTIA));
	unsigned char *matchweight = (unsigned char*)malloc((num11 * num21 + num12 * num22) * sizeof(unsigned char));
	memset(matchweight, 0, (num11 * num21 + num12 * num22) * sizeof(unsigned char));
	int mmp = 0;
	unsigned char *paircount1 = (unsigned char*)malloc(num11 * num21 * sizeof(unsigned char));
	memset(paircount1, 0, num11 * num21 * sizeof(unsigned char));

	unsigned char *matchpair = (unsigned char*)malloc(2 * (num11 * num21) * sizeof(unsigned char));
	for (int m = 0; m < NUM_IN_ONE_GROUP; m++)
	{
		memset(matchpair, 0, 2 * (num11 * num21) * sizeof(unsigned char));
		int pairnum = Hybrid_get_closest_pair_int(desc11[m], num11, desc21[m], num21, matchpair);
		for (int n = 0; n < pairnum; n++)
		{
			int i = matchpair[n << 1];
			int j = matchpair[(n << 1) + 1];
			paircount1[i*num21 + j] ++;
		}
	}
	free(matchpair);
	matchpair = NULL;
	free(desc21[0]);

	int countHist1[20] = {0};
	for (int i = 0; i < num11; i++)
	{
		for (int j = 0; j < num21; j++)
		{
			countHist1[paircount1[i*num21 + j]]++;
		}
	}
	int sumHist1[20] = { 0 };
	sumHist1[19] = countHist1[19];
	for (int i = 18; i > 0; i--)
	{
		sumHist1[i] = sumHist1[i + 1] + countHist1[i];
	}

	minutiae_match_thr = MINUTIA_MATCH_THR;
	//if (sumHist1[MINUTIA_MATCH_THR] < 10)
	//{
	//	minutiae_match_thr -= 1;
	//}

	for (int i = 0; i < num11; i++)
	{
		for (int j = 0; j < num21; j++)
		{
			if (paircount1[i*num21 + j] >= minutiae_match_thr)
			{
				matchPair_kp[mmp << 1] = feature11[0].MinutiaArr[i];
				matchPair_kp[(mmp << 1) + 1] = feature21.MinutiaArr[j];
				matchweight[mmp] = paircount1[i*num21 + j];
				mmp++;
			}
		}
	}
	free(paircount1); paircount1 = NULL;

	unsigned char *paircount2 = (unsigned char*)malloc(num12 * num22 * sizeof(unsigned char));
	memset(paircount2, 0, num12 * num22 * sizeof(unsigned char));

	matchpair = (unsigned char*)malloc(2 * (num12 * num22) * sizeof(unsigned char));
	for (int m = 0; m < NUM_IN_ONE_GROUP; m++)
	{
		memset(matchpair, 0, 2 * (num12 * num22) * sizeof(unsigned char));
		int pairnum = Hybrid_get_closest_pair_int(desc12[m], num12, desc22[m], num22, matchpair);
		for (int n = 0; n < pairnum; n++)
		{
			int i = matchpair[n << 1];
			int j = matchpair[(n << 1) + 1];
			paircount2[i*num22 + j] ++;
		}
	}
	free(matchpair);
	matchpair = NULL;
	free(desc22[0]);

	int countHist2[20] = { 0 };
	for (int i = 0; i < num12; i++)
	{
		for (int j = 0; j < num22; j++)
		{
			countHist2[paircount2[i*num22 + j]]++;
		}
	}
	int sumHist2[20] = { 0 };
	sumHist2[19] = countHist2[19];
	for (int i = 18; i > 0; i--)
	{
		sumHist2[i] = sumHist2[i + 1] + countHist2[i];
	}

	minutiae_match_thr = MINUTIA_MATCH_THR;
	//if (sumHist2[MINUTIA_MATCH_THR] < 10)
	//{
	//	minutiae_match_thr -= 1;
	//}

	for (int i = 0; i < num12; i++)
	{
		for (int j = 0; j < num22; j++)
		{
			if (paircount2[i*num22 + j] >= minutiae_match_thr)
			{
				matchPair_kp[mmp << 1] = feature12[0].MinutiaArr[i];
				matchPair_kp[(mmp << 1) + 1] = feature22.MinutiaArr[j];
				matchweight[mmp] = paircount2[i*num22 + j];
				mmp++;
			}
		}
	}
	free(paircount2);

	int iA[6];
	int Det;
	int* resultPair = (int*)malloc(2 * mmp * sizeof(int));
	memset(resultPair, 0, 2 * mmp * sizeof(int));
	int resultnum = Hybrid_filter_feat_int(matchPair_kp, mmp, iA, &Det, resultPair);

	int score = 0;
	for (int i = 0; i < resultnum; i++)
	{
		int j = resultPair[2 * i];
//		int k = resultPair[2 * i + 1];
		score += matchweight[j / 2];
	}

	//printf("---(%d,%d,%d)", countHist1[8] + countHist2[8], 
	//	countHist1[9] + countHist2[9], countHist1[10] + countHist2[10]);

	//score += 5 * (countHist1[5] + countHist2[5])
	//	+ 6 * (countHist1[6] + countHist2[6])
	//	+ 7 * (countHist1[7] + countHist2[7])
	//	+ 8 * (countHist1[8] + countHist2[8]);

	free(resultPair);
	free(matchPair_kp);
	free(matchweight);
	return score;
}

/*�ȶ����������������������*/
int Hybrid_match_desc_int(void *feat11, void *feat12, unsigned char *desc11[NUM_IN_ONE_GROUP], unsigned char *desc12[NUM_IN_ONE_GROUP],
	void *feat21, void *feat22, unsigned char *desc21[NUM_IN_ONE_GROUP], unsigned char *desc22[NUM_IN_ONE_GROUP],
	unsigned char* resultpair1, unsigned char* resultpair2, int *matchnum1, int *matchnum2,
	int iA[6], int *Det)
{
	FEATURE *feature11 = (FEATURE *)feat11;
	FEATURE *feature12 = (FEATURE *)feat12;
	FEATURE *feature21 = (FEATURE *)feat21;
	FEATURE *feature22 = (FEATURE *)feat22;

	int num11, num12, num21, num22;
	num11 = feature11[0].MinutiaNum;
	num12 = feature12[0].MinutiaNum;
	num21 = feature21[0].MinutiaNum;
	num22 = feature22[0].MinutiaNum;

	if (num11 + num12 == 0 || num21 + num22 == 0) return -1;

	MINUTIA *matchPair_kp = (MINUTIA*)malloc(2 * (num11 * num21 + num12 * num22) * sizeof(MINUTIA));
	unsigned char *matchweight = (unsigned char*)malloc((num11 * num21 + num12 * num22) * sizeof(unsigned char));
	memset(matchweight, 0, (num11 * num21 + num12 * num22) * sizeof(unsigned char));
	int mmp = 0,mmp1 = 0,mmp2=0;
	unsigned char *paircount1 = (unsigned char*)malloc(num11 * num21 * sizeof(unsigned char));
	memset(paircount1, 0, num11 * num21 * sizeof(unsigned char));

	unsigned char *matchpair = (unsigned char*)malloc(2 * (num11 * num21) * sizeof(unsigned char));
	for (int m = 0; m < NUM_IN_ONE_GROUP; m++)
	{
		memset(matchpair, 0, 2 * (num11 * num21) * sizeof(unsigned char));
		int pairnum = Hybrid_get_closest_pair_int(desc11[m], num11, desc21[m], num21, matchpair);
		for (int n = 0; n < pairnum; n++)
		{
			int i = matchpair[n << 1];
			int j = matchpair[(n << 1) + 1];
			paircount1[i*num21 + j] ++;
		}
	}
	free(matchpair);
	matchpair = NULL;
	//free(desc21[0]); free(desc21[1]); free(desc21[2]); free(desc21[3]); free(desc21[4]);

	int countHist1[20] = { 0 };
	for (int i = 0; i < num11; i++)
	{
		for (int j = 0; j < num21; j++)
		{
			countHist1[paircount1[i*num21 + j]]++;
		}
	}
	int sumHist1[20] = { 0 };
	sumHist1[19] = countHist1[19];
	for (int i = 18; i > 0; i--)
	{
		sumHist1[i] = sumHist1[i + 1] + countHist1[i];
	}

	int minutiae_match_thr = MINUTIA_MATCH_THR;
	//if (sumHist1[MINUTIA_MATCH_THR] < 10)
	//{
	//	minutiae_match_thr -= 1;
	//}

	unsigned char *matchpair_index = (unsigned char*)malloc(2 * (num11 * num21 + num12 * num22));

	for (int i = 0; i < num11; i++)
	{
		for (int j = 0; j < num21; j++)
		{
			if (paircount1[i*num21 + j] >= minutiae_match_thr)
			{
				matchPair_kp[mmp << 1] = feature11[0].MinutiaArr[i];
				matchPair_kp[(mmp << 1) + 1] = feature21[0].MinutiaArr[j];
				matchpair_index[mmp << 1] = i;
				matchpair_index[(mmp << 1) + 1] = j;
				matchweight[mmp] = paircount1[i*num21 + j];
				mmp++;
				mmp1++;
			}
		}
	}
	free(paircount1); paircount1 = NULL;

	unsigned char *paircount2 = (unsigned char*)malloc(num12 * num22 * sizeof(unsigned char));
	memset(paircount2, 0, num12 * num22 * sizeof(unsigned char));

	matchpair = (unsigned char*)malloc(2 * (num12 * num22) * sizeof(unsigned char));
	for (int m = 0; m < NUM_IN_ONE_GROUP; m++)
	{
		memset(matchpair, 0, 2 * (num12 * num22) * sizeof(unsigned char));
		int pairnum = Hybrid_get_closest_pair_int(desc12[m], num12, desc22[m], num22, matchpair);
		for (int n = 0; n < pairnum; n++)
		{
			int i = matchpair[n << 1];
			int j = matchpair[(n << 1) + 1];
			paircount2[i*num22 + j] ++;
		}
	}
	free(matchpair);
	matchpair = NULL;
	//free(desc22[0]); free(desc22[1]); free(desc22[2]); free(desc22[3]); free(desc22[4]);

	int countHist2[20] = { 0 };
	for (int i = 0; i < num12; i++)
	{
		for (int j = 0; j < num22; j++)
		{
			countHist2[paircount2[i*num22 + j]]++;
		}
	}
	int sumHist2[20] = { 0 };
	sumHist2[19] = countHist2[19];
	for (int i = 18; i > 0; i--)
	{
		sumHist2[i] = sumHist2[i + 1] + countHist2[i];
	}

	minutiae_match_thr = MINUTIA_MATCH_THR;
	//if (sumHist2[MINUTIA_MATCH_THR] < 10)
	//{
	//	minutiae_match_thr -= 1;
	//}

	for (int i = 0; i < num12; i++)
	{
		for (int j = 0; j < num22; j++)
		{
			if (paircount2[i*num22 + j] >= minutiae_match_thr)
			{
				matchPair_kp[mmp << 1] = feature12[0].MinutiaArr[i];
				matchPair_kp[(mmp << 1) + 1] = feature22[0].MinutiaArr[j];
				matchpair_index[mmp << 1] = i;
				matchpair_index[(mmp << 1) + 1] = j;
				matchweight[mmp] = paircount2[i*num22 + j];
				mmp++;
				mmp2++;
			}
		}
	}
	free(paircount2);

	//int iA[6];
	//int Det;
	int* resultPair = (int*)malloc(2 * mmp * sizeof(int));
	memset(resultPair, 0, 2 * mmp * sizeof(int));
	int resultnum = Hybrid_filter_feat_int(matchPair_kp, mmp, iA, Det, resultPair);

	int score = 0;
	for (int i = 0; i < resultnum; i++)
	{
		int j = resultPair[2 * i];
//		int k = resultPair[2 * i + 1];
		score += matchweight[j / 2];
	}

	//score += 5 * (countHist1[5] + countHist2[5])
	//	+ 6 * (countHist1[6] + countHist2[6])
	//	+ 7 * (countHist1[7] + countHist2[7])
	//	+ 8 * (countHist1[8] + countHist2[8]);

	if (resultpair1 != NULL && resultpair2 != NULL)
	{
		int c1 = 0, c2 = 0;

		for (int i = 0; i < resultnum; i++)
		{
			int j = resultPair[2 * i];
			int k = resultPair[2 * i + 1];
			if (j < 2 * mmp1)
			{
				resultpair1[2 * c1] = matchpair_index[j];
				resultpair1[2 * c1 + 1] = matchpair_index[k];
				c1++;
			}
			else
			{
				resultpair2[2 * c2] = matchpair_index[j];
				resultpair2[2 * c2 + 1] = matchpair_index[k];
				c2++;
			}
		}
		*matchnum1 = c1;
		*matchnum2 = c2;
	}
	free(matchpair_index);
	free(resultPair);
	free(matchPair_kp);
	free(matchweight);


	return score;
}

/*�ȶ����������������������-�����ڴ濪��*/
int Hybrid_match_desc_int_V2(void *feat11, void *feat12, unsigned char *desc11[NUM_IN_ONE_GROUP], unsigned char *desc12[NUM_IN_ONE_GROUP],
	void *feat21, void *feat22, unsigned char *desc21[NUM_IN_ONE_GROUP], unsigned char *desc22[NUM_IN_ONE_GROUP])
{
	FEATURE *feature11 = (FEATURE *)feat11;
	FEATURE *feature12 = (FEATURE *)feat12;
	FEATURE *feature21 = (FEATURE *)feat21;
	FEATURE *feature22 = (FEATURE *)feat22;

	int num11, num12, num21, num22;
	num11 = feature11[0].MinutiaNum;
	num12 = feature12[0].MinutiaNum;
	num21 = feature21[0].MinutiaNum;
	num22 = feature22[0].MinutiaNum;

	if (num11 + num12 == 0 || num21 + num22 == 0) return -1;

	int len1 = num11 * num21;
	int len2 = num12 * num22;
	int mmp = 0;
	int minutiae_match_thr = MINUTIA_MATCH_THR;

	unsigned char *paircount1 = (unsigned char*)malloc(num11 * num21 * sizeof(unsigned char));
	memset(paircount1, 0, num11 * num21 * sizeof(unsigned char));

	unsigned char *matchpair = (unsigned char*)malloc(2 * (num11 * num21) * sizeof(unsigned char));
	for (int m = 0; m < NUM_IN_ONE_GROUP; m++)
	{
		memset(matchpair, 0, 2 * (num11 * num21) * sizeof(unsigned char));
		int pairnum = Hybrid_get_closest_pair_int(desc11[m], num11, desc21[m], num21, matchpair);
		for (int n = 0; n < pairnum; n++)
		{
			int i = matchpair[n << 1];
			int j = matchpair[(n << 1) + 1];
			paircount1[i*num21 + j] ++;
		}
	}
	free(matchpair);
	matchpair = NULL;

	unsigned char *paircount2 = (unsigned char*)malloc(num12 * num22 * sizeof(unsigned char));
	memset(paircount2, 0, num12 * num22 * sizeof(unsigned char));
	matchpair = (unsigned char*)malloc(2 * (num12 * num22) * sizeof(unsigned char));
	for (int m = 0; m < NUM_IN_ONE_GROUP; m++)
	{
		memset(matchpair, 0, 2 * (num12 * num22) * sizeof(unsigned char));
		int pairnum = Hybrid_get_closest_pair_int(desc12[m], num12, desc22[m], num22, matchpair);
		for (int n = 0; n < pairnum; n++)
		{
			int i = matchpair[n << 1];
			int j = matchpair[(n << 1) + 1];
			paircount2[i*num22 + j] ++;
		}
	}
	free(matchpair);
	matchpair = NULL;

	mmp = 0;
	for (int i = 0; i < len1; i++)
	{
		if (paircount1[i] >= minutiae_match_thr) mmp++;
	}
	for (int i = 0; i < len2; i++)
	{
		if (paircount2[i] >= minutiae_match_thr) mmp++;
	}

	MINUTIA *matchPair_kp = (MINUTIA*)malloc(2 * mmp * sizeof(MINUTIA));
	unsigned char *matchweight = (unsigned char*)malloc(mmp * sizeof(unsigned char));
	memset(matchweight, 0, mmp * sizeof(unsigned char));

	mmp = 0;
	for (int i = 0; i < num11; i++)
	{
		for (int j = 0; j < num21; j++)
		{
			if (paircount1[i*num21 + j] >= minutiae_match_thr)
			{
				matchPair_kp[mmp << 1] = feature11[0].MinutiaArr[i];
				matchPair_kp[(mmp << 1) + 1] = feature21[0].MinutiaArr[j];
				matchweight[mmp] = paircount1[i*num21 + j];
				mmp++;
			}
		}
	}
	free(paircount1); paircount1 = NULL;

	for (int i = 0; i < num12; i++)
	{
		for (int j = 0; j < num22; j++)
		{
			if (paircount2[i*num22 + j] >= minutiae_match_thr)
			{
				matchPair_kp[mmp << 1] = feature12[0].MinutiaArr[i];
				matchPair_kp[(mmp << 1) + 1] = feature22[0].MinutiaArr[j];
				matchweight[mmp] = paircount2[i*num22 + j];
				mmp++;
			}
		}
	}
	free(paircount2); paircount2 = NULL;

	int iA[6];
	int Det;
	int* resultPair = (int*)malloc(2 * mmp * sizeof(int));
	memset(resultPair, 0, 2 * mmp * sizeof(int));
	int resultnum =  Hybrid_filter_feat_int_fast(matchPair_kp, mmp, iA, &Det, resultPair);

	int score = 0;
	for (int i = 0; i < resultnum; i++)
	{
		int j = resultPair[2 * i];
//		int k = resultPair[2 * i + 1];
		score += matchweight[j / 2];
	}
	free(resultPair);

	free(matchPair_kp);
	free(matchweight);

	return score;
}

/*�������ϸ�ڵ������Ӻ�������(Ч���ȷֿ��Ĳ�ܶ�)*/
int Hybrid_match_desc_int_2(void *feat11, void *feat12, unsigned char *desc11[NUM_IN_ONE_GROUP], unsigned char *desc12[NUM_IN_ONE_GROUP],
	void *feat21, void *feat22, unsigned char *desc21[NUM_IN_ONE_GROUP], unsigned char *desc22[NUM_IN_ONE_GROUP])
{
	FEATURE *feature11 = (FEATURE *)feat11;
	FEATURE *feature12 = (FEATURE *)feat12;
	FEATURE *feature21 = (FEATURE *)feat21;
	FEATURE *feature22 = (FEATURE *)feat22;

	int num11, num12, num21, num22;
	num11 = feature11[0].MinutiaNum;
	num12 = feature12[0].MinutiaNum;
	num21 = feature21[0].MinutiaNum;
	num22 = feature22[0].MinutiaNum;

	if (num11 + num12 == 0 || num21 + num22 == 0) return -1;

	MINUTIA *matchPair_kp = (MINUTIA*)malloc(2 * 3 * (num11 + num21 + num12 + num22) * sizeof(MINUTIA));
	int mmp = 0;
	unsigned char *matchweight = (unsigned char*)malloc((num11 + num21 + num12 + num22) * 3 * sizeof(unsigned char));
	memset(matchweight, 0, (num11+ num21 + num12+ num22) * 3 * sizeof(unsigned char));

	{
		int *dist_arr = (int*)malloc(num11*num21 * sizeof(int));
		memset(dist_arr, 0, num11*num21 * sizeof(int));
		unsigned char* flagCount = (unsigned char*)malloc(num11*num21 * sizeof(unsigned char));
		memset(flagCount, 0, num11*num21 * sizeof(unsigned char));

		for (int m = 0; m < NUM_IN_ONE_GROUP; m++)
		{
			for (int i = 0; i < num11; i++)
			{
				for (int j = 0; j < num21; j++)
				{
					dist_arr[i*num21 + j] += Hybrid_desc_dist_uc_table(desc11[m] + i * descriptorSize, desc21[m] + j * descriptorSize,
						descriptorSize);
				}
			}
		}

		int min_third_val[3] = { 0,0,0 };
		int min_third_index[3] = { 0,0,0 };
		int tmp = 0;
		for (int i = 0; i < num11; i++)
		{
			min_third_val[0] = min_third_val[1] = min_third_val[2] = 9999999;
			min_third_index[0] = min_third_index[1] = min_third_index[2] = 0;
//			int mindis = 9999999;
//			int minj = 0;
			for (int j = 0; j < num21; j++)
			{
				if (dist_arr[i*num21 + j] < min_third_val[2])
				{
					min_third_val[2] = dist_arr[i*num21 + j];
					min_third_index[2] = j;
					if (min_third_val[2] < min_third_val[1])
					{
						tmp = min_third_val[1];
						min_third_val[1] = min_third_val[2];
						min_third_val[2] = tmp;
						tmp = min_third_index[1];
						min_third_index[1] = min_third_index[2];
						min_third_index[2] = tmp;

						if (min_third_val[1] < min_third_val[0])
						{
							tmp = min_third_val[0];
							min_third_val[0] = min_third_val[1];
							min_third_val[1] = tmp;
							tmp = min_third_index[0];
							min_third_index[0] = min_third_index[1];
							min_third_index[1] = tmp;
						}
					}
				}
			}
			flagCount[i*num21 + min_third_index[0]] += 3;
			flagCount[i*num21 + min_third_index[1]] += 2;
			flagCount[i*num21 + min_third_index[2]] += 1;
		}

		for (int j = 0; j < num21; j++)
		{
			min_third_val[0] = min_third_val[1] = min_third_val[2] = 9999999;
			min_third_index[0] = min_third_index[1] = min_third_index[2] = 0;
//			int mindis = 9999999;
//			int mini = 0;
			for (int i = 0; i < num11; i++)
			{
				if (dist_arr[i*num21 + j] < min_third_val[2])
				{
					min_third_val[2] = dist_arr[i*num21 + j];
					min_third_index[2] = i;
					if (min_third_val[2] < min_third_val[1])
					{
						tmp = min_third_val[1];
						min_third_val[1] = min_third_val[2];
						min_third_val[2] = tmp;
						tmp = min_third_index[1];
						min_third_index[1] = min_third_index[2];
						min_third_index[2] = tmp;

						if (min_third_val[1] < min_third_val[0])
						{
							tmp = min_third_val[0];
							min_third_val[0] = min_third_val[1];
							min_third_val[1] = tmp;
							tmp = min_third_index[0];
							min_third_index[0] = min_third_index[1];
							min_third_index[1] = tmp;
						}
					}
				}
			}
			flagCount[min_third_index[0] *num21 + j] += 3;
			flagCount[min_third_index[1] *num21 + j] += 2;
			flagCount[min_third_index[2] *num21 + j] += 1;
		}

		for (int i = 0; i < num11; i++)
		{
			for (int j = 0; j < num21; j++)
			{
				if (flagCount[i * num21 + j] >= 3)
				{
					matchPair_kp[mmp << 1] = feature11[0].MinutiaArr[i];
					matchPair_kp[(mmp << 1) + 1] = feature21[0].MinutiaArr[j];
					matchweight[mmp] = flagCount[i * num21 + j];
					mmp++;
				}
			}
		}
		free(dist_arr);
		free(flagCount);
	}


	{
		int *dist_arr = (int*)malloc(num12 * num22 * sizeof(int));
		memset(dist_arr, 0, num12 * num22 * sizeof(int));
		unsigned char* flagCount = (unsigned char*)malloc(num12*num22 * sizeof(unsigned char));
		memset(flagCount, 0, num12*num22 * sizeof(unsigned char));

		for (int m = 0; m < NUM_IN_ONE_GROUP; m++)
		{
			for (int i = 0; i < num12; i++)
			{
				for (int j = 0; j < num22; j++)
				{
					dist_arr[i*num22 + j] += Hybrid_desc_dist_uc_table(desc12[m] + i * descriptorSize, desc22[m] + j * descriptorSize,
						descriptorSize);
				}
			}
		}

		int min_third_val[3] = { 0,0,0 };
		int min_third_index[3] = { 0,0,0 };
		int tmp = 0;
		for (int i = 0; i < num12; i++)
		{
			min_third_val[0] = min_third_val[1] = min_third_val[2] = 9999999;
			min_third_index[0] = min_third_index[1] = min_third_index[2] = 0;
//			int mindis = 9999999;
//			int minj = 0;
			for (int j = 0; j < num22; j++)
			{
				if (dist_arr[i*num22 + j] < min_third_val[2])
				{
					min_third_val[2] = dist_arr[i*num22 + j];
					min_third_index[2] = j;
					if (min_third_val[2] < min_third_val[1])
					{
						tmp = min_third_val[1];
						min_third_val[1] = min_third_val[2];
						min_third_val[2] = tmp;
						tmp = min_third_index[1];
						min_third_index[1] = min_third_index[2];
						min_third_index[2] = tmp;

						if (min_third_val[1] < min_third_val[0])
						{
							tmp = min_third_val[0];
							min_third_val[0] = min_third_val[1];
							min_third_val[1] = tmp;
							tmp = min_third_index[0];
							min_third_index[0] = min_third_index[1];
							min_third_index[1] = tmp;
						}
					}
				}
			}
			flagCount[i*num22 + min_third_index[0]] += 3;
			flagCount[i*num22 + min_third_index[1]] += 2;
			flagCount[i*num22 + min_third_index[2]] += 1;
		}

		for (int j = 0; j < num22; j++)
		{
			min_third_val[0] = min_third_val[1] = min_third_val[2] = 9999999;
			min_third_index[0] = min_third_index[1] = min_third_index[2] = 0;
//			int mindis = 9999999;
//			int mini = 0;
			for (int i = 0; i < num12; i++)
			{
				if (dist_arr[i*num22 + j] < min_third_val[2])
				{
					min_third_val[2] = dist_arr[i*num22 + j];
					min_third_index[2] = i;
					if (min_third_val[2] < min_third_val[1])
					{
						tmp = min_third_val[1];
						min_third_val[1] = min_third_val[2];
						min_third_val[2] = tmp;
						tmp = min_third_index[1];
						min_third_index[1] = min_third_index[2];
						min_third_index[2] = tmp;

						if (min_third_val[1] < min_third_val[0])
						{
							tmp = min_third_val[0];
							min_third_val[0] = min_third_val[1];
							min_third_val[1] = tmp;
							tmp = min_third_index[0];
							min_third_index[0] = min_third_index[1];
							min_third_index[1] = tmp;
						}
					}
				}
			}
			flagCount[min_third_index[0] * num22 + j] += 3;
			flagCount[min_third_index[1] * num22 + j] += 2;
			flagCount[min_third_index[2] * num22 + j] += 1;
		}

		for (int i = 0; i < num12; i++)
		{
			for (int j = 0; j < num22; j++)
			{
				if (flagCount[i * num22 + j] >= 3)
				{
					matchPair_kp[mmp << 1] = feature12[0].MinutiaArr[i];
					matchPair_kp[(mmp << 1) + 1] = feature22[0].MinutiaArr[j];
					matchweight[mmp] = flagCount[i * num22 + j];
					mmp++;
				}
			}
		}

		free(dist_arr);
		free(flagCount);
	}

	int iA[6];
	int Det;
	int* resultPair = (int*)malloc(2 * mmp * sizeof(int));
	memset(resultPair, 0, 2 * mmp * sizeof(int));
	int resultnum = Hybrid_filter_feat_int(matchPair_kp, mmp, iA, &Det, resultPair);

	int score = 0;
	for (int i = 0; i < resultnum; i++)
	{
		int j = resultPair[2 * i];
//		int k = resultPair[2 * i + 1];
		score += matchweight[j / 2];
	}

	free(resultPair);
	free(matchPair_kp);
	free(matchweight);
	return score;
}

/*��ȡ��������㹹�ɼ���������,ϸ�ڵ�Ͳ�����ĺϲ�����*/
int Hybrid_match_desc_int_3(void *feat11, void *feat12, unsigned char *desc11[NUM_IN_ONE_GROUP], unsigned char *desc12[NUM_IN_ONE_GROUP],
	void *feat21, void *feat22, unsigned char *desc21[NUM_IN_ONE_GROUP], unsigned char *desc22[NUM_IN_ONE_GROUP])
{
	FEATURE *feature11 = (FEATURE *)feat11;
	FEATURE *feature12 = (FEATURE *)feat12;
	FEATURE *feature21 = (FEATURE *)feat21;
	FEATURE *feature22 = (FEATURE *)feat22;

	int num11, num12, num21, num22;
	num11 = feature11[0].MinutiaNum;
	num12 = feature12[0].MinutiaNum;
	num21 = feature21[0].MinutiaNum;
	num22 = feature22[0].MinutiaNum;

	if (num11 + num12 == 0 || num21 + num22 == 0) return -1;

	int newdesc_size = NUM_IN_ONE_GROUP * SIFT_DESCR_WIDTH_INT * SIFT_DESCR_WIDTH_INT;
	unsigned char *newDesc11 = (unsigned char*)malloc(num11*newdesc_size * sizeof(unsigned char));
	unsigned char *newDesc12 = (unsigned char*)malloc(num12*newdesc_size * sizeof(unsigned char));
	unsigned char *newDesc21 = (unsigned char*)malloc(num21*newdesc_size * sizeof(unsigned char));
	unsigned char *newDesc22 = (unsigned char*)malloc(num22*newdesc_size * sizeof(unsigned char));

	MINUTIA *matchPair_kp = (MINUTIA*)malloc(2 * (num11 * num21 + num12 * num22) * sizeof(MINUTIA));
	int mmp = 0;
	unsigned char *matchweight = (unsigned char*)malloc((num11 * num21 + num12 * num22) * sizeof(unsigned char));
	memset(matchweight, 0, (num11 * num21 + num12 * num22) * sizeof(unsigned char));

	for (int m = 0; m < num11; m++)
	{
		for (int n = 0; n < NUM_IN_ONE_GROUP; n++)
		{
			for (int i = 0; i < SIFT_DESCR_WIDTH_INT * SIFT_DESCR_WIDTH_INT; i++)
			{
				int maxval = 0;
				int maxindex = 0;
				int val = 0;
				for (int j = 0; j < SIFT_DESCR_HIST_BINS_INT; j++)
				{
					val = *(desc11[n] + m * descriptorSize + i * SIFT_DESCR_HIST_BINS_INT + j);
					if (val > maxval)
					{
						maxval = val;
						maxindex = j;
					}
				}
				*(newDesc11 + m * newdesc_size + n * (SIFT_DESCR_WIDTH_INT * SIFT_DESCR_WIDTH_INT) + i) = maxindex;
			}
		}
	}

	for (int m = 0; m < num12; m++)
	{
		for (int n = 0; n < NUM_IN_ONE_GROUP; n++)
		{
			for (int i = 0; i < SIFT_DESCR_WIDTH_INT * SIFT_DESCR_WIDTH_INT; i++)
			{
				int maxval = 0;
				int maxindex = 0;
				int val = 0;
				for (int j = 0; j < SIFT_DESCR_HIST_BINS_INT; j++)
				{
					val = *(desc12[n] + m * descriptorSize + i * SIFT_DESCR_HIST_BINS_INT + j);
					if (val > maxval)
					{
						maxval = val;
						maxindex = j;
					}
				}
				*(newDesc12 + m * newdesc_size + n * (SIFT_DESCR_WIDTH_INT * SIFT_DESCR_WIDTH_INT) + i) = maxindex;
			}
		}
	}

	for (int m = 0; m < num21; m++)
	{
		for (int n = 0; n < NUM_IN_ONE_GROUP; n++)
		{
			for (int i = 0; i < SIFT_DESCR_WIDTH_INT * SIFT_DESCR_WIDTH_INT; i++)
			{
				int maxval = 0;
				int maxindex = 0;
				int val = 0;
				for (int j = 0; j < SIFT_DESCR_HIST_BINS_INT; j++)
				{
					val = *(desc21[n] + m * descriptorSize + i * SIFT_DESCR_HIST_BINS_INT + j);
					if (val > maxval)
					{
						maxval = val;
						maxindex = j;
					}
				}
				*(newDesc21 + m * newdesc_size + n * (SIFT_DESCR_WIDTH_INT * SIFT_DESCR_WIDTH_INT) + i) = maxindex;
			}
		}
	}

	for (int m = 0; m < num22; m++)
	{
		for (int n = 0; n < NUM_IN_ONE_GROUP; n++)
		{
			for (int i = 0; i < SIFT_DESCR_WIDTH_INT * SIFT_DESCR_WIDTH_INT; i++)
			{
				int maxval = 0;
				int maxindex = 0;
				int val = 0;
				for (int j = 0; j < SIFT_DESCR_HIST_BINS_INT; j++)
				{
					val = *(desc22[n] + m * descriptorSize + i * SIFT_DESCR_HIST_BINS_INT + j);
					if (val > maxval)
					{
						maxval = val;
						maxindex = j;
					}
				}
				*(newDesc22 + m * newdesc_size + n * (SIFT_DESCR_WIDTH_INT * SIFT_DESCR_WIDTH_INT) + i) = maxindex;
			}
		}
	}

	int *dist_arr = (int*)malloc(num11*num21 * sizeof(int));
	memset(dist_arr, 0, num11*num21 * sizeof(int));
	unsigned char* flagCount = (unsigned char*)malloc(num11*num21 * sizeof(unsigned char));
	memset(flagCount, 0, num11*num21 * sizeof(unsigned char));

	unsigned char* ptr1,*ptr2;
	unsigned char diff;
	for (int i = 0; i < num11; i++)
	{
		for (int j = 0; j < num21; j++)
		{
			ptr1 = newDesc11 + i * newdesc_size;
			ptr2 = newDesc21 + j * newdesc_size;
			for (int k = 0; k < newdesc_size; k++)
			{
				diff = abs(ptr1[k] - ptr2[k]);
				diff = min(diff, SIFT_DESCR_HIST_BINS_INT - diff);
				dist_arr[i * num21 + j] += diff * diff;
			}
		}
	}

	{
		int min_third_val[3] = { 0,0,0 };
		int min_third_index[3] = { 0,0,0 };
		int tmp = 0;
		for (int i = 0; i < num11; i++)
		{
			min_third_val[0] = min_third_val[1] = min_third_val[2] = 9999999;
			min_third_index[0] = min_third_index[1] = min_third_index[2] = 0;
//			int mindis = 9999999;
//			int minj = 0;
			for (int j = 0; j < num21; j++)
			{
				if (dist_arr[i*num21 + j] == 0)
				{
					flagCount[i * num21 + j] += 1;
				}

				if (dist_arr[i*num21 + j] < min_third_val[2])
				{
					min_third_val[2] = dist_arr[i*num21 + j];
					min_third_index[2] = j;
					if (min_third_val[2] < min_third_val[1])
					{
						tmp = min_third_val[1];
						min_third_val[1] = min_third_val[2];
						min_third_val[2] = tmp;
						tmp = min_third_index[1];
						min_third_index[1] = min_third_index[2];
						min_third_index[2] = tmp;

						if (min_third_val[1] < min_third_val[0])
						{
							tmp = min_third_val[0];
							min_third_val[0] = min_third_val[1];
							min_third_val[1] = tmp;
							tmp = min_third_index[0];
							min_third_index[0] = min_third_index[1];
							min_third_index[1] = tmp;
						}
					}
				}
			}
			flagCount[i*num21 + min_third_index[0]] += 1;
			flagCount[i*num21 + min_third_index[1]] += 1;
			//flagCount[i*num21 + min_third_index[2]] += 1;
		}

		for (int j = 0; j < num21; j++)
		{
			min_third_val[0] = min_third_val[1] = min_third_val[2] = 9999999;
			min_third_index[0] = min_third_index[1] = min_third_index[2] = 0;
//			int mindis = 9999999;
//			int mini = 0;
			for (int i = 0; i < num11; i++)
			{
				if (dist_arr[i*num21 + j] < min_third_val[2])
				{
					min_third_val[2] = dist_arr[i*num21 + j];
					min_third_index[2] = i;
					if (min_third_val[2] < min_third_val[1])
					{
						tmp = min_third_val[1];
						min_third_val[1] = min_third_val[2];
						min_third_val[2] = tmp;
						tmp = min_third_index[1];
						min_third_index[1] = min_third_index[2];
						min_third_index[2] = tmp;

						if (min_third_val[1] < min_third_val[0])
						{
							tmp = min_third_val[0];
							min_third_val[0] = min_third_val[1];
							min_third_val[1] = tmp;
							tmp = min_third_index[0];
							min_third_index[0] = min_third_index[1];
							min_third_index[1] = tmp;
						}
					}
				}
			}
			flagCount[min_third_index[0] * num21 + j] += 1;
			flagCount[min_third_index[1] * num21 + j] += 1;
			//flagCount[min_third_index[2] * num21 + j] += 1;
		}

		for (int i = 0; i < num11; i++)
		{
			for (int j = 0; j < num21; j++)
			{
				if (flagCount[i * num21 + j] >= 1)
				{
					matchPair_kp[mmp << 1] = feature11[0].MinutiaArr[i];
					matchPair_kp[(mmp << 1) + 1] = feature21[0].MinutiaArr[j];
					matchweight[mmp] = flagCount[i * num21 + j];
					mmp++;
				}
			}
		}
	}

	free(dist_arr);
	free(flagCount);

	dist_arr = (int*)malloc(num12*num22 * sizeof(int));
	memset(dist_arr, 0, num12*num22 * sizeof(int));
	flagCount = (unsigned char*)malloc(num12*num22 * sizeof(unsigned char));
	memset(flagCount, 0, num12*num22 * sizeof(unsigned char));

	for (int i = 0; i < num12; i++)
	{
		for (int j = 0; j < num22; j++)
		{
			ptr1 = newDesc12 + i * newdesc_size;
			ptr2 = newDesc22 + j * newdesc_size;
			for (int k = 0; k < newdesc_size; k++)
			{
				diff = abs(ptr1[k] - ptr2[k]);
				diff = min(diff, SIFT_DESCR_HIST_BINS_INT - diff);
				dist_arr[i * num22 + j] += diff * diff;
			}
		}
	}

	{
		int min_third_val[3] = { 0,0,0 };
		int min_third_index[3] = { 0,0,0 };
		int tmp = 0;
		for (int i = 0; i < num12; i++)
		{
			min_third_val[0] = min_third_val[1] = min_third_val[2] = 9999999;
			min_third_index[0] = min_third_index[1] = min_third_index[2] = 0;
//			int mindis = 9999999;
//			int minj = 0;
			for (int j = 0; j < num22; j++)
			{
				if (dist_arr[i*num22 + j] == 0)
				{
					flagCount[i * num22 + j] += 1;
				}
				if (dist_arr[i*num22 + j] < min_third_val[2])
				{
					min_third_val[2] = dist_arr[i*num22 + j];
					min_third_index[2] = j;
					if (min_third_val[2] < min_third_val[1])
					{
						tmp = min_third_val[1];
						min_third_val[1] = min_third_val[2];
						min_third_val[2] = tmp;
						tmp = min_third_index[1];
						min_third_index[1] = min_third_index[2];
						min_third_index[2] = tmp;

						if (min_third_val[1] < min_third_val[0])
						{
							tmp = min_third_val[0];
							min_third_val[0] = min_third_val[1];
							min_third_val[1] = tmp;
							tmp = min_third_index[0];
							min_third_index[0] = min_third_index[1];
							min_third_index[1] = tmp;
						}
					}
				}
			}
			flagCount[i*num22 + min_third_index[0]] += 1;
			flagCount[i*num22 + min_third_index[1]] += 1;
			//flagCount[i*num22 + min_third_index[2]] += 1;
		}

		for (int j = 0; j < num22; j++)
		{
			min_third_val[0] = min_third_val[1] = min_third_val[2] = 9999999;
			min_third_index[0] = min_third_index[1] = min_third_index[2] = 0;
//			int mindis = 9999999;
//			int mini = 0;
			for (int i = 0; i < num12; i++)
			{
				if (dist_arr[i*num22 + j] < min_third_val[2])
				{
					min_third_val[2] = dist_arr[i*num22 + j];
					min_third_index[2] = i;
					if (min_third_val[2] < min_third_val[1])
					{
						tmp = min_third_val[1];
						min_third_val[1] = min_third_val[2];
						min_third_val[2] = tmp;
						tmp = min_third_index[1];
						min_third_index[1] = min_third_index[2];
						min_third_index[2] = tmp;

						if (min_third_val[1] < min_third_val[0])
						{
							tmp = min_third_val[0];
							min_third_val[0] = min_third_val[1];
							min_third_val[1] = tmp;
							tmp = min_third_index[0];
							min_third_index[0] = min_third_index[1];
							min_third_index[1] = tmp;
						}
					}
				}
			}
			flagCount[min_third_index[0] * num22 + j] += 1;
			flagCount[min_third_index[1] * num22 + j] += 1;
			//flagCount[min_third_index[2] * num22 + j] += 1;
		}

		for (int i = 0; i < num12; i++)
		{
			for (int j = 0; j < num22; j++)
			{
				if (flagCount[i * num22 + j] >= 1)
				{
					matchPair_kp[mmp << 1] = feature12[0].MinutiaArr[i];
					matchPair_kp[(mmp << 1) + 1] = feature22[0].MinutiaArr[j];
					matchweight[mmp] = flagCount[i * num22 + j];
					mmp++;
				}
			}
		}
	}

	free(dist_arr);
	free(flagCount);

	int iA[6];
	int Det;
	int* resultPair = (int*)malloc(2 * mmp * sizeof(int));
	memset(resultPair, 0, 2 * mmp * sizeof(int));
	int resultnum = Hybrid_filter_feat_int(matchPair_kp, mmp, iA, &Det, resultPair);

	int score = 0;
	for (int i = 0; i < resultnum; i++)
	{
		int j = resultPair[2 * i];
//		int k = resultPair[2 * i + 1];
		score += matchweight[j / 2];
	}
	free(resultPair);
	free(matchweight);
	free(matchPair_kp);
	free(newDesc11);
	free(newDesc21);
	free(newDesc12);
	free(newDesc22);
	return score;
}

/*��ȡ��������㹹�ɼ���������,ϸ�ڵ�Ͳ�����ֿ��ȶ�*/
int Hybrid_match_desc_int_4(void *feat11, void *feat12, unsigned char *desc11[NUM_IN_ONE_GROUP], unsigned char *desc12[NUM_IN_ONE_GROUP],
	void *feat21, void *feat22, unsigned char *desc21[NUM_IN_ONE_GROUP], unsigned char *desc22[NUM_IN_ONE_GROUP])
{
	FEATURE *feature11 = (FEATURE *)feat11;
	FEATURE *feature12 = (FEATURE *)feat12;
	FEATURE *feature21 = (FEATURE *)feat21;
	FEATURE *feature22 = (FEATURE *)feat22;

	int num11, num12, num21, num22;
	num11 = feature11[0].MinutiaNum;
	num12 = feature12[0].MinutiaNum;
	num21 = feature21[0].MinutiaNum;
	num22 = feature22[0].MinutiaNum;
	int len1 = num11 * num21;
	int len2 = num12 * num22;

	if (num11 + num12 == 0 || num21 + num22 == 0) return -1;

	int newdesc_size = SIFT_DESCR_WIDTH_INT * SIFT_DESCR_WIDTH_INT;
	unsigned char *newDesc11[NUM_IN_ONE_GROUP] = { NULL };
	unsigned char *newDesc12[NUM_IN_ONE_GROUP] = { NULL };
	unsigned char *newDesc21[NUM_IN_ONE_GROUP] = { NULL };
	unsigned char *newDesc22[NUM_IN_ONE_GROUP] = { NULL };

	MINUTIA *matchPair_kp = (MINUTIA*)malloc(2 * (num11 * num21 + num12 * num22) * sizeof(MINUTIA));
	int mmp = 0;
	unsigned char *matchweight = (unsigned char*)malloc((num11 * num21 + num12 * num22) * sizeof(unsigned char));
	memset(matchweight, 0, (num11 * num21 + num12 * num22) * sizeof(unsigned char));

	
	for (int n = 0; n < NUM_IN_ONE_GROUP; n++)
	{
		newDesc11[n] = (unsigned char*)malloc(num11*newdesc_size * sizeof(unsigned char));
		for (int m = 0; m < num11; m++)
		{
			for (int i = 0; i < SIFT_DESCR_WIDTH_INT * SIFT_DESCR_WIDTH_INT; i++)
			{
				int maxval = 0;
				int maxindex = 0;
				int val = 0;
				for (int j = 0; j < SIFT_DESCR_HIST_BINS_INT; j++)
				{
					val = *(desc11[n] + m * descriptorSize + i * SIFT_DESCR_HIST_BINS_INT + j);
					if (val > maxval)
					{
						maxval = val;
						maxindex = j;
					}
				}
				*(newDesc11[n] + m * newdesc_size + i) = maxindex;
			}
		}

		newDesc12[n] = (unsigned char*)malloc(num12*newdesc_size * sizeof(unsigned char));
		for (int m = 0; m < num12; m++)
		{
			for (int i = 0; i < SIFT_DESCR_WIDTH_INT * SIFT_DESCR_WIDTH_INT; i++)
			{
				int maxval = 0;
				int maxindex = 0;
				int val = 0;
				for (int j = 0; j < SIFT_DESCR_HIST_BINS_INT; j++)
				{
					val = *(desc12[n] + m * descriptorSize + i * SIFT_DESCR_HIST_BINS_INT + j);
					if (val > maxval)
					{
						maxval = val;
						maxindex = j;
					}
				}
				*(newDesc12[n] + m * newdesc_size + i) = maxindex;
			}
		}

		newDesc21[n] = (unsigned char*)malloc(num21*newdesc_size * sizeof(unsigned char));
		for (int m = 0; m < num21; m++)
		{
			for (int i = 0; i < SIFT_DESCR_WIDTH_INT * SIFT_DESCR_WIDTH_INT; i++)
			{
				int maxval = 0;
				int maxindex = 0;
				int val = 0;
				for (int j = 0; j < SIFT_DESCR_HIST_BINS_INT; j++)
				{
					val = *(desc21[n] + m * descriptorSize + i * SIFT_DESCR_HIST_BINS_INT + j);
					if (val > maxval)
					{
						maxval = val;
						maxindex = j;
					}
				}
				*(newDesc21[n] + m * newdesc_size + i) = maxindex;
			}
		}

		newDesc22[n] = (unsigned char*)malloc(num22*newdesc_size * sizeof(unsigned char));
		for (int m = 0; m < num22; m++)
		{
			for (int i = 0; i < SIFT_DESCR_WIDTH_INT * SIFT_DESCR_WIDTH_INT; i++)
			{
				int maxval = 0;
				int maxindex = 0;
				int val = 0;
				for (int j = 0; j < SIFT_DESCR_HIST_BINS_INT; j++)
				{
					val = *(desc22[n] + m * descriptorSize + i * SIFT_DESCR_HIST_BINS_INT + j);
					if (val > maxval)
					{
						maxval = val;
						maxindex = j;
					}
				}
				*(newDesc22[n] + m * newdesc_size + i) = maxindex;
			}
		}
	}

	int *dist_arr = (int*)malloc(num11*num21 * sizeof(int));
	memset(dist_arr, 0, num11*num21 * sizeof(int));
	unsigned char* flagCount = (unsigned char*)malloc(num11*num21 * sizeof(unsigned char));
	memset(flagCount, 0, num11*num21 * sizeof(unsigned char));

	unsigned char* ptr1, *ptr2;
	unsigned char diff;
	for (int n = 0; n < NUM_IN_ONE_GROUP; n++)
	{
		memset(dist_arr, 0, num11*num21 * sizeof(int));
		for (int i = 0; i < num11; i++)
		{
			for (int j = 0; j < num21; j++)
			{
				ptr1 = newDesc11[n] + i * newdesc_size;
				ptr2 = newDesc21[n] + j * newdesc_size;
				for (int k = 0; k < newdesc_size; k++)
				{
					diff = abs(ptr1[k] - ptr2[k]);
					diff = min(diff, SIFT_DESCR_HIST_BINS_INT - diff);
					dist_arr[i * num21 + j] = diff;
				}
			}
		}

		//int min_third_val[3] = { 0,0,0 };
		//int min_third_index[3] = { 0,0,0 };
		//int tmp = 0;
		for (int i = 0; i < num11; i++)
		{
			//min_third_val[0] = min_third_val[1] = min_third_val[2] = 9999999;
			//min_third_index[0] = min_third_index[1] = min_third_index[2] = 0;
			//int mindis = 9999999;
			//int minj = 0;
			for (int j = 0; j < num21; j++)
			{
				if (dist_arr[i*num21 + j] == 0)
				{
					flagCount[i * num21 + j] += 1;
				}
				//if (dist_arr[i*num21 + j] < min_third_val[2])
				//{
				//	min_third_val[2] = dist_arr[i*num21 + j];
				//	min_third_index[2] = j;
				//	if (min_third_val[2] < min_third_val[1])
				//	{
				//		tmp = min_third_val[1];
				//		min_third_val[1] = min_third_val[2];
				//		min_third_val[2] = tmp;
				//		tmp = min_third_index[1];
				//		min_third_index[1] = min_third_index[2];
				//		min_third_index[2] = tmp;
				//		if (min_third_val[1] < min_third_val[0])
				//		{
				//			tmp = min_third_val[0];
				//			min_third_val[0] = min_third_val[1];
				//			min_third_val[1] = tmp;
				//			tmp = min_third_index[0];
				//			min_third_index[0] = min_third_index[1];
				//			min_third_index[1] = tmp;
				//		}
				//	}
				//}
			}
			//flagCount[i*num21 + min_third_index[0]] += 1;
			//flagCount[i*num21 + min_third_index[1]] += 1;
			//flagCount[i*num21 + min_third_index[2]] += 1;
		}
		//for (int j = 0; j < num21; j++)
		//{
		//	min_third_val[0] = min_third_val[1] = min_third_val[2] = 9999999;
		//	min_third_index[0] = min_third_index[1] = min_third_index[2] = 0;
		//	int mindis = 9999999;
		//	int mini = 0;
		//	for (int i = 0; i < num11; i++)
		//	{
		//		if (dist_arr[i*num21 + j] < min_third_val[2])
		//		{
		//			min_third_val[2] = dist_arr[i*num21 + j];
		//			min_third_index[2] = i;
		//			if (min_third_val[2] < min_third_val[1])
		//			{
		//				tmp = min_third_val[1];
		//				min_third_val[1] = min_third_val[2];
		//				min_third_val[2] = tmp;
		//				tmp = min_third_index[1];
		//				min_third_index[1] = min_third_index[2];
		//				min_third_index[2] = tmp;
		//				if (min_third_val[1] < min_third_val[0])
		//				{
		//					tmp = min_third_val[0];
		//					min_third_val[0] = min_third_val[1];
		//					min_third_val[1] = tmp;
		//					tmp = min_third_index[0];
		//					min_third_index[0] = min_third_index[1];
		//					min_third_index[1] = tmp;
		//				}
		//			}
		//		}
		//	}
		//	flagCount[min_third_index[0] * num21 + j] += 1;
		//	flagCount[min_third_index[1] * num21 + j] += 1;
		//	//flagCount[min_third_index[2] * num21 + j] += 1;
		//}
	}

	int countHist1[2* NUM_IN_ONE_GROUP] = { 0 };
	for (int i = 0; i < len1; i++)
	{
		countHist1[flagCount[i]]++;
	}
	int sumHist1[2 * NUM_IN_ONE_GROUP] = { 0 };
	sumHist1[2 * NUM_IN_ONE_GROUP - 1] = countHist1[2 * NUM_IN_ONE_GROUP - 1];
	for (int i = 2 * NUM_IN_ONE_GROUP - 2; i > 0; i--)
	{
		sumHist1[i] = sumHist1[i + 1] + countHist1[i];
	}

	int minutiae_match_thr = MINUTIA_MATCH_THR;
	if (sumHist1[MINUTIA_MATCH_THR] > 150) minutiae_match_thr = MINUTIA_MATCH_THR + 1;

	for (int i = 0; i < num11; i++)
	{
		for (int j = 0; j < num21; j++)
		{
			if (flagCount[i * num21 + j] >= minutiae_match_thr)
			{
				matchPair_kp[mmp << 1] = feature11[0].MinutiaArr[i];
				matchPair_kp[(mmp << 1) + 1] = feature21[0].MinutiaArr[j];
				matchweight[mmp] = flagCount[i * num21 + j];
				mmp++;
			}
		}
	}
	free(dist_arr);
	free(flagCount);

	dist_arr = (int*)malloc(num12*num22 * sizeof(int));
	memset(dist_arr, 0, num12*num22 * sizeof(int));
	flagCount = (unsigned char*)malloc(num12*num22 * sizeof(unsigned char));
	memset(flagCount, 0, num12*num22 * sizeof(unsigned char));

	for (int n = 0; n < NUM_IN_ONE_GROUP; n++)
	{
		memset(dist_arr, 0, num12*num22 * sizeof(int));
		for (int i = 0; i < num12; i++)
		{
			for (int j = 0; j < num22; j++)
			{
				ptr1 = newDesc12[n] + i * newdesc_size;
				ptr2 = newDesc22[n] + j * newdesc_size;
				for (int k = 0; k < newdesc_size; k++)
				{
					diff = abs(ptr1[k] - ptr2[k]);
					diff = min(diff, SIFT_DESCR_HIST_BINS_INT - diff);
					dist_arr[i * num22 + j] = diff;
				}
			}
		}
		for (int i = 0; i < num12; i++)
		{
			for (int j = 0; j < num22; j++)
			{
				if (dist_arr[i * num22 + j] == 0)
				{
					flagCount[i * num22 + j] += 1;
				}
			}
		}
	}

	int countHist2[2 * NUM_IN_ONE_GROUP] = { 0 };
	for (int i = 0; i < len2; i++)
	{
		countHist2[flagCount[i]]++;
	}
	int sumHist2[2 * NUM_IN_ONE_GROUP] = { 0 };
	sumHist2[2 * NUM_IN_ONE_GROUP - 1] = countHist2[2 * NUM_IN_ONE_GROUP - 1];
	for (int i = 2 * NUM_IN_ONE_GROUP - 2; i > 0; i--)
	{
		sumHist2[i] = sumHist2[i + 1] + countHist2[i];
	}

	minutiae_match_thr = MINUTIA_MATCH_THR;
	if (sumHist2[MINUTIA_MATCH_THR] > 150) minutiae_match_thr = MINUTIA_MATCH_THR + 1;

	for (int i = 0; i < num12; i++)
	{
		for (int j = 0; j < num22; j++)
		{
			if (flagCount[i * num22 + j] >= minutiae_match_thr)
			{
				matchPair_kp[mmp << 1] = feature12[0].MinutiaArr[i];
				matchPair_kp[(mmp << 1) + 1] = feature22[0].MinutiaArr[j];
				matchweight[mmp] = flagCount[i * num22 + j];
				mmp++;
			}
		}
	}
	free(dist_arr);
	free(flagCount);

	for (int n = 0; n < NUM_IN_ONE_GROUP; n++)
	{
		free(newDesc11[n]); free(newDesc12[n]);
		free(newDesc21[n]); free(newDesc22[n]);
	}

	int iA[6];
	int Det;
	int* resultPair = (int*)malloc(2 * mmp * sizeof(int));
	memset(resultPair, 0, 2 * mmp * sizeof(int));
	int resultnum = Hybrid_filter_feat_int(matchPair_kp, mmp, iA, &Det, resultPair);

	int score = 0;
	for (int i = 0; i < resultnum; i++)
	{
		int j = resultPair[2 * i];
//		int k = resultPair[2 * i + 1];
		score += matchweight[j / 2];
	}
	free(resultPair);
	free(matchPair_kp);
	free(matchweight);


	return score;
}

/*��ȡ2���������ȶ�*/
int Hybrid_enroll_match_fp_int(unsigned char *imgdata1, int width1, int height1,
	unsigned char *imgdata2, int width2, int height2)
{
	FEATURE feature11;
	FEATURE feature12;
	unsigned char *desc11[NUM_IN_ONE_GROUP];
	unsigned char *desc12[NUM_IN_ONE_GROUP];

	int ret = Hybrid_enroll_fp_int(imgdata1, width1, height1,
		&feature11, &feature12, desc11, desc12);

	int matchret = Hybrid_match_fp_int(imgdata2, width2, height2,
		&feature11, &feature12, desc11, desc12);

	free(desc11[0]); 
	free(desc12[0]);

	return matchret;
}

/***********************���ܺ���ʵ��*************************/

//ţ�ٵ�����ƽ����
static int SqrtNiudun(unsigned int intx)
{
	int pre = 1;
	int tempz = 1;
	unsigned char flag = 0;
	while (abs(tempz - pre) > 1 || flag == 0)
	{
		flag = 1;
		pre = tempz;
		tempz = (pre + intx / pre) >> 1;
	}
	return tempz;
}

//static int Get_sqrt_root_from_table(int dx, int dy)
//{
//	if (abs(dx) <= 128 && abs(dy) <= 128)
//		return square_root_table_uc[dx + 128][dy + 128];
//	else
//	{
//		return (square_root_table_uc[(dx>>1) + 128][(dy>>1) + 128] << 1);
//	}
//}

/*32λ���ο��ٿ�����,�Ŵ�8��*/
static int fast_sqrt_root(int dx, int dy)
{
	unsigned int M = (dx * dx + dy * dy) << 6;

	unsigned int N, i;
	unsigned int tmp, ttp;   // �����ѭ������ 
	if (M == 0)               // �����������������ҲΪ0 
		return 0;
	M++;
	N = 0;
	tmp = (M >> 30);          // ��ȡ���λ��B[m-1] 
	M <<= 2;
	if (tmp > 1)              // ���λΪ1 
	{
		N++;                 // �����ǰλΪ1������ΪĬ�ϵ�0 
		tmp -= N;
	}
	for (i = 15; i>0; i--)      // ��ʣ���15λ 
	{
		N <<= 1;              // ����һλ

		tmp <<= 2;
		tmp += (M >> 30);     // ����

		ttp = N;
		ttp = (ttp << 1) + 1;

		M <<= 2;
		if (tmp >= ttp)       // ������� 
		{
			tmp -= ttp;
			N++;
		}
	}

	return N;
}

/*
获取细节点
@imgdata [in]
@width [in]
@height [in]
@feature0 [out] 谷线上的细节点(白色)
@feature1 [out] 脊线上的细节点(黑色)
@featMask [in] 有效区域的mask
*/
void Hybrid_getFeatPoint_both(unsigned char *imgdata, int width, int height, 
	FEATURE *feature0, FEATURE *feature1, binaryMap* featMask)
{
//	int ret = 0;
	unsigned char *dir = NULL, *bin = NULL;
	int datalen = width * height * sizeof(unsigned char);

	dir = malloc(datalen);
	if (dir == NULL) 
		return;
	memset(dir, 0, datalen);
	
	
	#if TIME_COUNTER
		time = 0;
	#endif
	
	Hybrid_GetOrt(imgdata, dir, featMask, width, height, 8, 0, 4);   // 由imgdata,featmask得到方向场 *dir
	
	#if TIME_COUNTER
		process_time.hybrid_getfeaturepoint_getort = time;	
	#endif	
  
	#if TIME_COUNTER
		time = 0;
	#endif	
	
	bin = dir;
	Hybrid_binarize(imgdata, width, height, dir, bin);  // 由imgdata,方向场数据得到二值化图像数据 *bin
	
	#if TIME_COUNTER
		process_time.hybrid_getfeaturepoint_binarize = time;	
	#endif
	
	#if TIME_COUNTER 
		time = 0; 
	#endif	
	
	Hybrid_Erosion(featMask, width, height, 5);                // 对featMask进行腐蚀操作
	
	#if TIME_COUNTER
		process_time.hybrid_getfeaturepoint_erosion = time;	
	#endif	
	
	int maskMargin = 8;                                        // 屏蔽featMask周围的8行pixel
	for (int i = 0; i < width; i++)
	{
		for (int j = 0; j < maskMargin; j++)
		{
			binaryMap_SetBit(featMask, i, j, 0);
		}
		for (int j = height - maskMargin; j < height; j++)
		{
			binaryMap_SetBit(featMask, i, j, 0);
		}
	}
	
	for (int j = 0; j < height; j++)
	{
		for (int i = 0; i < maskMargin; i++)
		{
			binaryMap_SetBit(featMask, i, j, 0); 
		}
		for (int i = width - maskMargin; i < width; i++)
		{
			binaryMap_SetBit(featMask, i, j, 0); 
		}
	}
	
	binaryMap binmap = binaryMap_Construct(width, height);    // 取二值化之后的图像，求其二进制的map图 binmap
	for (int x = 0; x < width; x++)
	{
		for (int y = 0; y < height; y++)
		{
			if (bin[y*width + x]) 
				binaryMap_SetBit(&binmap, x, y, 1);
			else 
				binaryMap_SetBit(&binmap, x, y, 0);
		}
	}

	unsigned char *thinning = bin;
	feature0->MinutiaNum = feature1->MinutiaNum = 0;
	
	#if TIME_COUNTER
		time = 0;
	#endif
	
	Hybrid_thinning(thinning, width, height);               // 对二值化之后的图像进行细化
	
	#if TIME_COUNTER
		process_time.hybrid_getfeaturepoint_firstthinning = time;	
	#endif	
	
	#if TIME_COUNTER
		time = 0;
	#endif	
	
	Hybrid_FindMinutiae(thinning, featMask, width, height, feature1);
	
	#if TIME_COUNTER
		process_time.hybrid_getfeaturepoint_firstfindminutiae = time;	
	#endif	

	#if TIME_COUNTER
		time = 0;
	#endif
	
	for (int x = 0; x < width; x++)
	{
		for (int y = 0; y < height; y++)
		{
			if (binaryMap_GetBit(&binmap, x, y))  thinning[y*width + x] = 0;
			else thinning[y*width + x] = 255;
		}
	}
	#if TIME_COUNTER
		process_time.others += time;	
	#endif	
	
	#if TIME_COUNTER
		time = 0;
	#endif
	
	Hybrid_thinning(thinning, width, height);
	
	#if TIME_COUNTER
		process_time.hybrid_getfeaturepoint_secondthinning = time;	
	#endif	
	
	#if TIME_COUNTER
		time = 0;
	#endif	
	
	Hybrid_FindMinutiae(thinning, featMask, width, height, feature0);
	
	#if TIME_COUNTER
		process_time.hybrid_getfeaturepoint_secondfindminutiae = time;	
	#endif
	
	free(bin);
	binaryMap_Destruct(&binmap);
#if 0
	feature0->MinutiaNum = feature1->MinutiaNum = 0;

	for (int i = 0; i < feat0.MinutiaNum; i++)
	{
		int x = feat0.MinutiaArr[i].x;
		int y = feat0.MinutiaArr[i].y;
		if (featMask[y*width + x] == 255 && feature0->MinutiaNum < MAXMINUTIANUM)
		{
			feature0->MinutiaArr[feature0->MinutiaNum] = feat0.MinutiaArr[i];
			feature0->MinutiaNum++;
		}
	}
	for (int i = 0; i < feat1.MinutiaNum; i++)
	{
		int x = feat1.MinutiaArr[i].x;
		int y = feat1.MinutiaArr[i].y;
		if (featMask[y*width + x] == 255 && feature1->MinutiaNum < MAXMINUTIANUM)
		{
			feature1->MinutiaArr[feature1->MinutiaNum] = feat1.MinutiaArr[i];
			feature1->MinutiaNum++;
		}
	}

	for (int i = 0; i < feat2.MinutiaNum; i++)
	{
		int x = feat2.MinutiaArr[i].x;
		int y = feat2.MinutiaArr[i].y;
		if (featMask[y*width + x] == 255 && feature1->MinutiaNum < MAXMINUTIANUM)
		{
			feature1->MinutiaArr[feature1->MinutiaNum] = feat2.MinutiaArr[i];
			feature1->MinutiaNum++;
		}
	}
#endif
}

/*
��ʴ����
@data [in]
@width [in]
@height [in]
@iterator [in] ��������,ÿ�ε������ڸ�ʴһ�����ص�
*/
void Hybrid_Erosion(binaryMap* data, int width, int height, int iterator)
{
	int i, j, m ; //, len;,index
	unsigned char p0, flag ;//p1, p2, p3, p4, p5, p6, p7, p8, ;
	p0 = /*p1 = p2 = p3 = p4 = p5 = p6 = p7 = p8 =*/ flag = 0;
	i = j = m = 0;//= index
	//len = width * height * sizeof(unsigned char);
	binaryMap tmpdata = binaryMap_Construct(width, height);

	for (m = 0; m < iterator; m++)
	{
		//memcpy_s((char*)tmpdata, len, (char*)data, len);
		binaryMap_CopyData(data, &tmpdata);

		for (i = 1; i < width - 1; i++)
		{
			flag = 0;
			for (j = 1; j < height - 1; j++)
			{
//			index = j * width + i;
				p0 = binaryMap_GetBit(&tmpdata, i, j);
				if(!p0)                                              // 只要3x3的方框的中心点为0，则将
				{                                                    // 方框中所有的点置0
					if(!flag)
					{
					  binaryMap_SetBit(data, i - 1, j - 1,0);
						binaryMap_SetBit(data, i, j - 1,0);
						binaryMap_SetBit(data, i + 1, j - 1,0);

						binaryMap_SetBit(data, i - 1, j,0); 
						binaryMap_SetBit(data, i + 1, j,0); 
					}
					binaryMap_SetBit(data, i - 1, j + 1,0); 
					binaryMap_SetBit(data, i, j + 1,0); 
					binaryMap_SetBit(data, i + 1, j + 1,0);
					flag = 1;
				}
				else
				{
					flag = 0;
				}
//				p1 = binaryMap_GetBit(&tmpdata, i - 1, j - 1);      // 只要在3x3的方框中有任意一个点为0，
//				p2 = binaryMap_GetBit(&tmpdata, i, j - 1);          // 则将这一点置0
//				p3 = binaryMap_GetBit(&tmpdata, i + 1, j - 1);
//				p4 = binaryMap_GetBit(&tmpdata, i - 1, j); 
//				p5 = binaryMap_GetBit(&tmpdata, i + 1, j);  
//				p6 = binaryMap_GetBit(&tmpdata, i - 1, j + 1); 
//				p7 = binaryMap_GetBit(&tmpdata, i, j + 1); 
//				p8 = binaryMap_GetBit(&tmpdata, i + 1, j + 1); 
//				flag = p0 & p1 & p2 & p3 & p4 & p5 & p6 & p7 & p8;
//				if (!flag)
//				{
//					binaryMap_SetBit(data, i, j, 0);
//				}
			}
		}
	}
	binaryMap_Destruct(&tmpdata);

}

#if USE_FLOAT_DOUBLE
/*
��ȡŷ����þ���������������
@desc11 [in] ������1
@num11 [in] �����Ӹ���1
@desc21 [in] ������2
@num21 [in] �����Ӹ���2
@matchpair [out] 1&2ƥ�������������
@return ����ƥ�������
*/
int Hybrid_get_colsest_pair(float *desc11, int num11, float *desc21, int num21, int *matchpair)
{
	int *dist_arr = (int*)malloc(num11*num21 * sizeof(int));
	int *flag_arr = (int*)malloc(num11*num21 * sizeof(int));
	memset(flag_arr, 0, num11*num21 * sizeof(int));
	memset(dist_arr, 0, num11*num21 * sizeof(int));
	for (int i = 0; i < num11; i++)
	{
		for (int j = 0; j < num21; j++)
		{
			dist_arr[i*num21 + j] = Hybrid_desc_dist_f_table(desc11 + i * descriptorSize, 
				desc21 + j * descriptorSize, descriptorSize);
		}
	}

	int pairnum = 0;
	for (int i = 0; i < num11; i++)
	{
		int mindis = 9999999;
		int minj = 0;
		for (int j = 0; j < num21; j++)
		{
			if (dist_arr[i*num21 + j] < mindis)
			{
				mindis = dist_arr[i*num21 + j];
				minj = j;
			}
		}
		if (dist_arr[i*num21 + minj] < MAX_EU_DIST)
		{
			matchpair[pairnum << 1] = i;
			matchpair[(pairnum << 1) + 1] = minj;
			pairnum++;
			flag_arr[i*num21 + minj] = 1;
		}
	}

	for (int j = 0; j < num21; j++)
	{
		int mindis = 9999999;
		int mini = 0;
		for (int i = 0; i < num11; i++)
		{
			if (dist_arr[i*num21 + j] < mindis)
			{
				mindis = dist_arr[i*num21 + j];
				mini = i;
			}
		}
		if (flag_arr[mini*num21 + j] == 0 && dist_arr[mini*num21 + j] < MAX_EU_DIST)
		{
			matchpair[pairnum << 1] = mini;
			matchpair[(pairnum << 1) + 1] = j;
			pairnum++;
			flag_arr[mini*num21 + j] = 1;
		}
	}

	free(dist_arr);
	free(flag_arr);

	return pairnum;
}
#endif
/*
��ȡŷ����þ���������������
@desc11 [in] ������1
@num11 [in] �����Ӹ���1
@desc21 [in] ������2
@num21 [in] �����Ӹ���2
@matchpair [out] 1&2ƥ�������������
@return ����ƥ�������
*/
int Hybrid_get_closest_pair_int(unsigned char *desc11, int num11, unsigned char *desc21, int num21, unsigned char *matchpair)
{
	int *dist_arr = (int*)malloc(num11*num21 * sizeof(int));
	//int *flag_arr = (int*)malloc(num11*num21 * sizeof(int));
	//memset(flag_arr, 0, num11*num21 * sizeof(int));
	memset(dist_arr, 0, num11*num21 * sizeof(int));
	for (int i = 0; i < num11; i++)
	{
		for (int j = 0; j < num21; j++)
		{
			dist_arr[i*num21 + j] = Hybrid_desc_dist_uc_table(desc11 + i * descriptorSize, desc21 + j * descriptorSize,
				descriptorSize);
		}
	}

	int min_third_val[3] = { 0,0,0 };
	int min_third_index[3] = {0,0,0};
	int tmp = 0;
	int pairnum = 0;
	for (int i = 0; i < num11; i++)
	{
		min_third_val[0] = min_third_val[1] = min_third_val[2] = 9999999;
		min_third_index[0] = min_third_index[1] = min_third_index[2] = 0;
//		int mindis = 9999999;
//		int minj = 0;
		for (int j = 0; j < num21; j++)
		{
			if (dist_arr[i*num21 + j] < min_third_val[2])
			{
				min_third_val[2] = dist_arr[i*num21 + j];
				min_third_index[2] = j;
				if (min_third_val[2] < min_third_val[1])
				{
					tmp = min_third_val[1];
					min_third_val[1] = min_third_val[2];
					min_third_val[2] = tmp;
					tmp = min_third_index[1];
					min_third_index[1] = min_third_index[2];
					min_third_index[2] = tmp;

					if (min_third_val[1] < min_third_val[0])
					{
						tmp = min_third_val[0];
						min_third_val[0] = min_third_val[1];
						min_third_val[1] = tmp;
						tmp = min_third_index[0];
						min_third_index[0] = min_third_index[1];
						min_third_index[1] = tmp;
					}
				}
			}
#if USE_LOW_DIST
			if (dist_arr[i*num21 + j] < EU_DIST_THR)
			{
				matchpair[pairnum << 1] = i;
				matchpair[(pairnum << 1) + 1] = j;
				pairnum++;
				flag_arr[i*num21 + j] = 1;
			}
#endif
		}
		//if (/*flag_arr[i*num21 + minj] == 0 &&*/ dist_arr[i*num21 + minj] < MAX_EU_DIST)
		//{
		//	matchpair[pairnum << 1] = i;
		//	matchpair[(pairnum << 1) + 1] = minj;
		//	pairnum++;
		//	flag_arr[i*num21 + minj] = 1;
		//}
		matchpair[pairnum << 1] = i;
		matchpair[(pairnum << 1) + 1] = min_third_index[0];
		pairnum++;
		matchpair[pairnum << 1] = i;
		matchpair[(pairnum << 1) + 1] = min_third_index[1];
		pairnum++;
		//matchpair[pairnum << 1] = i;
		//matchpair[(pairnum << 1) + 1] = min_third_index[2];
		//pairnum++;
	}

	for (int j = 0; j < num21; j++)
	{
		min_third_val[0] = min_third_val[1] = min_third_val[2] = 9999999;
		min_third_index[0] = min_third_index[1] = min_third_index[2] = 0;
//		int mindis = 9999999;
//		int mini = 0;
		for (int i = 0; i < num11; i++)
		{
			if (dist_arr[i*num21 + j] < min_third_val[2])
			{
				min_third_val[2] = dist_arr[i*num21 + j];
				min_third_index[2] = i;
				if (min_third_val[2] < min_third_val[1])
				{
					tmp = min_third_val[1];
					min_third_val[1] = min_third_val[2];
					min_third_val[2] = tmp;
					tmp = min_third_index[1];
					min_third_index[1] = min_third_index[2];
					min_third_index[2] = tmp;

					if (min_third_val[1] < min_third_val[0])
					{
						tmp = min_third_val[0];
						min_third_val[0] = min_third_val[1];
						min_third_val[1] = tmp;
						tmp = min_third_index[0];
						min_third_index[0] = min_third_index[1];
						min_third_index[1] = tmp;
					}
				}
			}
		}
		//if (/*flag_arr[mini*num21 + j] == 0 &&*/ dist_arr[mini*num21 + j] < MAX_EU_DIST)
		//{
		//	matchpair[pairnum << 1] = mini;
		//	matchpair[(pairnum << 1) + 1] = j;
		//	pairnum++;
		//	flag_arr[mini*num21 + j] = 1;
		//}

		matchpair[pairnum << 1] = min_third_index[0];
		matchpair[(pairnum << 1) + 1] = j;
		pairnum++;
		matchpair[pairnum << 1] = min_third_index[1];
		matchpair[(pairnum << 1) + 1] = j;
		pairnum++;
		//matchpair[pairnum << 1] = min_third_index[2];
		//matchpair[(pairnum << 1) + 1] = j;
		//pairnum++;
	}

	free(dist_arr);
	//free(flag_arr);

	return pairnum;
}

#if USE_FLOAT_DOUBLE
/*
�������ŷ����þ���
@desc1 [in] ������1
@desc2 [in] ������2
@d [in] ������ά��
@return �������ӵ�ŷ����þ���
*/
int Hybrid_desc_dist_f_table(float *desc1, float *desc2, int d)
{
	int dsq = 0;
	int diff = 0;

	for (int i = 0; i < d; )
	{
		diff = (int)(desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
		diff = (int)(desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
		diff = (int)(desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
		diff = (int)(desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
		diff = (int)(desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
		diff = (int)(desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
		diff = (int)(desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
		diff = (int)(desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
	}
	return dsq;
}
#endif
/*
�������ŷ����þ���
@desc1 [in] ������1
@desc2 [in] ������2
@d [in] ������ά��
@return �������ӵ�ŷ����þ���
*/
int Hybrid_desc_dist_uc_table(unsigned char *desc1, unsigned char *desc2, int d)
{
	int dsq = 0;
	int diff = 0;

	for (int i = 0; i < d; )
	{
		diff = (desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
		diff = (desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
		diff = (desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
		diff = (desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
		diff = (desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
		diff = (desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
		diff = (desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
		diff = (desc1[i] - desc2[i] + 512);
		dsq += squaredec_table[diff];
		i++;
	}
	return dsq;
}

#if USE_FLOAT_DOUBLE
/*
������ɸѡ,��������������ͼ��νṹɸѡ�������
@match_kp [in] ƥ���ϸ�ڵ��
@pair_num [in] ƥ���ϸ�ڵ������
@A [out] ��תƽ�ƾ���
@resultPair [out] ����ɸѡ��ϸ�ڵ������
@return ��������ƥ���ϸ�ڵ����;
*/
int Hybrid_filter_feat(MINUTIA *match_kp, int pair_num, float A[6], int* resultPair)
{
	int match_num = 0;

	if (pair_num < 3) return pair_num;
	float d1 = 0, d2 = 0;
	float sita1, sita2, dsita1, dsita2;

	float val[9] = { 0,0,0,0,0,0,0,0,0 };
	Matrix matResult, matA, matB, matInvB, matH;
	MatCreate(&matA, 3, 3);
	MatCreate(&matB, 3, 3);
	MatCreate(&matInvB, 3, 3);
	MatCreate(&matH, 3, 3);
	MatCreate(&matResult, 3, 3);

	MINUTIA *aligenKp2 = (MINUTIA*)malloc(pair_num * sizeof(MINUTIA));
	int *tmpPair = (int*)malloc(2 * pair_num * sizeof(int));

	for (int i = 0; i < pair_num - 2 && match_num < 20; i++)
	{
		for (int j = i + 1; j < pair_num - 1 && match_num < 20; j++)
		{
			for (int k = j + 1; k < pair_num && match_num < 20; k++)
			{
				MINUTIA p11 = match_kp[2 * i];
				MINUTIA p12 = match_kp[2 * j];
				MINUTIA p13 = match_kp[2 * k];

				MINUTIA p21 = match_kp[2 * i + 1];
				MINUTIA p22 = match_kp[2 * j + 1];
				MINUTIA p23 = match_kp[2 * k + 1];

				d1 = sqrtf((p11.x - p12.x)*(p11.x - p12.x) + (p11.y - p12.y)*(p11.y - p12.y));
				d2 = sqrtf((p21.x - p22.x)*(p21.x - p22.x) + (p21.y - p22.y)*(p21.y - p22.y));
				if (d1 < d2 - 3 || d1 > d2 + 3) continue;
				if (d1 < 3 && d2 < 3) continue;

				d1 = sqrtf((p11.x - p13.x)*(p11.x - p13.x) + (p11.y - p13.y)*(p11.y - p13.y));
				d2 = sqrtf((p21.x - p23.x)*(p21.x - p23.x) + (p21.y - p23.y)*(p21.y - p23.y));
				if (d1 < d2 - 3 || d1 > d2 + 3) continue;
				if (d1 < 3 && d2 < 3) continue;

				d1 = sqrtf((p12.x - p13.x)*(p12.x - p13.x) + (p12.y - p13.y)*(p12.y - p13.y));
				d2 = sqrtf((p22.x - p23.x)*(p22.x - p23.x) + (p22.y - p23.y)*(p22.y - p23.y));
				if (d1 < d2 - 3 || d1 > d2 + 3) continue;
				if (d1 < 3 && d2 < 3) continue;

				sita1 = atan2f(p11.y - p12.y, p11.x - p12.x);
				sita2 = atan2f(p11.y - p13.y, p11.x - p13.x);
				dsita1 = sita1 - sita2;
				if (dsita1 > PI) dsita1 -= (float)(2 * PI);
				if (dsita1 < -PI) dsita1 += (float)(2 * PI);

				sita1 = atan2f(p21.y - p22.y, p21.x - p22.x);
				sita2 = atan2f(p21.y - p23.y, p21.x - p23.x);
				dsita2 = sita1 - sita2;
				if (dsita2 > PI) dsita2 -= (float)(2 * PI);
				if (dsita2 < -PI) dsita2 += (float)(2 * PI);

				if (fabs(dsita1 - dsita2) > PI / 36) continue;

				sita1 = atan2f(p12.y - p11.y, p12.x - p11.x);
				sita2 = atan2f(p12.y - p13.y, p12.x - p13.x);
				dsita1 = sita1 - sita2;
				if (dsita1 > PI) dsita1 -= (float)(2 * PI);
				if (dsita1 < -PI) dsita1 += (float)(2 * PI);

				sita1 = atan2f(p22.y - p21.y, p22.x - p21.x);
				sita2 = atan2f(p22.y - p23.y, p22.x - p23.x);
				dsita2 = sita1 - sita2;
				if (dsita2 > PI) dsita2 -= (float)(2 * PI);
				if (dsita2 < -PI) dsita2 += (float)(2 * PI);

				if (fabs(dsita1 - dsita2) > PI / 36) continue;

				val[0] = p11.x;
				val[1] = p12.x;
				val[2] = p13.x;

				val[3] = p11.y;
				val[4] = p12.y;
				val[5] = p13.y;

				val[6] = 1;
				val[7] = 1;
				val[8] = 1;

				MatSetVal(&matA, val);

				val[0] = p21.x;
				val[1] = p22.x;
				val[2] = p23.x;

				val[3] = p21.y;
				val[4] = p22.y;
				val[5] = p23.y;

				val[6] = 1;
				val[7] = 1;
				val[8] = 1;

				MatSetVal(&matB, val);

				if (MatInv(&matB, &matInvB) == NULL)
				{
					continue;
				}

				MatMul(&matA, &matInvB, &matH);

				float fd1 = matH.element[0][0] * matH.element[0][0] + matH.element[0][1] * matH.element[0][1];
				float fd2 = matH.element[1][0] * matH.element[1][0] + matH.element[1][1] * matH.element[1][1];
				if (fd1 > 1.1 || fd1 < 0.9 || fd2 > 1.1 || fd2 < 0.9)/*����̫������*/
				{
					continue;
				}

				/*kp2 ͨ��matH �任�� kp1����*/
				for (int ii = 0; ii < pair_num; ii++)
				{
					int jj = 2 * ii + 1;
					aligenKp2[ii] = match_kp[jj];
					aligenKp2[ii].x = matH.element[0][0] * match_kp[jj].x + matH.element[0][1] * match_kp[jj].y + matH.element[0][2];
					aligenKp2[ii].y = matH.element[1][0] * match_kp[jj].x + matH.element[1][1] * match_kp[jj].y + matH.element[1][2];
				}

				/*�任��������ϵĵ���*/
				int matchNum = 0;
				for (int ii = 0; ii < pair_num; ii++)
				{
					int jj = 2 * ii;
					float dis = sqrtf((match_kp[jj].x - aligenKp2[ii].x)*(match_kp[jj].x - aligenKp2[ii].x)
						+ (match_kp[jj].y - aligenKp2[ii].y)*(match_kp[jj].y - aligenKp2[ii].y));
					if (dis < 3)
					{
						tmpPair[2 * matchNum] = 2 * ii;
						tmpPair[2 * matchNum + 1] = 2 * ii + 1;
						matchNum++;
					}
				}

				if (matchNum > match_num)
				{
					match_num = matchNum;
					memcpy(resultPair, tmpPair, 2 * pair_num * sizeof(int));
					MatCopy(&matH, &matResult);
				}
			}
		}
	}
	free(aligenKp2);
	free(tmpPair);

	A[0] = matResult.element[0][0];
	A[1] = matResult.element[0][1];
	A[2] = matResult.element[0][2];
	A[3] = matResult.element[1][0];
	A[4] = matResult.element[1][1];
	A[5] = matResult.element[1][2];

	MatDelete(&matResult);
	MatDelete(&matA);
	MatDelete(&matB);
	MatDelete(&matInvB);
	MatDelete(&matH);

	return match_num;
}
#endif

/*
����������ɸѡ,��������������ͼ��νṹɸѡ�������
@match_kp [in] ƥ���ϸ�ڵ��
@pair_num [in] ƥ���ϸ�ڵ������
@A [out] ��תƽ�ƾ���(����)
@oDet [out] ��תƽ�ƾ���A�ķ�ĸ
@resultPair [out] ����ɸѡ��ϸ�ڵ������
@return ��������ƥ���ϸ�ڵ����;
*/
int Hybrid_filter_feat_int(void *match_kpi, int pair_num, int A[6], int *oDet, int* resultPair)
{
	MINUTIA *match_kp = (MINUTIA *)match_kpi;
	int match_num = 0;

	if (pair_num < 3) return pair_num;
	int d1 = 0, d2 = 0;
	int sita1, sita2, dsita1, dsita2, ddsita;
	int val[9] = { 0,0,0,0,0,0,0,0,0 };
	int diffx1, diffx2, diffy1, diffy2;
	int line_err_thr = 0, match_dis_err_thr = 0;
	int tmpx, tmpy;

	Matrix_int matResult, matA, matB, matInvB, matH;
	MatCreate_int(&matA, 3, 3);
	MatCreate_int(&matB, 3, 3);
	MatCreate_int(&matInvB, 3, 3);
	MatCreate_int(&matH, 3, 3);
	MatCreate_int(&matResult, 3, 3);

	MINUTIA *aligenKp2 = (MINUTIA*)malloc(pair_num * sizeof(MINUTIA));
	int *tmpPair = (int*)malloc(2 * pair_num * sizeof(int));

	/*�Ŵ�8��*/
	line_err_thr = FILTER_FEATER_LINE_ERR * 8;
	match_dis_err_thr = FILTER_FEATER_MATCH_DIST * 8;

	for (int i = 0; i < pair_num - 2 && match_num < FILTER_FEATER_THR; i++)
	{
		MINUTIA p11 = match_kp[ i << 1];
		MINUTIA p21 = match_kp[ (i << 1) + 1];

		for (int j = i + 1; j < pair_num - 1 && match_num < FILTER_FEATER_THR; j++)
		{
			MINUTIA p12 = match_kp[j << 1];
			MINUTIA p22 = match_kp[(j << 1) + 1];

			diffx1 = p11.x - p12.x;
			diffy1 = p11.y - p12.y;
			diffx2 = p21.x - p22.x;
			diffy2 = p21.y - p22.y;
			/*�Ŵ�8��,�����ڷŴ�64��*/
			d1 = SqrtNiudun((diffx1*diffx1 + diffy1*diffy1) << 6);
			d2 = SqrtNiudun((diffx2*diffx2 + diffy2*diffy2) << 6);
			if (d1 < d2 - line_err_thr || d1 > d2 + line_err_thr) continue;
			if (d1 < line_err_thr && d2 < line_err_thr) continue;

			sita1 = search_atan_table(diffy1>>1, diffx1>>1); //atan_int_table_angle2[(p11.y - p12.y + 256) >> 1][(p11.x - p12.x + 256) >> 1];
			sita2 = search_atan_table(diffy2>>1, diffx2>>1); // atan_int_table_angle2[(p21.y - p22.y + 256) >> 1][(p21.x - p22.x + 256) >> 1];
			dsita1 = p11.Direction - sita1;
			if (dsita1 < 0) dsita1 += 360;
			dsita2 = p21.Direction - sita2;
			if (dsita2 < 0) dsita2 += 360;
			ddsita = abs(dsita1 - dsita2);
			ddsita = min(ddsita, 360 - ddsita);
			if (ddsita > FILTER_FEATER_ANGLE_ERR) continue;

			dsita1 = p12.Direction - sita1;
			if (dsita1 < 0) dsita1 += 360;
			dsita2 = p22.Direction - sita2;
			if (dsita2 < 0) dsita2 += 360;
			ddsita = abs(dsita1 - dsita2);
			ddsita = min(ddsita, 360 - ddsita);
			if (ddsita > FILTER_FEATER_ANGLE_ERR) continue;

			for (int k = j + 1; k < pair_num && match_num < FILTER_FEATER_THR; k++)
			{
				
				MINUTIA p13 = match_kp[k << 1];
				MINUTIA p23 = match_kp[(k << 1) + 1];

				diffx1 = p11.x - p13.x;
				diffy1 = p11.y - p13.y;
				diffx2 = p21.x - p23.x;
				diffy2 = p21.y - p23.y;

				d1 = SqrtNiudun((diffx1*diffx1 + diffy1 * diffy1) << 6);
				d2 = SqrtNiudun((diffx2*diffx2 + diffy2 * diffy2) << 6);
				if (d1 < d2 - line_err_thr || d1 > d2 + line_err_thr) continue;
				if (d1 < line_err_thr && d2 < line_err_thr) continue;

				diffx1 = p12.x - p13.x;
				diffy1 = p12.y - p13.y;
				diffx2 = p22.x - p23.x;
				diffy2 = p22.y - p23.y;

				d1 = SqrtNiudun((diffx1*diffx1 + diffy1 * diffy1) << 6);
				d2 = SqrtNiudun((diffx2*diffx2 + diffy2 * diffy2) << 6);
				if (d1 < d2 - line_err_thr || d1 > d2 + line_err_thr) continue;
				if (d1 < line_err_thr && d2 < line_err_thr) continue;
#if 0
				sita1 = atan_int_table_angle[(p11.y - p12.y + 256) >> 1][(p11.x - p12.x + 256) >> 1];
				sita2 = atan_int_table_angle[(p11.y - p13.y + 256) >> 1][(p11.x - p13.x + 256) >> 1];
				dsita1 = sita1 - sita2;
				sita1 = atan_int_table_angle[(p21.y - p22.y + 256) >> 1][(p21.x - p22.x + 256) >> 1];
				sita2 = atan_int_table_angle[(p21.y - p23.y + 256) >> 1][(p21.x - p23.x + 256) >> 1];
				dsita2 = sita1 - sita2;
				ddsita = abs(dsita1 - dsita2);
				ddsita = min(ddsita, 360 - ddsita);
				if (ddsita > FILTER_FEATER_ANGLE_ERR) continue;

				sita1 = atan_int_table_angle[(p12.y - p11.y + 256) >> 1][(p12.x - p11.x + 256) >> 1];
				sita2 = atan_int_table_angle[(p12.y - p13.y + 256) >> 1][(p12.x - p13.x + 256) >> 1];
				dsita1 = sita1 - sita2;
				sita1 = atan_int_table_angle[(p22.y - p21.y + 256) >> 1][(p22.x - p21.x + 256) >> 1];
				sita2 = atan_int_table_angle[(p22.y - p23.y + 256) >> 1][(p22.x - p23.x + 256) >> 1];
				dsita2 = sita1 - sita2;
				ddsita = abs(dsita1 - dsita2);
				ddsita = min(ddsita, 360 - ddsita);
				if (ddsita > FILTER_FEATER_ANGLE_ERR) continue;
#else
				dsita1 = p13.Direction - sita1;
				if (dsita1 < 0) dsita1 += 360;
				dsita2 = p23.Direction - sita2;
				if (dsita2 < 0) dsita2 += 360;
				ddsita = abs(dsita1 - dsita2);
				ddsita = min(ddsita, 360 - ddsita);
				if (ddsita > FILTER_FEATER_ANGLE_ERR) continue;
#endif
				val[0] = p11.x;
				val[1] = p12.x;
				val[2] = p13.x;
				val[3] = p11.y;
				val[4] = p12.y;
				val[5] = p13.y;
				val[6] = 1;
				val[7] = 1;
				val[8] = 1;
				MatSetVal_int(&matA, val);

				val[0] = p21.x;
				val[1] = p22.x;
				val[2] = p23.x;
				val[3] = p21.y;
				val[4] = p22.y;
				val[5] = p23.y;
				val[6] = 1;
				val[7] = 1;
				val[8] = 1;
				MatSetVal_int(&matB, val);

				/*matInvB ֵ�Ŵ�1024��*/
				int Det = 0;
				if (MatInv_int(&matB, &matInvB,&Det) == NULL)
				{
					continue;
				}

				/*matH ֵҲ���ŷŴ�1024��*/
				MatMul_int(&matA, &matInvB, &matH);
#if 1
				int absDet = abs(Det);
				int fd1 = ((matH.element[0][0] * matH.element[0][0])/ absDet
					+ (matH.element[0][1] * matH.element[0][1])/ absDet);
				int fd2 = ((matH.element[1][0] * matH.element[1][0])/ absDet
					+ (matH.element[1][1] * matH.element[1][1])/ absDet);
				if (fd1 > (absDet*FILTER_FEATER_WRAP_MAX) || fd1 < (absDet*FILTER_FEATER_WRAP_MIN) ||
					fd2 > (absDet*FILTER_FEATER_WRAP_MAX) || fd2 < (absDet*FILTER_FEATER_WRAP_MIN))/*����̫������*/
				{
					continue;
				}
#endif
				/*kp2 ͨ��matH �任�� kp1����*/
				for (int ii = 0; ii < pair_num; ii++)
				{
					int jj = (ii << 1)+ 1;
					aligenKp2[ii] = match_kp[jj];
					tmpx = matH.element[0][0] * match_kp[jj].x + matH.element[0][1] * match_kp[jj].y + matH.element[0][2];
					aligenKp2[ii].x = tmpx / Det;
					tmpy = matH.element[1][0] * match_kp[jj].x + matH.element[1][1] * match_kp[jj].y + matH.element[1][2];
					aligenKp2[ii].y = tmpy / Det;
				}

				/*�任��������ϵĵ���*/
				int matchNum = 0;
				for (int ii = 0; ii < pair_num; ii++)
				{
					int jj = ii << 1;
					diffx1 = (match_kp[jj].x - aligenKp2[ii].x);
					diffy1 = (match_kp[jj].y - aligenKp2[ii].y);
					/*�Ŵ�8��*/
					int dis = SqrtNiudun((diffx1*diffx1 + diffy1*diffy1)<<6);
					if (dis < match_dis_err_thr)
					{
						tmpPair[matchNum << 1] = jj;
						tmpPair[(matchNum << 1)+ 1] = jj + 1;
						matchNum++;
					}
				}

				if (matchNum > match_num)
				{
					match_num = matchNum;
					memcpy(resultPair, tmpPair, 2 * pair_num * sizeof(int));
					MatCopy_int(&matH, &matResult);
					*oDet = Det;
				}
			}
		}
	}
	free(aligenKp2);
	free(tmpPair);

	A[0] = matResult.element[0][0];
	A[1] = matResult.element[0][1];
	A[2] = matResult.element[0][2];
	A[3] = matResult.element[1][0];
	A[4] = matResult.element[1][1];
	A[5] = matResult.element[1][2];

	MatDelete_int(&matResult);
	MatDelete_int(&matA);
	MatDelete_int(&matB);
	MatDelete_int(&matInvB);
	MatDelete_int(&matH);
	return match_num;
}

/*���ٰ�,�ÿռ任ʱ��*/
int Hybrid_filter_feat_int_fast(void *match_kpi, int pair_num, int A[6], int *oDet, int* resultPair)
{
	MINUTIA *match_kp = (MINUTIA *)match_kpi;
	int match_num = 0;

	if (pair_num < 3) return pair_num;
	int d1 = 0, d2 = 0;
	int sita1, sita2, dsita1, dsita2, ddsita;
	int val[9] = { 0,0,0,0,0,0,0,0,0 };
	int diffx1, diffx2, diffy1, diffy2;
	int line_err_thr = 0, match_dis_err_thr = 0;
	int tmpx, tmpy;

	Matrix_int matResult, matA, matB, matInvB, matH;
	MatCreate_int(&matA, 3, 3);
	MatCreate_int(&matB, 3, 3);
	MatCreate_int(&matInvB, 3, 3);
	MatCreate_int(&matH, 3, 3);
	MatCreate_int(&matResult, 3, 3);

	MINUTIA *aligenKp2 = (MINUTIA*)malloc(pair_num * sizeof(MINUTIA));
	int *tmpPair = (int*)malloc(2 * pair_num * sizeof(int));

	/*�Ŵ�8��*/
	line_err_thr = FILTER_FEATER_LINE_ERR * 8 ;
	match_dis_err_thr = FILTER_FEATER_MATCH_DIST * 8;

	//unsigned char *line_dis_err_arr = (unsigned char*)malloc(pair_num*pair_num * sizeof(unsigned char));
	//memset(line_dis_err_arr, 0, pair_num*pair_num * sizeof(unsigned char));
#if 0
	for (int i = 0; i < pair_num; i++)
	{
		MINUTIA p11 = match_kp[i << 1];
		MINUTIA p21 = match_kp[(i << 1) + 1];
		for (int j = 0; j < pair_num; j++)
		{
			MINUTIA p12 = match_kp[j << 1];
			MINUTIA p22 = match_kp[(j << 1) + 1];

			diffx1 = p11.x - p12.x;
			diffy1 = p11.y - p12.y;
			diffx2 = p21.x - p22.x;
			diffy2 = p21.y - p22.y;

			/*�Ŵ�8��,�����ڷŴ�64��*/
			//d1 = SqrtNiudun((diffx1 + diffy1) << 6);
			//d2 = SqrtNiudun((diffx2 + diffy2) << 6);

			d1 = square_root_table_uc[diffx1 / 2 + 128][diffy1 / 2 + 128] *2;
			d2 = square_root_table_uc[diffx2 / 2 + 128][diffy2 / 2 + 128] *2;

			if (d1 < line_err_thr && d2 < line_err_thr)
			{
				line_dis_err_arr[i * pair_num + j] =1;
			}
			else if( abs(d1 - d2) < line_err_thr)
			{
				line_dis_err_arr[i * pair_num + j] = 0;
			}
			else
			{
				line_dis_err_arr[i * pair_num + j] = 1;
			}
		}
	}
#endif
	//FILTER_FEATER_THR
	for (int i = 0; i < pair_num - 2 && match_num < FILTER_FEATER_THR; i++)
	{
		MINUTIA p11 = match_kp[i << 1];
		MINUTIA p21 = match_kp[(i << 1) + 1];

		for (int j = i + 1; j < pair_num - 1 && match_num < FILTER_FEATER_THR; j++)
		{
			MINUTIA p12 = match_kp[j << 1];
			MINUTIA p22 = match_kp[(j << 1) + 1];
#if 1
			diffx1 = p11.x - p12.x;
			diffy1 = p11.y - p12.y;
			diffx2 = p21.x - p22.x;
			diffy2 = p21.y - p22.y;
			/*�Ŵ�8��,�����ڷŴ�64��*/
			//d1 = fast_sqrt_root(diffx1, diffy1);//square_root_table_uc[diffx1 / 2 + 128][diffy1 / 2 + 128] * 2;
			//d2 = fast_sqrt_root(diffx2, diffy2);//square_root_table_uc[diffx2 / 2 + 128][diffy2 / 2 + 128] * 2;
			d1 = square_root_table_short_8[abs(diffx1)][abs(diffy1)];
			d2 = square_root_table_short_8[abs(diffx2)][abs(diffy2)];
			if (d1 < d2 - line_err_thr || d1 > d2 + line_err_thr) continue;
			if (d1 < line_err_thr && d2 < line_err_thr) continue;
#endif
			//if (line_dis_err_arr[i * pair_num + j]) continue;

			sita1 = search_atan_table(diffy1>>1, diffx1>>1);//atan_int_table_angle2[(p11.y - p12.y + 256) >> 1][(p11.x - p12.x + 256) >> 1];
			sita2 = search_atan_table(diffy2>>1, diffx2>>1);//atan_int_table_angle2[(p21.y - p22.y + 256) >> 1][(p21.x - p22.x + 256) >> 1];
			dsita1 = p11.Direction - sita1;
			if (dsita1 < 0) dsita1 += 360;
			dsita2 = p21.Direction - sita2;
			if (dsita2 < 0) dsita2 += 360;
			ddsita = abs(dsita1 - dsita2);
			ddsita = min(ddsita, 360 - ddsita);
			if (ddsita > FILTER_FEATER_ANGLE_ERR) continue;

			dsita1 = p12.Direction - sita1;
			if (dsita1 < 0) dsita1 += 360;
			dsita2 = p22.Direction - sita2;
			if (dsita2 < 0) dsita2 += 360;
			ddsita = abs(dsita1 - dsita2);
			ddsita = min(ddsita, 360 - ddsita);
			if (ddsita > FILTER_FEATER_ANGLE_ERR) continue;

			for (int k = j + 1; k < pair_num && match_num < FILTER_FEATER_THR; k++)
			{

				MINUTIA p13 = match_kp[k << 1];
				MINUTIA p23 = match_kp[(k << 1) + 1];
#if 1
				diffx1 = p11.x - p13.x;
				diffy1 = p11.y - p13.y;
				diffx2 = p21.x - p23.x;
				diffy2 = p21.y - p23.y;

				//d1 = fast_sqrt_root(diffx1, diffy1);//square_root_table_uc[diffx1 / 2 + 128][diffy1 / 2 + 128] * 2;
				//d2 = fast_sqrt_root(diffx2, diffy2);//square_root_table_uc[diffx2 / 2 + 128][diffy2 / 2 + 128] * 2;
				d1 = square_root_table_short_8[abs(diffx1)][abs(diffy1)];
				d2 = square_root_table_short_8[abs(diffx2)][abs(diffy2)];
				if (d1 < d2 - line_err_thr || d1 > d2 + line_err_thr) continue;
				if (d1 < line_err_thr && d2 < line_err_thr) continue;

				diffx1 = p12.x - p13.x;
				diffy1 = p12.y - p13.y;
				diffx2 = p22.x - p23.x;
				diffy2 = p22.y - p23.y;

				//d1 = fast_sqrt_root(diffx1, diffy1);//square_root_table_uc[diffx1 / 2 + 128][diffy1 / 2 + 128] * 2;
				//d2 = fast_sqrt_root(diffx2, diffy2);//square_root_table_uc[diffx2 / 2 + 128][diffy2 / 2 + 128] * 2;
				d1 = square_root_table_short_8[abs(diffx1)][abs(diffy1)];
				d2 = square_root_table_short_8[abs(diffx2)][abs(diffy2)];
				if (d1 < d2 - line_err_thr || d1 > d2 + line_err_thr) continue;
				if (d1 < line_err_thr && d2 < line_err_thr) continue;
#endif
				//if (line_dis_err_arr[i * pair_num + k]) continue;
				//if (line_dis_err_arr[j * pair_num + k]) continue;

				dsita1 = p13.Direction - sita1;
				if (dsita1 < 0) dsita1 += 360;
				dsita2 = p23.Direction - sita2;
				if (dsita2 < 0) dsita2 += 360;
				ddsita = abs(dsita1 - dsita2);
				ddsita = min(ddsita, 360 - ddsita);
				if (ddsita > FILTER_FEATER_ANGLE_ERR) continue;

				val[0] = p11.x;
				val[1] = p12.x;
				val[2] = p13.x;
				val[3] = p11.y;
				val[4] = p12.y;
				val[5] = p13.y;
				val[6] = 1;
				val[7] = 1;
				val[8] = 1;
				MatSetVal_int(&matA, val);

				val[0] = p21.x;
				val[1] = p22.x;
				val[2] = p23.x;
				val[3] = p21.y;
				val[4] = p22.y;
				val[5] = p23.y;
				val[6] = 1;
				val[7] = 1;
				val[8] = 1;
				MatSetVal_int(&matB, val);

				/*matInvB ֵ�Ŵ�1024��*/
				int Det = 0;
				if (MatInv_int(&matB, &matInvB, &Det) == NULL)
				{
					continue;
				}

				/*matH ֵҲ���ŷŴ�1024��*/
				MatMul_int(&matA, &matInvB, &matH);
#if 1
				int absDet = abs(Det);
				int fd1 = ((matH.element[0][0] * matH.element[0][0]) / absDet
					+ (matH.element[0][1] * matH.element[0][1]) / absDet);
				int fd2 = ((matH.element[1][0] * matH.element[1][0]) / absDet
					+ (matH.element[1][1] * matH.element[1][1]) / absDet);
				if (fd1 > (absDet*FILTER_FEATER_WRAP_MAX) || fd1 < (absDet*FILTER_FEATER_WRAP_MIN) ||
					fd2 >(absDet*FILTER_FEATER_WRAP_MAX) || fd2 < (absDet*FILTER_FEATER_WRAP_MIN))/*����̫������*/
				{
					continue;
				}
#endif
				/*kp2 ͨ��matH �任�� kp1����*/
				for (int ii = 0; ii < pair_num; ii++)
				{
					int jj = (ii << 1) + 1;
					aligenKp2[ii] = match_kp[jj];
					tmpx = matH.element[0][0] * match_kp[jj].x + matH.element[0][1] * match_kp[jj].y + matH.element[0][2];
					aligenKp2[ii].x = tmpx / Det;
					tmpy = matH.element[1][0] * match_kp[jj].x + matH.element[1][1] * match_kp[jj].y + matH.element[1][2];
					aligenKp2[ii].y = tmpy / Det;
				}

				/*�任��������ϵĵ���*/
				int matchNum = 0;
				for (int ii = 0; ii < pair_num; ii++)
				{
					int jj = ii << 1;
					/*�Ŵ�8��*/
					diffx1 = (match_kp[jj].x - aligenKp2[ii].x);
					diffy1 = (match_kp[jj].y - aligenKp2[ii].y);
					//int dis = SqrtNiudun((diffx1*diffx1 + diffy1 * diffy1) << 6);
					/*������ת���и���,diffx1,diffy1�ķ�Χ�ᳬ��192,���ﲻ���ò��*/
					int dis = fast_sqrt_root(diffx1, diffy1);// square_root_table_uc[diffx1 / 2 + 128][diffy1 / 2 + 128] * 16;
					//int dis = square_root_table_short_8[abs(diffx1)][abs(diffy1)];
					if (dis < match_dis_err_thr)
					{
						tmpPair[matchNum << 1] = jj;
						tmpPair[(matchNum << 1) + 1] = jj + 1;
						matchNum++;
					}
				}

				if (matchNum > match_num)
				{
					match_num = matchNum;
					memcpy(resultPair, tmpPair, 2 * pair_num * sizeof(int));
					MatCopy_int(&matH, &matResult);
					*oDet = Det;
				}
			}
		}
	}
	free(aligenKp2);
	free(tmpPair);
	//free(line_dis_err_arr);

	A[0] = matResult.element[0][0];
	A[1] = matResult.element[0][1];
	A[2] = matResult.element[0][2];
	A[3] = matResult.element[1][0];
	A[4] = matResult.element[1][1];
	A[5] = matResult.element[1][2];

	MatDelete_int(&matResult);
	MatDelete_int(&matA);
	MatDelete_int(&matB);
	MatDelete_int(&matInvB);
	MatDelete_int(&matH);
	return match_num;
}


/*sigma = 1 的高斯模糊, 整形运算*/
/*[-3*sigma, 3*sigma]窗口大小  WindowSize = (1 + 2 * 3*1) = 7*/
/*1维高斯滤波参数放大1024倍*/
#define gauss_len  7 //11
//static int gauss_weight[gauss_len] = {2,11,44,117,210,255,210,117,44,11,2};/*sigma = 1.6*/
const int gauss_weight[gauss_len] = { 5,55,248,409,248,55,5};
const int gauss_weight_sum = 1025;

int INT_GaussSmooth(unsigned char *pUnchImg, unsigned char *pUnchSmthdImg, int nWidth, int nHeight)
{
	int x = 0, y = 0; //i = 0;
	//int nWindowSize = gauss_len, 
	int nHalfLen = 0;
	int dDotMul = 0, dWeightSum = 0;
	unsigned char *pdTmp = NULL;
  int temp = 0;
	nHalfLen = gauss_len / 2;
	pdTmp = (unsigned char*)malloc(nWidth*nHeight * sizeof(unsigned char));
	memset(pdTmp, 0, nWidth*nHeight * sizeof(unsigned char));

	// x方向进行滤波
	for (y = 4; y < nHeight-4; y++)
	{
		for (x = 4; x < nWidth-4; x++)
		{
			dDotMul = 0;
			dWeightSum = 0;
			temp = y*nWidth + x;
			dDotMul += pUnchImg[temp-3] * gauss_weight[0];
			dDotMul += pUnchImg[temp-2] * gauss_weight[1];
			dDotMul += pUnchImg[temp-1] * gauss_weight[2];				
			dDotMul += pUnchImg[temp]   * gauss_weight[3];				
			dDotMul += pUnchImg[temp+1] * gauss_weight[4];				
			dDotMul += pUnchImg[temp+2] * gauss_weight[5];				
			dDotMul += pUnchImg[temp+3] * gauss_weight[6];
			pdTmp[temp] = (unsigned char)(dDotMul/ gauss_weight_sum);
		}
	}

	// y方向进行滤波
	for (x = 4; x<nWidth-4; x++)
	{
		for (y = 4; y<nHeight-4; y++)
		{
			dDotMul = 0;
			dWeightSum = 0;
			temp = y*nWidth + x;
			dDotMul += pdTmp[temp-3*nWidth] * gauss_weight[0];
			dDotMul += pdTmp[temp-2*nWidth] * gauss_weight[1];			
			dDotMul += pdTmp[temp-nWidth]   * gauss_weight[2];				
			dDotMul += pdTmp[temp]          * gauss_weight[3];			
			dDotMul += pdTmp[temp+nWidth]   * gauss_weight[4];				
			dDotMul += pdTmp[temp+2*nWidth] * gauss_weight[5];			
			dDotMul += pdTmp[temp+3*nWidth] * gauss_weight[6];
			pUnchSmthdImg[temp] = (unsigned char)(dDotMul / gauss_weight_sum);
		}
	}
	free(pdTmp);
	return 0;
}
//int INT_GaussSmooth(unsigned char *pUnchImg, unsigned char *pUnchSmthdImg, int nWidth, int nHeight)
//{
//	int x = 0, y = 0, i = 0;
//	//int nWindowSize = gauss_len, 
//	int nHalfLen = 0;
//	int dDotMul = 0, dWeightSum = 0;
//	unsigned char *pdTmp = NULL;

//	nHalfLen = gauss_len / 2;
//	pdTmp = (unsigned char*)malloc(nWidth*nHeight * sizeof(unsigned char));
//	memset(pdTmp, 0, nWidth*nHeight * sizeof(unsigned char));

//	// x方向进行滤波
//	for (y = 0; y < nHeight; y++)
//	{
//		for (x = 0; x < nWidth; x++)
//		{
//			dDotMul = 0;
//			dWeightSum = 0;
//			for (i = (-nHalfLen); i <= nHalfLen; i++)
//			{
//				// 判断是否在图像内部
//				if ((i + x) >= 0 && (i + x) < nWidth)
//				{
//					dDotMul += pUnchImg[y*nWidth + (i + x)] * gauss_weight[nHalfLen + i];
//					dWeightSum += gauss_weight[nHalfLen + i];
//				}
//			}
//			pdTmp[y*nWidth + x] = (unsigned char)(dDotMul/ dWeightSum);
//		}
//	}

//	// y方向进行滤波
//	for (x = 0; x<nWidth; x++)
//	{
//		for (y = 0; y<nHeight; y++)
//		{
//			dDotMul = 0;
//			dWeightSum = 0;
//			for (i = (-nHalfLen); i <= nHalfLen; i++)
//			{
//				// 判断是否在图像内部
//				if ((i + y) >= 0 && (i + y) < nHeight)
//				{
//					dDotMul += pdTmp[(y + i)*nWidth + x] * gauss_weight[nHalfLen + i];
//					dWeightSum += gauss_weight[nHalfLen + i];
//				}
//			}
//			pUnchSmthdImg[y*nWidth + x] = (unsigned char)(dDotMul / dWeightSum);
//		}
//	}
//	free(pdTmp);
//	return 0;
//}

int Hybrid_mosaic(void *baseft1, void *baseft2, unsigned char *basedesc1[NUM_IN_ONE_GROUP], unsigned char *basedesc2[NUM_IN_ONE_GROUP],
	void *addft1, void *addft2, unsigned char *adddesc1[NUM_IN_ONE_GROUP], unsigned char *adddesc2[NUM_IN_ONE_GROUP])
{
	int matchnum1, matchnum2;
	unsigned char resultpair1[MAXMINUTIANUM * 2], resultpair2[MAXMINUTIANUM * 2];
	int A[6];
	int Det;
	int matchscore = Hybrid_match_desc_int(baseft1, baseft2, basedesc1, basedesc2, addft1, addft2, adddesc1, adddesc2,
		resultpair1, resultpair2,&matchnum1,&matchnum2,A,&Det);
	if (matchscore < MOSAIC_THR) return -1;

	FEATURE *feature11 = (FEATURE *)baseft1;
	FEATURE *feature12 = (FEATURE *)baseft2;
	FEATURE *feature21 = (FEATURE *)addft1;
	FEATURE *feature22 = (FEATURE *)addft2;

	int num11, num12, num21, num22;
	num11 = feature11[0].MinutiaNum;
	num12 = feature12[0].MinutiaNum;
	num21 = feature21[0].MinutiaNum;
	num22 = feature22[0].MinutiaNum;

	unsigned char addflag[MAXMINUTIANUM] = {0};
	memset(addflag, 0, MAXMINUTIANUM * sizeof(unsigned char));
	int addNum1 = num21 - matchnum1;
	if (num11 + addNum1 > MAXMINUTIANUM) addNum1 = MAXMINUTIANUM - num11;
	if (addNum1 > 0)
	{
		for (int i = 0; i < matchnum1; i++)
		{
			int idex = resultpair1[2 * i + 1];
			addflag[idex] = 1;
		}
		for (int i = 0; i < 5; i++)
		{
			unsigned char *newdesc1 = (unsigned char*)malloc((num11 + addNum1)*descriptorSize * sizeof(unsigned char));
			memset(newdesc1, 0, (num11 + addNum1)*descriptorSize * sizeof(unsigned char));
			memcpy(newdesc1, basedesc1[i], num11*descriptorSize * sizeof(unsigned char));
			free(basedesc1[i]); basedesc1[i] = NULL;
			basedesc1[i] = newdesc1;
		}
		for (int i = 0; i < num21; i++)
		{
			if (addflag[i]) continue;
			if (num11 >= MAXMINUTIANUM) continue;
			feature11[0].MinutiaArr[num11] = feature21[0].MinutiaArr[i];
			feature11[0].MinutiaArr[num12].x = A[0] * feature21[0].MinutiaArr[i].x + A[1] * feature21[0].MinutiaArr[i].y + A[2];
			feature11[0].MinutiaArr[num12].y = A[3] * feature21[0].MinutiaArr[i].x + A[4] * feature21[0].MinutiaArr[i].y + A[5];
			feature11[0].MinutiaArr[num12].x /= Det;
			feature11[0].MinutiaArr[num12].y /= Det;
			
			for (int j = 0; j < 5; j++)
			{
				memcpy(basedesc1[j] + num11 * descriptorSize, 
					adddesc1[j] + i * descriptorSize, descriptorSize * sizeof(unsigned char));
			}
			num11++;
		}
		feature11[0].MinutiaNum = num11;
	}

	memset(addflag, 0, MAXMINUTIANUM * sizeof(unsigned char));
	int addNum2 = num22 - matchnum2;
	if (num12 + addNum2 > MAXMINUTIANUM) addNum1 = MAXMINUTIANUM - num11;
	if (addNum2 > 0)
	{
		for (int i = 0; i < matchnum2; i++)
		{
			int idex = resultpair2[2 * i + 1];
			addflag[idex] = 1;
		}
		for (int i = 0; i < 5; i++)
		{
			unsigned char *newdesc2 = (unsigned char*)malloc((num12 + addNum2)*descriptorSize * sizeof(unsigned char));
			memset(newdesc2, 0, (num12 + addNum2)*descriptorSize * sizeof(unsigned char));
			memcpy(newdesc2, basedesc2[i], num12*descriptorSize * sizeof(unsigned char));
			free(basedesc2[i]); basedesc2[i] = NULL;
			basedesc2[i] = newdesc2;
		}

		for (int i = 0; i < num21; i++)
		{
			if (addflag[i]) continue;
			if (num12 >= MAXMINUTIANUM) continue;
			feature12[0].MinutiaArr[num12] = feature22[0].MinutiaArr[i];
			feature12[0].MinutiaArr[num12].x = A[0] * feature22[0].MinutiaArr[i].x + A[1] * feature22[0].MinutiaArr[i].y + A[2];
			feature12[0].MinutiaArr[num12].y = A[3] * feature22[0].MinutiaArr[i].x + A[4] * feature22[0].MinutiaArr[i].y + A[5];
			feature12[0].MinutiaArr[num12].x /= Det;
			feature12[0].MinutiaArr[num12].y /= Det;

			for (int j = 0; j < 5; j++)
			{
				memcpy(basedesc2[j] + num12 * descriptorSize,
					adddesc2[j] + i * descriptorSize, descriptorSize * sizeof(unsigned char));
			}
			num12++;
		}
		feature12[0].MinutiaNum = num12;
	}
	return 0;
}

