#include "minutiae.h"
#include "table_int.h"
#include "type_def.h"
#include "List.h"
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "public.h"

/***************************************************************************/
/*                       �ڶ�ֵ��ͼ���в���������                          */
/***************************************************************************/

/*************************************************************************/
/* 10, 2X3 pixel pair feature patterns used to define ridge endings      */
/* and bifurcations.                                                     */
/* 2nd pixel pair is permitted to repeat multiple times in match.        */
#define NFEATURES      10
#define BIFURCATION     0
#define RIDGE_ENDING    1
#define DISAPPEARING    0
#define APPEARING       1

#define NUM_DIRECTIONS          16

/* Map value for not well-defined directions */
#define INVALID_DIR             255

#define IGNORE                   2

#define MAX_MINUTIAE          1000

/* The maximum pixel translation distance in X or Y within which */
/* two potential minutia points are to be considered similar.    */
#define MAX_MINUTIA_DELTA       10

/* Definitions for controlling the scanning of minutiae. */
#define SCAN_HORIZONTAL          0
#define SCAN_VERTICAL            1
#define SCAN_CLOCKWISE           0
#define SCAN_COUNTER_CLOCKWISE   1

#ifndef FOUND
#define FOUND                 1
#endif
#ifndef NOT_FOUND
#define NOT_FOUND             0
#endif

#define HOOK_FOUND               1
#define LOOP_FOUND               1
#define IGNORE                   2
#define LIST_FULL                3
#define INCOMPLETE               3

#define NORTH                    0
#define SOUTH                    4
#define EAST                     2
#define WEST                     6

/*���ֵΪN,ĳ������A,�����䷽����N�����غ�,����ʱ����
   invalid block,��ɾ��������*/
#define TRANS_DIR_PIX_V2         4 

#define INV_BLOCK_MARGIN_V2      0

/* Given a sufficiently close, neighboring invalid block, if that invalid */
/* block has a total number of neighboring blocks with valid ridge flow   */
/* less than this threshold, then the minutia point is removed.           */
#define RM_VALID_NBR_MIN         7

/* Definitions for removing or adusting side minutiae. */
/* Half the number of pixels to be traced to form a complete contour. */
#define SIDE_HALF_CONTOUR        7

//#define     MAXMINUTIANUM			50	  // �����������
//typedef struct tagMinutiae {
//	int    x;				// ������
//	int    y;				// ������
//	int    Direction;		// ����
//	//double reliability;   //����
//	//int	Triangle[3];	// ������Ϊ�������Բ�뾶Ϊ��ֵ������������������ķ���
//	//int    Type;			// ����
//} MINUTIA, *MINUTIAPTR;
//
//// ָ������(ģ��)�ṹ
//typedef struct tagFeature {
//	int		    MinutiaNum;					// ��������
//	MINUTIA		MinutiaArr[MAXMINUTIANUM];	// ����������V
//} FEATURE, *FEATUREPTR;

typedef struct minutia_ {
	int x;
	int y;
	int ex; /*x_edge*/
	int ey; /*y_edge*/
	int direction;
	int type;
} MINUTIA_;

typedef struct minutiae_ {
	int alloc;
	int num;
	MINUTIA_ **list;
} MINUTIAE_;

typedef struct feature_pattern {
	int type;
	int appearing;
	int first[2];
	int second[2];
	int third[2];
} FEATURE_PATTERN;

/* Global array of feature pixel pairs. */
FEATURE_PATTERN feature_patterns[] =
{ 
	{ RIDGE_ENDING,  /* a. Ridge Ending (appearing) */
     APPEARING,
	{ 0,0 },
	{ 0,1 },
	{ 0,0 } },

	{ RIDGE_ENDING,  /* b. Ridge Ending (disappearing) */
	DISAPPEARING,
	{ 0,0 },
	{ 1,0 },
	{ 0,0 } },

	{ BIFURCATION,   /* c. Bifurcation (disappearing) */
	DISAPPEARING,
	{ 1,1 },
	{ 0,1 },
	{ 1,1 } },

	{ BIFURCATION,   /* d. Bifurcation (appearing) */
	APPEARING,
	{ 1,1 },
	{ 1,0 },
	{ 1,1 } },

	{ BIFURCATION,   /* e. Bifurcation (disappearing) */
	DISAPPEARING,
	{ 1,0 },
	{ 0,1 },
	{ 1,1 } },

	{ BIFURCATION,   /* f. Bifurcation (disappearing) */
	DISAPPEARING,
	{ 1,1 },
	{ 0,1 },
	{ 1,0 } },

	{ BIFURCATION,   /* g. Bifurcation (appearing) */
	APPEARING,
	{ 1,1 },
	{ 1,0 },
	{ 0,1 } },

	{ BIFURCATION,   /* h. Bifurcation (appearing) */
	APPEARING,
	{ 0,1 },
	{ 1,0 },
	{ 1,1 } },

	{ BIFURCATION,   /* i. Bifurcation (disappearing) */
	DISAPPEARING,
	{ 1,0 },
	{ 0,1 },
	{ 1,0 } },

	{ BIFURCATION,   /* j. Bifurcation (appearing) */
	APPEARING,
	{ 0,1 },
	{ 1,0 },
	{ 0,1 } } 
};

/* Variables for conducting 8-connected neighbor analyses. */
/* Pixel neighbor offsets:  0  1  2  3  4  5  6  7  */     
                                                 /* 7 0 1 */
int nbr8_dx[] = { 0, 1, 1, 1, 0,-1,-1,-1 };      /* 6 C 2 */
int nbr8_dy[] = { -1,-1, 0, 1, 1, 1, 0,-1 };     /* 5 4 3 */

/* The chain code lookup matrix for 8-connected neighbors. */
/* Should put this in globals.                             */
int chaincodes_nbr8[] = 
						{ 3, 2, 1,
						  4,-1, 0,
						  5, 6, 7 };


/*******************************���ܺ�������************************************/

static int alloc_minutiae(MINUTIAE_ **ominutiae, const int max_minutiae);

static int realloc_minutiae(MINUTIAE_ *minutiae, const int incr_minutiae);

static void free_minutiae(MINUTIAE_ *minutiae);

static void free_minutia(MINUTIA_ *minutia);

static int remove_minutia(const int index, MINUTIAE_ *minutiae);

static void gray2bin(const int thresh, const int less_pix, const int greater_pix,
	unsigned char *bdata, const int iw, const int ih);

static int detect_minutiae_bin(MINUTIAE_ *minutiae,unsigned char *bdata, unsigned char *direction_map, const int iw, const int ih);

static int scan4minutiae_horizontally_bin(MINUTIAE_ *minutiae, unsigned char *bdata, const int iw, const int ih,
	unsigned char *pdirection_map);

static int match_1st_pair(unsigned char p1, unsigned char p2, int *possible, int *nposs);

static int match_2nd_pair(unsigned char p1, unsigned char p2, int *possible, int *nposs);

static int match_3rd_pair(unsigned char p1, unsigned char p2, int *possible, int *nposs);

static void skip_repeated_horizontal_pair(int *cx, const int ex, unsigned char **p1ptr,
	unsigned char **p2ptr, const int iw, const int ih);

static int process_horizontal_scan_minutia_bin(MINUTIAE_ *minutiae, const int cx, const int cy, const int x2,
	const int feature_id, unsigned char *bdata, const int iw, const int ih, unsigned char *pdirection_map);

static int get_low_curvature_direction(const int scan_dir, const int appearing,const int imapval, const int ndirs);

static int create_minutia(MINUTIA_ **ominutia, const int x_loc, const int y_loc,const int x_edge, 
	const int y_edge, const int idir,const int type, const int appearing, const int feature_id);

static int update_minutiae(MINUTIAE_ *minutiae, MINUTIA_ *minutia, const int scan_dir, const int dmapval,
	unsigned char *bdata, const int iw, const int ih);

static int search_contour(const int x_search, const int y_search, const int search_len, const int x_loc,
	const int y_loc, const int x_edge, const int y_edge, const int scan_clock, unsigned char *bdata,
	const int iw, const int ih);

static int next_contour_pixel(int *next_x_loc, int *next_y_loc, int *next_x_edge, int *next_y_edge,
	const int cur_x_loc, const int cur_y_loc, const int cur_x_edge, const int cur_y_edge,
	const int scan_clock, unsigned char *bdata, const int iw, const int ih);

static int start_scan_nbr(const int x_prev, const int y_prev, const int x_next, const int y_next);

static int next_scan_nbr(const int nbr_i, const int scan_clock);

static int choose_scan_direction(const int imapval, const int ndirs);

static int scan4minutiae_vertically_bin(MINUTIAE_ *minutiae, unsigned char *bdata, const int iw, const int ih,
	unsigned char *pdirection_map);

static void skip_repeated_vertical_pair(int *cy, const int ey,unsigned char **p1ptr, unsigned char **p2ptr,
	const int iw, const int ih);

static int process_vertical_scan_minutia_bin(MINUTIAE_ *minutiae,const int cx, const int cy,const int y2, 
	const int feature_id,unsigned char *bdata, const int iw, const int ih,unsigned char *pdirection_map);

static int remove_false_minutia_bin(MINUTIAE_ *minutiae, unsigned char *bdata, const int iw, const int ih,
	unsigned char *direction_map);

static int remove_false_minutia_bin(MINUTIAE_ *minutiae, unsigned char *bdata, const int iw, const int ih,
	unsigned char *direction_map);

static int sort_minutiae_y_x(MINUTIAE_ *minutiae, const int iw, const int ih);

static int sort_indices_int_inc(int **optr, int *ranks, const int num);

static void bubble_sort_int_inc_2(int *ranks, int *items, const int len);

static int remove_pointing_invblock_bin(MINUTIAE_ *minutiae, unsigned char *direction_map, 
	const int mw, const int mh);

//static int remove_near_invblock_bin(MINUTIAE_ *minutiae, int *direction_map, const int mw, const int mh);

//static int num_valid_8nbrs(int *imap, const int mx, const int my, const int mw, const int mh);

static int remove_or_adjust_side_minutiae_bin(MINUTIAE_ *minutiae, unsigned char *bdata, const int iw, const int ih,
	unsigned char *direction_map);

static int get_centered_contour(int **ocontour_x, int **ocontour_y, int **ocontour_ex, int **ocontour_ey,
	int *oncontour, const int half_contour, const int x_loc, const int y_loc, const int x_edge,
	const int y_edge, unsigned char *bdata, const int iw, const int ih);

static int trace_contour(int **ocontour_x, int **ocontour_y, int **ocontour_ex, int **ocontour_ey, int *oncontour,
	const int max_len, const int x_loop, const int y_loop, const int x_loc, const int y_loc,
	const int x_edge, const int y_edge, const int scan_clock, unsigned char *bdata, const int iw, const int ih);

static int minmaxs(int **ominmax_val, int **ominmax_type, int **ominmax_i, int *ominmax_alloc, int *ominmax_num,
	const int *items, const int num);

static int allocate_contour(int **ocontour_x, int **ocontour_y, int **ocontour_ex, int **ocontour_ey,
	const int ncontour);

static void free_contour(int *contour_x, int *contour_y, int *contour_ex, int *contour_ey);


/******************************************�ӿں���ʵ��*****************************************************/
int Hybrid_FindMinutiae_bin(unsigned char *bin_img, unsigned char *direction_map, int width, int height, void *feature, int if_recaldir)
{
	MINUTIAE_ *minutiae = NULL;
	FEATURE *lpFeature = (FEATURE*)(feature);
	int ret = 0;

	if (if_recaldir)/*�Ƿ���������*/
	{
		/* ���� 0~180�� ת��Ϊ 0 ~15������, 90���Ӧ0*/
		int half_dir_num = NUM_DIRECTIONS / 2;
		unsigned char max_dir_index = NUM_DIRECTIONS - 1;
		for (int y = 0; y < height; y++)
		{
			for (int x = 0; x < width; x++)
			{
				int index = y * width + x;
				unsigned char currdata = direction_map[index];
				if (currdata == 180) currdata = 0;

				if (currdata >= 0 && currdata <= 90)
				{
					direction_map[index] = (half_dir_num - (currdata* NUM_DIRECTIONS - 90) / 180)& max_dir_index;
				}
				else if (currdata > 90 && currdata < 180)
				{
					direction_map[index] = (NUM_DIRECTIONS + half_dir_num - (currdata * NUM_DIRECTIONS - 90) / 180)& max_dir_index;
				}
			}
		}
	}

	/* Convert 8-bit grayscale binary image [0,255] to */
	/* 8-bit binary image [0,1]. */
	gray2bin(1, 1, 0, bin_img, width, height);
	
	/* Allocate initial list of minutia pointers. */
	if ((ret = alloc_minutiae(&minutiae, MAX_MINUTIAE))) 
	{
		return(ret);
	}

	/* Detect the minutiae in the binarized image. */
	if ((ret = detect_minutiae_bin(minutiae,  bin_img, direction_map, width, height)))
	{
		return(ret);
	}

	if ((ret = remove_false_minutia_bin(minutiae, bin_img, width, height,direction_map))) 
	{
		/* Free memory allocated to this point. */
		free_minutiae(minutiae);
		return(ret);
	}

	/* Convert 8-bit binary image [0,1] to 8-bit */
	/* grayscale binary image [0,255].           */
	gray2bin(1, 255, 0, bin_img, width, height);

	lpFeature->MinutiaNum = min(MAXMINUTIANUM,minutiae->num);
	for (int i = 0; i < minutiae->num && i < MAXMINUTIANUM; i++)
	{
		lpFeature->MinutiaArr[i].x = minutiae->list[i]->x;
		lpFeature->MinutiaArr[i].y = minutiae->list[i]->y;
		lpFeature->MinutiaArr[i].Direction = (360 + 90 - minutiae->list[i]->direction * 180 / NUM_DIRECTIONS) % 360;
	}

	/* Deallocate working memory. */
	if(minutiae != NULL) free_minutiae(minutiae);

	return 0;
}


/******************************************���ܺ���ʵ��*****************************************************/
int detect_minutiae_bin(MINUTIAE_ *minutiae, unsigned char *bdata, unsigned char *direction_map,const int iw, const int ih)
{
	int ret;

	if ((ret = scan4minutiae_horizontally_bin(minutiae, bdata, iw, ih, direction_map)))
	{
		return(ret);
	}
	if ((ret = scan4minutiae_vertically_bin(minutiae, bdata, iw, ih,direction_map))) 
	{
		return(ret);
	}

	return(0);
}

int scan4minutiae_horizontally_bin(MINUTIAE_ *minutiae,unsigned char *bdata, const int iw, const int ih,
	unsigned char *pdirection_map)
{
	int sx, sy, ex, ey, cx, cy, x2;
	unsigned char *p1ptr, *p2ptr;
	int possible[NFEATURES], nposs;
	int ret;

	/* Set scan region to entire image. */
	sx = 0;
	ex = iw;
	sy = 0;
	ey = ih;

	/* Start at first row in region. */
	cy = sy;
	/* While second scan row not outside the bottom of the scan region... */
	while (cy + 1 < ey)
	{
		/* Start at beginning of new scan row in region. */
		cx = sx;
		/* While not at end of region's current scan row. */
		while (cx < ex) 
		{
			/* Get pixel pair from current x position in current and next */
			/* scan rows. */
			p1ptr = bdata + (cy*iw) + cx;
			p2ptr = bdata + ((cy + 1)*iw) + cx;
			/* If scan pixel pair matches first pixel pair of */
			/* 1 or more features... */
			if (match_1st_pair(*p1ptr, *p2ptr, possible, &nposs))
			{
				/* Bump forward to next scan pixel pair. */
				cx++;
				p1ptr++;
				p2ptr++;
				/* If not at end of region's current scan row... */
				if (cx < ex)
				{
					/* If scan pixel pair matches second pixel pair of */
					/* 1 or more features... */
					if (match_2nd_pair(*p1ptr, *p2ptr, possible, &nposs)) 
					{
						/* Store current x location. */
						x2 = cx;
						/* Skip repeated pixel pairs. */
						skip_repeated_horizontal_pair(&cx, ex, &p1ptr, &p2ptr,iw, ih);

						/* If not at end of region's current scan row... */
						if (cx < ex)
						{
							/* If scan pixel pair matches third pixel pair of */
							/* a single feature... */
							if (match_3rd_pair(*p1ptr, *p2ptr, possible, &nposs)) 
							{
								/* Process detected minutia point. */
								if ((ret = process_horizontal_scan_minutia_bin(minutiae,
									cx, cy, x2, possible[0], bdata, iw, ih, pdirection_map)))
								{
									/* Return code may be:                       */
									/* 1.  ret< 0 (implying system error)        */
									/* 2. ret==IGNORE (ignore current feature)   */
									if (ret < 0) return(ret);
									/* Otherwise, IGNORE and continue. */
								}
							}
							/* Set up to resume scan. */
							/* Test to see if 3rd pair can slide into 2nd pair. */
							/* The values of the 2nd pair MUST be different.    */
							/* If 3rd pair values are different ... */
							if (*p1ptr != *p2ptr) 
							{
								/* Set next first pair to last of repeated */
								/* 2nd pairs, ie. back up one pair.        */
								cx--;
							}
							/* Otherwise, 3rd pair can't be a 2nd pair, so  */
							/* keep pointing to 3rd pair so that it is used */
							/* in the next first pair test.                 */
						}/* Else, at end of current scan row. */
					}
					/* Otherwise, 2nd pair failed, so keep pointing to it */
					/* so that it is used in the next first pair test.    */

				}/* Else, at end of current scan row. */
			}
			/* Otherwise, 1st pair failed... */
			else
			{
				/* Bump forward to next pixel pair. */
				cx++;
			}
		}/* While not at end of current scan row. */
		 /* Bump forward to next scan row. */
		cy++;
	}/* While not out of scan rows. */

	 /* Return normally. */
	return(0);
}

int match_1st_pair(unsigned char p1, unsigned char p2, int *possible, int *nposs)
{
	int i;

	/* Set possibilities to 0 */
	*nposs = 0;

	/* Foreach set of feature pairs ... */
	for (i = 0; i < NFEATURES; i++) {
		/* If current scan pair matches first pair for feature ... */
		if ((p1 == feature_patterns[i].first[0]) &&
			(p2 == feature_patterns[i].first[1])) {
			/* Store feature as a possible match. */
			possible[*nposs] = i;
			/* Bump number of stored possibilities. */
			(*nposs)++;
		}
	}

	/* Return number of stored possibilities. */
	return(*nposs);
}

int match_2nd_pair(unsigned char p1, unsigned char p2,int *possible, int *nposs)
{
	int i;
	int tnposs;

	/* Store input possibilities. */
	tnposs = *nposs;
	/* Reset output possibilities to 0. */
	*nposs = 0;

	/* If current scan pair values are the same ... */
	if (p1 == p2)
		/* Simply return because pair can't be a second feature pair. */
		return(*nposs);

	/* Foreach possible match based on first pair ... */
	for (i = 0; i < tnposs; i++) {
		/* If current scan pair matches second pair for feature ... */
		if ((p1 == feature_patterns[possible[i]].second[0]) &&
			(p2 == feature_patterns[possible[i]].second[1])) {
			/* Store feature as a possible match. */
			possible[*nposs] = possible[i];
			/* Bump number of stored possibilities. */
			(*nposs)++;
		}
	}

	/* Return number of stored possibilities. */
	return(*nposs);
}

int match_3rd_pair(unsigned char p1, unsigned char p2,int *possible, int *nposs)
{
	int i;
	int tnposs;

	/* Store input possibilities. */
	tnposs = *nposs;
	/* Reset output possibilities to 0. */
	*nposs = 0;

	/* Foreach possible match based on first and second pairs ... */
	for (i = 0; i < tnposs; i++) {
		/* If current scan pair matches third pair for feature ... */
		if ((p1 == feature_patterns[possible[i]].third[0]) &&
			(p2 == feature_patterns[possible[i]].third[1])) {
			/* Store feature as a possible match. */
			possible[*nposs] = possible[i];
			/* Bump number of stored possibilities. */
			(*nposs)++;
		}
	}

	/* Return number of stored possibilities. */
	return(*nposs);
}

void skip_repeated_horizontal_pair(int *cx, const int ex, unsigned char **p1ptr, 
	unsigned char **p2ptr,const int iw, const int ih)
{
	int old1, old2;

	/* Store starting pixel pair. */
	old1 = **p1ptr;
	old2 = **p2ptr;

	/* Bump horizontally to next pixel pair. */
	(*cx)++;
	(*p1ptr)++;
	(*p2ptr)++;

	/* While not at right of scan region... */
	while (*cx < ex) {
		/* If one or the other pixels in the new pair are different */
		/* from the starting pixel pair...                          */
		if ((**p1ptr != old1) || (**p2ptr != old2))
			/* Done skipping repreated pixel pairs. */
			return;
		/* Otherwise, bump horizontally to next pixel pair. */
		(*cx)++;
		(*p1ptr)++;
		(*p2ptr)++;
	}
}

int process_horizontal_scan_minutia_bin(MINUTIAE_ *minutiae, const int cx, const int cy, const int x2,
	const int feature_id, unsigned char *bdata, const int iw, const int ih, unsigned char *pdirection_map)
{
	MINUTIA_ *minutia;
	int x_loc, y_loc;
	int x_edge, y_edge;
	int idir, ret;
	int dmapval;
	//double reliability;

	/* Set x location of minutia point to be half way between */
	/* first position of second feature pair and position of  */
	/* third feature pair.                                    */
	x_loc = (cx + x2) >> 1;

	/* Set same x location to neighboring edge pixel. */
	x_edge = x_loc;

	/* Feature location should always point to either ending  */
	/* of ridge or (for bifurcations) ending of valley.       */
	/* So, if detected feature is APPEARING...                */
	if (feature_patterns[feature_id].appearing) {
		/* Set y location to second scan row. */
		y_loc = cy + 1;
		/* Set y location of neighboring edge pixel to the first scan row. */
		y_edge = cy;
	}
	/* Otherwise, feature is DISAPPEARING... */
	else {
		/* Set y location to first scan row. */
		y_loc = cy;
		/* Set y location of neighboring edge pixel to the second scan row. */
		y_edge = cy + 1;
	}

	dmapval = *(pdirection_map + (y_loc*iw) + x_loc);

	/* If the minutia point is in a block with INVALID direction ... */
	if (dmapval == INVALID_DIR)
		/* Then, IGNORE the point. */
		return(IGNORE);

	/* Get minutia direction based on current block's direction. */
	idir = get_low_curvature_direction(SCAN_HORIZONTAL,feature_patterns[feature_id].appearing, 
		dmapval,NUM_DIRECTIONS);
	

	/* Create a minutia object based on derived attributes. */
	if ((ret = create_minutia(&minutia, x_loc, y_loc, x_edge, y_edge, idir,
		feature_patterns[feature_id].type,
		feature_patterns[feature_id].appearing, feature_id)))
		/* Return system error. */
		return(ret);

	/* Update the minutiae list with potential new minutia. */
	ret = update_minutiae(minutiae, minutia, SCAN_HORIZONTAL,
		dmapval, bdata, iw, ih);

	/* If minuitia IGNORED and not added to the minutia list ... */
	if (ret == IGNORE)
		/* Deallocate the minutia. */
		free_minutia(minutia);

	/* Otherwise, return normally. */
	return(0);
}

int get_low_curvature_direction(const int scan_dir, const int appearing,
	const int imapval, const int ndirs)
{
	int idir;

	/* Start direction out with IMAP value. */
	idir = imapval;

	/* NOTE!                                                           */
	/* The logic in this routine should hold whether for ridge endings */
	/* or for bifurcations.  The examples in the comments show ridge   */
	/* ending conditions only.                                         */

	/* CASE I : Ridge flow in Quadrant I; directions [0..8]             */
	if (imapval <= (ndirs >> 1)) {
		/*    I.A: HORIZONTAL scan                                       */
		if (scan_dir == SCAN_HORIZONTAL) {
			/*       I.A.1: Appearing Minutia                             */
			if (appearing) {
				/*        Ex.    0 0 0                                     */
				/*               0 1 0                                     */
				/*               ? ?                                       */
				/*              Ridge flow is up and to the right, whereas */
				/*              actual ridge is running down and to the    */
				/*              left.                                      */
				/*              Thus: HORIZONTAL : appearing   : should be */
				/*                    OPPOSITE the ridge flow direction.   */
				idir += ndirs;
			}
			/* Otherwise:                                                 */
			/*       I.A.2: Disappearing Minutia                       */
			/*           Ex.   ? ?                                     */
			/*               0 1 0                                     */
			/*               0 0 0                                     */
			/*              Ridge flow is up and to the right, which   */
			/*              should be SAME direction from which ridge  */
			/*              is projecting.                             */
			/*              Thus: HORIZONTAL : disappearing : should   */
			/*                    be the same as ridge flow direction. */
		} /* End if HORIZONTAL scan */
		  /* Otherwise:                                                    */
		  /*    I.B: VERTICAL scan                                         */
		else {
			/*       I.B.1: Disappearing Minutia                          */
			if (!appearing) {
				/*        Ex.    0 0                                       */
				/*             ? 1 0                                       */
				/*             ? 0 0                                       */
				/*              Ridge flow is up and to the right, whereas */
				/*              actual ridge is projecting down and to the */
				/*              left.                                      */
				/*              Thus: VERTICAL : disappearing : should be  */
				/*                    OPPOSITE the ridge flow direction.   */
				idir += ndirs;
			}
			/* Otherwise:                                                 */
			/*       I.B.2: Appearing Minutia                          */
			/*           Ex. 0 0 ?                                     */
			/*               0 1 ?                                     */
			/*               0 0                                       */
			/*              Ridge flow is up and to the right, which   */
			/*              should be SAME direction the ridge is      */
			/*              running.                                   */
			/*              Thus: VERTICAL : appearing   : should be   */
			/*                    be the same as ridge flow direction. */
		} /* End else VERTICAL scan */
	} /* End if Quadrant I */

	  /* Otherwise:                                                       */
	  /* CASE II : Ridge flow in Quadrant II; directions [9..15]          */
	else {
		/*   II.A: HORIZONTAL scan                                       */
		if (scan_dir == SCAN_HORIZONTAL) {
			/*      II.A.1: Disappearing Minutia                          */
			if (!appearing) {
				/*           Ex. ? ?                                       */
				/*               0 1 0                                     */
				/*               0 0 0                                     */
				/*              Ridge flow is down and to the right,       */
				/*              whereas actual ridge is running up and to  */
				/*              the left.                                  */
				/*              Thus: HORIZONTAL : disappearing : should   */
				/*                    be OPPOSITE the ridge flow direction.*/
				idir += ndirs;
			}
			/* Otherwise:                                                 */
			/*      II.A.2: Appearing Minutia                             */
			/*           Ex. 0 0 0                                     */
			/*               0 1 0                                     */
			/*                 ? ?                                     */
			/*              Ridge flow is down and to the right, which */
			/*              should be same direction from which ridge  */
			/*              is projecting.                             */
			/*              Thus: HORIZONTAL : appearing : should be   */
			/*                    the SAME as ridge flow direction.    */
		} /* End if HORIZONTAL scan */
		  /* Otherwise:                                                    */
		  /*   II.B: VERTICAL scan                                         */
		else {
			/*      II.B.1: Disappearing Minutia                          */
			if (!appearing) {
				/*           Ex. ? 0 0                                     */
				/*               ? 1 0                                     */
				/*                 0 0                                     */
				/*              Ridge flow is down and to the right,       */
				/*              whereas actual ridge is running up and to  */
				/*              the left.                                  */
				/*              Thus: VERTICAL : disappearing : should be  */
				/*                    OPPOSITE the ridge flow direction.   */
				idir += ndirs;
			}
			/* Otherwise:                                                 */
			/*      II.B.2: Appearing Minutia                          */
			/*           Ex. 0 0                                       */
			/*               0 1 ?                                     */
			/*               0 0 ?                                     */
			/*              Ridge flow is down and to the right, which */
			/*              should be same direction the ridge is      */
			/*              projecting.                                */
			/*              Thus: VERTICAL : appearing   : should be   */
			/*                    be the SAME as ridge flow direction. */
		} /* End else VERTICAL scan */
	} /* End else Quadrant II */

	  /* Return resulting direction on range [0..31]. */
	return(idir);
}

int create_minutia(MINUTIA_ **ominutia, const int x_loc, const int y_loc,const int x_edge, const int y_edge, 
	const int idir,const int type, const int appearing, const int feature_id)
{
	MINUTIA_ *minutia;

	/* Allocate a minutia structure. */
	minutia = (MINUTIA_ *)malloc(sizeof(MINUTIA_));
	/* If allocation error... */
	if (minutia == (MINUTIA_ *)NULL) 
	{
		return(-230);
	}

	/* Assign minutia structure attributes. */
	minutia->x = x_loc;
	minutia->y = y_loc;
	minutia->ex = x_edge;
	minutia->ey = y_edge;
	minutia->direction = idir;
	minutia->type = type;
	/* Set minutia object to output pointer. */
	*ominutia = minutia;
	/* Return normally. */
	return(0);
}

int update_minutiae(MINUTIAE_ *minutiae, MINUTIA_ *minutia,const int scan_dir, const int dmapval,
	unsigned char *bdata, const int iw, const int ih)
{
	int i, ret, dy, dx, delta_dir;
	int qtr_ndirs, full_ndirs;
	int map_scan_dir;

	/* Check to see if minutiae list is full ... if so, then extend */
	/* the length of the allocated list of minutia points.          */
	if (minutiae->num >= minutiae->alloc) 
	{
		if ((ret = realloc_minutiae(minutiae, MAX_MINUTIAE)))
			return(ret);
	}

	/* Otherwise, there is still room for more minutia. */

	/* Compute quarter of possible directions in a semi-circle */
	/* (ie. 45 degrees).                                       */
	qtr_ndirs = NUM_DIRECTIONS >> 2;

	/* Compute number of directions in full circle. */
	full_ndirs = NUM_DIRECTIONS << 1;

	/* Is the minutiae list empty? */
	if (minutiae->num > 0) 
	{
		/* Foreach minutia stored in the list (in reverse order) ... */
		for (i = minutiae->num - 1; i >= 0; i--) 
		{
			/* If x distance between new minutia and current list minutia */
			/* are sufficiently close...                                 */
			dx = abs(minutiae->list[i]->x - minutia->x);
			if (dx < MAX_MINUTIA_DELTA)
			{
				/* If y distance between new minutia and current list minutia */
				/* are sufficiently close...                                 */
				dy = abs(minutiae->list[i]->y - minutia->y);
				if (dy <MAX_MINUTIA_DELTA) 
				{
					/* If new minutia and current list minutia are same type... */
					if (minutiae->list[i]->type == minutia->type)
					{
						/* Test to see if minutiae have similar directions. */
						/* Take minimum of computed inner and outer        */
						/* direction differences.                          */
						delta_dir = abs(minutiae->list[i]->direction - minutia->direction);
						delta_dir = min(delta_dir, full_ndirs - delta_dir);
						/* If directional difference is <= 45 degrees... */
						if (delta_dir <= qtr_ndirs)
						{
							/* If new minutia and current list minutia share */
							/* the same point... */
							if ((dx == 0) && (dy == 0)) {
								/* Then the minutiae match, so don't add the new one */
								/* to the list.                                     */
								return(IGNORE);
							}
							/* Othewise, check if they share the same contour. */
							/* Start by searching "max_minutia_delta" steps    */
							/* clockwise.                                      */
							/* If new minutia point found on contour...        */
							if (search_contour(minutia->x, minutia->y,
								MAX_MINUTIA_DELTA,
								minutiae->list[i]->x, minutiae->list[i]->y,
								minutiae->list[i]->ex, minutiae->list[i]->ey,
								SCAN_CLOCKWISE, bdata, iw, ih) ||
								search_contour(minutia->x, minutia->y,
									MAX_MINUTIA_DELTA,
									minutiae->list[i]->x, minutiae->list[i]->y,
									minutiae->list[i]->ex, minutiae->list[i]->ey,
									SCAN_COUNTER_CLOCKWISE, bdata, iw, ih)) 
							{
								/* If new minutia has VALID block direction ... */
								if (dmapval != INVALID_DIR)
								{
									/* Derive feature scan direction compatible */
									/* with VALID direction.                    */
									map_scan_dir = choose_scan_direction(dmapval,NUM_DIRECTIONS);
									/* If map scan direction compatible with scan   */
									/* direction in which new minutia was found ... */
									if (map_scan_dir == scan_dir)
									{
										/* Then choose the new minutia over the one */
										/* currently in the list.                   */
										if ((ret = remove_minutia(i, minutiae))) {
											return(ret);
										}
										/* Continue on ... */
									}
									else
										/* Othersize, scan directions not compatible...*/
										/* so choose to keep the current minutia in    */
										/* the list and ignore the new one.            */
										return(IGNORE);
								}
								else 
								{
									/* Otherwise, no reason to believe new minutia    */
									/* is any better than the current one in the list,*/
									/* so consider the new minutia to be the same as  */
									/* the current list minutia, and don't add the new*/
									/*  one to the list.                              */
									return(IGNORE);
								}
							}
							/* Otherwise, new minutia and current list minutia do */
							/* not share the same contour, so although they are   */
							/* similar in type and location, treat them as 2      */
							/* different minutia.                                 */
						}/* Otherwise, directions are too different. */
					}/* Otherwise, minutiae are different type. */
				}/* Otherwise, minutiae too far apart in Y. */
			}/* Otherwise, minutiae too far apart in X. */
		} /* End FOR minutia in list. */
	}/* Otherwise, minutiae list is empty. */

	 /* Otherwise, assume new minutia is not in the list, or those that */
	 /* were close neighbors were selectively removed, so add it.       */
	minutiae->list[minutiae->num] = minutia;
	(minutiae->num)++;

	/* New minutia was successfully added to the list. */
	/* Return normally. */

	return(0);
}

int search_contour(const int x_search, const int y_search,const int search_len,const int x_loc,
	const int y_loc,const int x_edge, const int y_edge,const int scan_clock,unsigned char *bdata,
	const int iw, const int ih)
{
	int cur_x_loc, cur_y_loc;
	int cur_x_edge, cur_y_edge;
	int next_x_loc, next_y_loc;
	int next_x_edge, next_y_edge;
	int i;

	/* Set up for finding first contour pixel. */
	cur_x_loc = x_loc;
	cur_y_loc = y_loc;
	cur_x_edge = x_edge;
	cur_y_edge = y_edge;

	/* Foreach point to be collected on the feature's contour... */
	for (i = 0; i < search_len; i++) {
		/* Find the next contour pixel. */
		if (next_contour_pixel(&next_x_loc, &next_y_loc,
			&next_x_edge, &next_y_edge,
			cur_x_loc, cur_y_loc,
			cur_x_edge, cur_y_edge,
			scan_clock, bdata, iw, ih)) {

			/* If we find the point we are looking for on the contour... */
			if ((next_x_loc == x_search) && (next_y_loc == y_search)) {
				/* Then return FOUND. */
				return(FOUND);
			}

			/* Otherwise, set up for finding next contour pixel. */
			cur_x_loc = next_x_loc;
			cur_y_loc = next_y_loc;
			cur_x_edge = next_x_edge;
			cur_y_edge = next_y_edge;
		}
		/* Otherwise, no new contour point found ... */
		else {
			/* So, stop searching, and return NOT_FOUND. */
			return(NOT_FOUND);
		}
	}

	/* If we get here, we successfully searched the maximum points */
	/* without finding our desired point, so return NOT_FOUND.     */
	return(NOT_FOUND);
}

int next_contour_pixel(int *next_x_loc, int *next_y_loc,int *next_x_edge, int *next_y_edge,
	const int cur_x_loc, const int cur_y_loc,const int cur_x_edge, const int cur_y_edge,
	const int scan_clock,unsigned char *bdata, const int iw, const int ih)
{
	int feature_pix, edge_pix;
	int prev_nbr_pix, prev_nbr_x, prev_nbr_y;
	int cur_nbr_pix, cur_nbr_x, cur_nbr_y;
	int ni, nx, ny, npix;
	int nbr_i, i;

	/* Get the feature's pixel value. */
	feature_pix = *(bdata + (cur_y_loc * iw) + cur_x_loc);
	/* Get the feature's edge pixel value. */
	edge_pix = *(bdata + (cur_y_edge * iw) + cur_x_edge);

	/* Get the nieghbor position of the feature's edge pixel in relationship */
	/* to the feature's actual position.                                     */
	/* REMEBER: The feature's position is always interior and on a ridge     */
	/* ending (black pixel) or (for bifurcations) on a valley ending (white  */
	/* pixel).  The feature's edge pixel is an adjacent pixel to the feature */
	/* pixel that is exterior to the ridge or valley ending and opposite in  */
	/* pixel value.                                                          */
	nbr_i = start_scan_nbr(cur_x_loc, cur_y_loc, cur_x_edge, cur_y_edge);

	/* Set current neighbor scan pixel to the feature's edge pixel. */
	cur_nbr_x = cur_x_edge;
	cur_nbr_y = cur_y_edge;
	cur_nbr_pix = edge_pix;

	/* Foreach pixel neighboring the feature pixel ... */
	for (i = 0; i < 8; i++) {

		/* Set current neighbor scan pixel to previous scan pixel. */
		prev_nbr_x = cur_nbr_x;
		prev_nbr_y = cur_nbr_y;
		prev_nbr_pix = cur_nbr_pix;

		/* Bump pixel neighbor index clockwise or counter-clockwise. */
		nbr_i = next_scan_nbr(nbr_i, scan_clock);

		/* Set current scan pixel to the new neighbor.                   */
		/* REMEMBER: the neighbors are being scanned around the original */
		/* feature point.                                                */
		cur_nbr_x = cur_x_loc + nbr8_dx[nbr_i];
		cur_nbr_y = cur_y_loc + nbr8_dy[nbr_i];

		/* If new neighbor is not within image boundaries... */
		if ((cur_nbr_x < 0) || (cur_nbr_x >= iw) ||
			(cur_nbr_y < 0) || (cur_nbr_y >= ih))
			/* Return (FALSE==>Failure) if neighbor out of bounds. */
			return(0);

		/* Get the new neighbor's pixel value. */
		cur_nbr_pix = *(bdata + (cur_nbr_y * iw) + cur_nbr_x);

		/* If the new neighbor's pixel value is the same as the feature's   */
		/* pixel value AND the previous neighbor's pixel value is the same  */
		/* as the features's edge, then we have "likely" found our next     */
		/* contour pixel.                                                   */
		if ((cur_nbr_pix == feature_pix) && (prev_nbr_pix == edge_pix)) {

			/* Check to see if current neighbor is on the corner of the */
			/* neighborhood, and if so, test to see if it is "exposed". */
			/* The neighborhood corners have odd neighbor indicies.     */
			if (nbr_i % 2) {
				/* To do this, look ahead one more neighbor pixel. */
				ni = next_scan_nbr(nbr_i, scan_clock);
				nx = cur_x_loc + nbr8_dx[ni];
				ny = cur_y_loc + nbr8_dy[ni];
				/* If new neighbor is not within image boundaries... */
				if ((nx < 0) || (nx >= iw) ||
					(ny < 0) || (ny >= ih))
					/* Return (FALSE==>Failure) if neighbor out of bounds. */
					return(0);
				npix = *(bdata + (ny * iw) + nx);

				/* If the next neighbor's value is also the same as the */
				/* feature's pixel, then corner is NOT exposed...       */
				if (npix == feature_pix) {
					/* Assign the current neighbor pair to the output pointers. */
					*next_x_loc = cur_nbr_x;
					*next_y_loc = cur_nbr_y;
					*next_x_edge = prev_nbr_x;
					*next_y_edge = prev_nbr_y;
					/* Return TRUE==>Success. */
					return(1);
				}
				/* Otherwise, corner pixel is "exposed" so skip it. */
				else {
					/* Skip current corner neighbor by resetting it to the      */
					/* next neighbor, which upon the iteration will immediately */
					/* become the previous neighbor.                            */
					cur_nbr_x = nx;
					cur_nbr_y = ny;
					cur_nbr_pix = npix;
					/* Advance neighbor index. */
					nbr_i = ni;
					/* Advance neighbor count. */
					i++;
				}
			}
			/* Otherwise, current neighbor is not a corner ... */
			else {
				/* Assign the current neighbor pair to the output pointers. */
				*next_x_loc = cur_nbr_x;
				*next_y_loc = cur_nbr_y;
				*next_x_edge = prev_nbr_x;
				*next_y_edge = prev_nbr_y;
				/* Return TRUE==>Success. */
				return(1);
			}
		}
	}

	/* If we get here, then we did not find the next contour pixel */
	/* within the 8 neighbors of the current feature pixel so      */
	/* return (FALSE==>Failure).                                   */
	/* NOTE: This must mean we found a single isolated pixel.      */
	/*       Perhaps this should be filled?                        */
	return(0);
}

int start_scan_nbr(const int x_prev, const int y_prev,const int x_next, const int y_next)
{
	if ((x_prev == x_next) && (y_next > y_prev))
		return(SOUTH);
	else if ((x_prev == x_next) && (y_next < y_prev))
		return(NORTH);
	else if ((x_next > x_prev) && (y_prev == y_next))
		return(EAST);
	else if ((x_next < x_prev) && (y_prev == y_next))
		return(WEST);

	/* Added by MDG on 03-16-05 */
	/* Should never reach here.  Added to remove compiler warning. */
	return(-1); /* -1 */
}

int next_scan_nbr(const int nbr_i, const int scan_clock)
{
	int new_i;

	/* If scanning neighbors clockwise ... */
	if (scan_clock == SCAN_CLOCKWISE)
		/* Advance one neighbor clockwise. */
		new_i = (nbr_i + 1) % 8;
	/* Otherwise, scanning neighbors counter-clockwise ... */
	else
		/* Advance one neighbor counter-clockwise.         */
		/* There are 8 pixels in the neighborhood, so to   */
		/* decrement with wrapping from 0 around to 7, add */
		/* the nieghbor index by 7 and mod with 8.         */
		new_i = (nbr_i + 7) % 8;

	/* Return the new neighbor index. */
	return(new_i);
}

int choose_scan_direction(const int imapval, const int ndirs)
{
	int qtr_ndirs;

	/* Compute quarter of directions in semi-circle. */
	qtr_ndirs = ndirs >> 2;

	/* If ridge flow in block is relatively vertical, then we want */
	/* to scan for minutia features in the opposite direction      */
	/* (ie. HORIZONTALLY).                                         */
	if ((imapval <= qtr_ndirs) || (imapval > (qtr_ndirs * 3)))
		return(SCAN_HORIZONTAL);
	/* Otherwise, ridge flow is realtively horizontal, and we want */
	/* to scan for minutia features in the opposite direction      */
	/* (ie. VERTICALLY).                                           */
	else
		return(SCAN_VERTICAL);

}

int scan4minutiae_vertically_bin(MINUTIAE_ *minutiae,unsigned char *bdata, const int iw, const int ih,
	unsigned char *pdirection_map)
{
	int sx, sy, ex, ey, cx, cy, y2;
	unsigned char *p1ptr, *p2ptr;
	int possible[NFEATURES], nposs;
	int ret;

	/* Set scan region to entire image. */
	sx = 0;
	ex = iw;
	sy = 0;
	ey = ih;

	/* Start at first column in region. */
	cx = sx;
	/* While second scan column not outside the right of the region ... */
	while (cx + 1 < ex) 
	{
		/* Start at beginning of new scan column in region. */
		cy = sy;
		/* While not at end of region's current scan column. */
		while (cy < ey) 
		{
			/* Get pixel pair from current y position in current and next */
			/* scan columns. */
			p1ptr = bdata + (cy*iw) + cx;
			p2ptr = p1ptr + 1;
			/* If scan pixel pair matches first pixel pair of */
			/* 1 or more features... */
			if (match_1st_pair(*p1ptr, *p2ptr, possible, &nposs)) 
			{
				/* Bump forward to next scan pixel pair. */
				cy++;
				p1ptr += iw;
				p2ptr += iw;
				/* If not at end of region's current scan column... */
				if (cy < ey) 
				{
					/* If scan pixel pair matches second pixel pair of */
					/* 1 or more features... */
					if (match_2nd_pair(*p1ptr, *p2ptr, possible, &nposs)) 
					{
						/* Store current y location. */
						y2 = cy;
						/* Skip repeated pixel pairs. */
						skip_repeated_vertical_pair(&cy, ey, &p1ptr, &p2ptr,iw, ih);
						/* If not at end of region's current scan column... */
						if (cy < ey) 
						{
							/* If scan pixel pair matches third pixel pair of */
							/* a single feature... */
							if (match_3rd_pair(*p1ptr, *p2ptr, possible, &nposs)) 
							{
								/* Process detected minutia point. */
								if ((ret = process_vertical_scan_minutia_bin(minutiae,
									cx, cy, y2, possible[0], bdata, iw, ih, pdirection_map))) 
								{
									/* Return code may be:                       */
									/* 1.  ret< 0 (implying system error)        */
									/* 2. ret==IGNORE (ignore current feature)   */
									if (ret < 0)
										return(ret);
									/* Otherwise, IGNORE and continue. */
								}
							}

							/* Set up to resume scan. */
							/* Test to see if 3rd pair can slide into 2nd pair. */
							/* The values of the 2nd pair MUST be different.    */
							/* If 3rd pair values are different ... */
							if (*p1ptr != *p2ptr) 
							{
								/* Set next first pair to last of repeated */
								/* 2nd pairs, ie. back up one pair.        */
								cy--;
							}

							/* Otherwise, 3rd pair can't be a 2nd pair, so  */
							/* keep pointing to 3rd pair so that it is used */
							/* in the next first pair test.                 */

						} /* Else, at end of current scan row. */
					}

					/* Otherwise, 2nd pair failed, so keep pointing to it */
					/* so that it is used in the next first pair test.    */

				} /* Else, at end of current scan column. */
			}
			/* Otherwise, 1st pair failed... */
			else 
			{
				/* Bump forward to next pixel pair. */
				cy++;
			}
		} /* While not at end of current scan column. */
		  /* Bump forward to next scan column. */
		cx++;
	} /* While not out of scan columns. */

	/* Return normally. */
	return(0);
}

void skip_repeated_vertical_pair(int *cy, const int ey,unsigned char **p1ptr, unsigned char **p2ptr,
	const int iw, const int ih)
{
	int old1, old2;

	/* Store starting pixel pair. */
	old1 = **p1ptr;
	old2 = **p2ptr;

	/* Bump vertically to next pixel pair. */
	(*cy)++;
	(*p1ptr) += iw;
	(*p2ptr) += iw;

	/* While not at bottom of scan region... */
	while (*cy < ey) {
		/* If one or the other pixels in the new pair are different */
		/* from the starting pixel pair...                          */
		if ((**p1ptr != old1) || (**p2ptr != old2))
			/* Done skipping repreated pixel pairs. */
			return;
		/* Otherwise, bump vertically to next pixel pair. */
		(*cy)++;
		(*p1ptr) += iw;
		(*p2ptr) += iw;
	}
}

int process_vertical_scan_minutia_bin(MINUTIAE_ *minutiae,const int cx, const int cy,const int y2, 
	const int feature_id,unsigned char *bdata, const int iw, const int ih,
	unsigned char *pdirection_map)
{
	MINUTIA_ *minutia;
	int x_loc, y_loc;
	int x_edge, y_edge;
	int idir, ret;
	int dmapval;

	/* Feature location should always point to either ending  */
	/* of ridge or (for bifurcations) ending of valley.       */
	/* So, if detected feature is APPEARING...                */
	if (feature_patterns[feature_id].appearing) {
		/* Set x location to second scan column. */
		x_loc = cx + 1;
		/* Set x location of neighboring edge pixel to the first scan column. */
		x_edge = cx;
	}
	/* Otherwise, feature is DISAPPEARING... */
	else {
		/* Set x location to first scan column. */
		x_loc = cx;
		/* Set x location of neighboring edge pixel to the second scan column. */
		x_edge = cx + 1;
	}

	/* Set y location of minutia point to be half way between */
	/* first position of second feature pair and position of  */
	/* third feature pair.                                    */
	y_loc = (cy + y2) >> 1;
	/* Set same y location to neighboring edge pixel. */
	y_edge = y_loc;

	dmapval = *(pdirection_map + (y_loc*iw) + x_loc);

	/* If the minutia point is in a block with INVALID direction ... */
	if (dmapval == INVALID_DIR)
		/* Then, IGNORE the point. */
		return(IGNORE);

	/* Get minutia direction based on current block's direction. */
	idir = get_low_curvature_direction(SCAN_VERTICAL,
		feature_patterns[feature_id].appearing, dmapval,
		NUM_DIRECTIONS);

	/* Create a minutia object based on derived attributes. */
	if ((ret = create_minutia(&minutia, x_loc, y_loc, x_edge, y_edge, idir,
		feature_patterns[feature_id].type,
		feature_patterns[feature_id].appearing, feature_id)))
		/* Return system error. */
		return(ret);

	/* Update the minutiae list with potential new minutia. */
	ret = update_minutiae(minutiae, minutia, SCAN_VERTICAL,dmapval, bdata, iw, ih);

	/* If minuitia IGNORED and not added to the minutia list ... */
	if (ret == IGNORE)
		/* Deallocate the minutia. */
		free_minutia(minutia);

	/* Otherwise, return normally. */
	return(0);
}

void gray2bin(const int thresh, const int less_pix, const int greater_pix,
	unsigned char *bdata, const int iw, const int ih)
{
	int i;

	for (i = 0; i < iw*ih; i++) {
		if (bdata[i] >= thresh)
			bdata[i] = (unsigned char)greater_pix;
		else
			bdata[i] = (unsigned char)less_pix;
	}
}

int alloc_minutiae(MINUTIAE_ **ominutiae, const int max_minutiae)
{
	MINUTIAE_ *minutiae;

	minutiae = (MINUTIAE_ *)malloc(sizeof(MINUTIAE_));
	if (minutiae == (MINUTIAE_ *)NULL) {
		//exit(-430);
	}
	minutiae->list = (MINUTIA_ **)malloc(max_minutiae * sizeof(MINUTIA_ *));
	if (minutiae->list == (MINUTIA_ **)NULL) {
		//exit(-431);
	}

	minutiae->alloc = max_minutiae;
	minutiae->num = 0;

	*ominutiae = minutiae;
	return(0);
}

int realloc_minutiae(MINUTIAE_ *minutiae, const int incr_minutiae)
{
	minutiae->alloc += incr_minutiae;
	minutiae->list = (MINUTIA_ **)realloc(minutiae->list,
		minutiae->alloc * sizeof(MINUTIA_ *));
	if (minutiae->list == (MINUTIA_ **)NULL)
	{
		//exit(-432);
	}
	return(0);
}

void free_minutiae(MINUTIAE_ *minutiae)
{
	int i;

	/* Deallocate minutia structures in the list. */
	for (i = 0; i < minutiae->num; i++)
		free_minutia(minutiae->list[i]);
	/* Deallocate list of minutia pointers. */
	free(minutiae->list);

	/* Deallocate the list structure. */
	free(minutiae);
}

void free_minutia(MINUTIA_ *minutia)
{
	/* Deallocate the minutia structure. */
	free(minutia);
}

int remove_minutia(const int index, MINUTIAE_ *minutiae)
{
	int fr, to;
	/* Make sure the requested index is within range. */
	if ((index < 0) && (index >= minutiae->num)) 
	{
		return(-380);
	}

	/* Deallocate the minutia structure to be removed. */
	free_minutia(minutiae->list[index]);

	/* Slide the remaining list of minutiae up over top of the */
	/* position of the minutia being removed.                 */
	for (to = index, fr = index + 1; fr < minutiae->num; to++, fr++)
		minutiae->list[to] = minutiae->list[fr];

	/* Decrement the number of minutiae remaining in the list. */
	minutiae->num--;

	/* Return normally. */
	return(0);
}

int remove_false_minutia_bin(MINUTIAE_ *minutiae,unsigned char *bdata, const int iw, const int ih,
	unsigned char *direction_map)
{
	int ret;

	/* 1. Sort minutiae points top-to-bottom and left-to-right. */
	if ((ret = sort_minutiae_y_x(minutiae, iw, ih)))
	{
		return(ret);
	}

	/* 4. Remove minutiae that point sufficiently close to a block with */
	/*    INVALID direction.                                            */
	if ((ret = remove_pointing_invblock_bin(minutiae, direction_map, iw, ih))) 
	{
		return(ret);
	}

	/* 5. Remove minutiae that are sufficiently close to a block with */
	/*    INVALID direction.                                          */
	//if ((ret = remove_near_invblock_bin(minutiae, direction_map, iw,ih))) 
	//{
	//	return(ret);
	//}

	/* 6. Remove or adjust minutiae that reside on the side of a ridge */
	/*    or valley.                                                   */
	if ((ret = remove_or_adjust_side_minutiae_bin(minutiae, bdata, iw, ih,direction_map))) 
	{
		return(ret);
	}

	return(0);
}

int sort_minutiae_y_x(MINUTIAE_ *minutiae, const int iw, const int ih)
{
	int *ranks, *order;
	int i, ret;
	MINUTIA_ **newlist;

	/* Allocate a list of integers to hold 1-D image pixel offsets */
	/* for each of the 2-D minutia coordinate points.               */
	ranks = (int *)malloc(minutiae->num * sizeof(int));
	if (ranks == (int *)NULL) 
	{
		return(-310);
	}

	/* Compute 1-D image pixel offsets form 2-D minutia coordinate points. */
	for (i = 0; i < minutiae->num; i++)
		ranks[i] = (minutiae->list[i]->y * iw) + minutiae->list[i]->x;

	/* Get sorted order of minutiae. */
	if ((ret = sort_indices_int_inc(&order, ranks, minutiae->num))) {
		free(ranks);
		return(ret);
	}

	/* Allocate new MINUTIA list to hold sorted minutiae. */
	newlist = (MINUTIA_ **)malloc(minutiae->num * sizeof(MINUTIA_ *));
	if (newlist == (MINUTIA_ **)NULL) {
		free(ranks);
		free(order);
		return(-311);
	}

	/* Put minutia into sorted order in new list. */
	for (i = 0; i < minutiae->num; i++)
		newlist[i] = minutiae->list[order[i]];

	/* Deallocate non-sorted list of minutia pointers. */
	free(minutiae->list);
	/* Assign new sorted list of minutia to minutiae list. */
	minutiae->list = newlist;

	/* Free the working memories supporting the sort. */
	free(order);
	free(ranks);

	/* Return normally. */
	return(0);
}

int sort_indices_int_inc(int **optr, int *ranks, const int num)
{
	int *order;
	int i;

	/* Allocate list of sequential indices. */
	order = (int *)malloc(num * sizeof(int));
	if (order == (int *)NULL)
	{
		return(-390);
	}
	/* Initialize list of sequential indices. */
	for (i = 0; i < num; i++)
		order[i] = i;

	/* Sort the indecies into rank order. */
	bubble_sort_int_inc_2(ranks, order, num);

	/* Set output pointer to the resulting order of sorted indices. */
	*optr = order;
	/* Return normally. */
	return(0);
}

void bubble_sort_int_inc_2(int *ranks, int *items, const int len)
{
	int done = 0;
	int i, p, n, trank, titem;

	/* Set counter to the length of the list being sorted. */
	n = len;
	/* While swaps in order continue to occur from the */
	/* previous iteration...                           */
	while (!done) {
		/* Reset the done flag to TRUE. */
		done = 1;
		/* Foreach rank in list up to current end index...               */
		/* ("p" points to current rank and "i" points to the next rank.) */
		for (i = 1, p = 0; i<n; i++, p++) {
			/* If previous rank is < current rank ... */
			if (ranks[p] > ranks[i]) {
				/* Swap ranks. */
				trank = ranks[i];
				ranks[i] = ranks[p];
				ranks[p] = trank;
				/* Swap items. */
				titem = items[i];
				items[i] = items[p];
				items[p] = titem;
				/* Changes were made, so set done flag to FALSE. */
				done = 0;
			}
			/* Otherwise, rank pair is in order, so continue. */
		}
		/* Decrement the ending index. */
		n--;
	}
}

int remove_pointing_invblock_bin(MINUTIAE_ *minutiae,unsigned char *direction_map, const int mw, const int mh)
{
	int i, ret;
	int delta_x, delta_y, dmapval;
	int nx, ny, bx, by;
	MINUTIA_ *minutia;
	int theta;
	int dx, dy;

	/* Compute factor for converting integer directions to radians. */
	//pi_factor = PI / NUM_DIRECTIONS;

	i = 0;
	/* Foreach minutia remaining in list ... */
	while (i < minutiae->num) 
	{
		/* Set temporary minutia pointer. */
		minutia = minutiae->list[i];
		/* Convert minutia's direction to radians. */
		theta = minutia->direction * 180 / NUM_DIRECTIONS;
		/* Compute translation offsets (ex. 6 pixels). */
		dx = (sin_int_table[theta] * TRANS_DIR_PIX_V2)>> SIN_COS_SCAL_BIT;
		dy = (cos_int_table[theta] * TRANS_DIR_PIX_V2) >> SIN_COS_SCAL_BIT;
		/* Need to truncate precision so that answers are consistent */
		/* on different computer architectures when rounding doubles. */
		//dx = trunc_dbl_precision(dx, TRUNC_SCALE);
		//dy = trunc_dbl_precision(dy, TRUNC_SCALE);
		delta_x = dx;// sround(dx);
		delta_y = dy;// sround(dy);
		/* Translate the minutia's coords. */
		nx = minutia->x - delta_x;
		ny = minutia->y + delta_y;
		/* Convert pixel coords to block coords. */
		bx = nx;// (int)(nx / lfsparms->blocksize); //blocksize = 1
		by = ny;// (int)(ny / lfsparms->blocksize); //blocksize = 1
		/* The translation could move the point out of image boundaries,    */
		/* and therefore the corresponding block coords can be out of       */
		/* map boundaries, so limit the block coords to within boundaries.  */
		bx = max(0, bx);
		bx = min(mw - 1, bx);
		by = max(0, by);
		by = min(mh - 1, by);

		/* Get corresponding block's ridge flow direction. */
		dmapval = *(direction_map + (by*mw) + bx);

		/* If the block's direction is INVALID ... */
		if (dmapval == INVALID_DIR) 
		{
			/* Remove the minutia from the minutiae list. */
			if ((ret = remove_minutia(i, minutiae)))
			{
				return(ret);
			}
			/* No need to advance because next minutia has slid into slot. */
		}
		else
		{
			/* Advance to next minutia in list. */
			i++;
		}
	}

	/* Return normally. */
	return(0);
}

//int remove_near_invblock_bin(MINUTIAE_ *minutiae, int *direction_map, const int mw, const int mh)
//{
//	int i, ret;
//	int ni, nbx, nby, nvalid;
//	int ix, iy, sbi, ebi;
//	int bx, by, px, py;
//	int removed;
//	MINUTIA_ *minutia;
//	int lo_margin, hi_margin;

//	/* The next 2 lookup tables are indexed by 'ix' and 'iy'. */
//	/* When a feature pixel lies within a 6-pixel margin of a */
//	/* block, this routine examines neighboring blocks to     */
//	/* determine appropriate actions.                         */
//	/*    'ix' may take on values:                            */
//	/*         0 == x-pixel coord in leftmost margin          */
//	/*         1 == x-pixel coord in middle of block          */
//	/*         2 == x-pixel coord in rightmost margin         */
//	/*    'iy' may take on values:                            */
//	/*         0 == y-pixel coord in topmost margin           */
//	/*         1 == y-pixel coord in middle of block          */
//	/*         2 == y-pixel coord in bottommost margin        */
//	/* Given (ix, iy):                                        */
//	/*    'startblk[ix][iy]' == starting neighbor index (sbi) */
//	/*    'endblk[ix][iy]'   == ending neighbor index (ebi)   */
//	/*    so that neighbors begin to be analized from index   */
//	/*    'sbi' to 'ebi'.                                     */
//	/* Ex. (ix, iy) = (2, 0)                                  */
//	/*    ix==2 ==> x-pixel coord in rightmost margin         */
//	/*    iy==0 ==> y-pixel coord in topmost margin           */
//	/*    X - marks the region in the current block           */
//	/*        corresponding to (ix=2, iy=0).                  */
//	/*    sbi = 0 = startblk[2][0]                            */
//	/*    ebi = 2 = endblk[2][0]                              */
//	/*    so neighbors are analized on index range [0..2]     */
//	/*                                |                       */
//	/*                 nbr block 0    |  nbr block 1          */
//	/*      --------------------------+------------           */
//	/*           top margin      | X  |                       */
//	/*      _._._._._._._._._._._._._.|                       */
//	/*                           |    |                       */
//	/*          current block    .r  m|  nbr block 2          */
//	/*                           |i  a|                       */
//	/*                           .g  g|                       */
//	/*                           |h  i|                       */
//	/*                           .t  n|                       */
//	/*                           |    |                       */

//	/* LUT for starting neighbor index given (ix, iy).        */
//	static int startblk[9] = { 6, 0, 0,
//							   6,-1, 2,
//							   4, 4, 2 };
//	/* LUT for ending neighbor index given (ix, iy).          */
//	static int endblk[9] = { 8, 0, 2,
//							 6,-1, 2,
//							 6, 4, 4 };

//	/* Pixel coord offsets specifying the order in which neighboring */
//	/* blocks are searched.  The current block is in the middle of   */
//	/* 8 surrounding neighbors.  The following illustrates the order */
//	/* of neighbor indices.  (Note that 9 overlaps 1.)               */
//	/*                        8                                      */
//	/*                      7 0 1                                    */
//	/*                      6 C 2                                    */
//	/*                      5 4 3                                    */
//	/*                                                               */
//	/*                       0  1  2  3  4  5  6  7  8                    */
//	static int blkdx[9] = { 0, 1, 1, 1, 0,-1,-1,-1, 0 };  /* Delta-X     */
//	static int blkdy[9] = { -1,-1, 0, 1, 1, 1, 0,-1,-1 };  /* Delta-Y     */

//	int blocksize = 1;
//	/* If the margin covers more than the entire block ... */
//	if (INV_BLOCK_MARGIN_V2 > (blocksize >> 1)) 
//	{
//		/* Then treat this as an error. */
//		return(-620);
//	}

//	/* Compute the low and high pixel margin boundaries (ex. 6 pixels wide) */
//	/* in the block.                                                        */
//	lo_margin = INV_BLOCK_MARGIN_V2;
//	hi_margin = blocksize - INV_BLOCK_MARGIN_V2 - 1;

//	i = 0;
//	/* Foreach minutia remaining in the list ... */
//	while (i < minutiae->num) 
//	{
//		/* Assign temporary minutia pointer. */
//		minutia = minutiae->list[i];

//		/* Compute block coords from minutia's pixel location. */
//		bx = minutia->x / blocksize;
//		by = minutia->y / blocksize;

//		/* Compute pixel offset into the image block corresponding to the */
//		/* minutia's pixel location.                                      */
//		/* NOTE: The margins used here will not necessarily correspond to */
//		/* the actual block boundaries used to compute the map values.    */
//		/* This will be true when the image width and/or height is not an */
//		/* even multiple of 'blocksize' and we are processing minutia     */
//		/* located in the right-most column (or bottom-most row) of       */
//		/* blocks.  I don't think this will pose a problem in practice.   */
//		px = minutia->x % blocksize;
//		py = minutia->y % blocksize;

//		/* Determine if x pixel offset into the block is in the margins. */
//		/* If x pixel offset is in left margin ... */
//		if (px < lo_margin)
//			ix = 0;
//		/* If x pixel offset is in right margin ... */
//		else if (px > hi_margin)
//			ix = 2;
//		/* Otherwise, x pixel offset is in middle of block. */
//		else
//			ix = 1;

//		/* Determine if y pixel offset into the block is in the margins. */
//		/* If y pixel offset is in top margin ... */
//		if (py < lo_margin)
//			iy = 0;
//		/* If y pixel offset is in bottom margin ... */
//		else if (py > hi_margin)
//			iy = 2;
//		/* Otherwise, y pixel offset is in middle of block. */
//		else
//			iy = 1;

//		/* Set remove flag to FALSE. */
//		removed = 0;

//		/* If one of the minutia's pixel offsets is in a margin ... */
//		if ((ix != 1) || (iy != 1)) {

//			/* Compute the starting neighbor block index for processing. */
//			sbi = *(startblk + (iy * 3) + ix);
//			/* Compute the ending neighbor block index for processing. */
//			ebi = *(endblk + (iy * 3) + ix);

//			/* Foreach neighbor in the range to be processed ... */
//			for (ni = sbi; ni <= ebi; ni++) {
//				/* Compute the neighbor's block coords relative to */
//				/* the block the current minutia is in.            */
//				nbx = bx + blkdx[ni];
//				nby = by + blkdy[ni];

//				/* If neighbor's block coords are outside of map boundaries... */
//				if ((nbx < 0) || (nbx >= mw) ||(nby < 0) || (nby >= mh)) 
//				{
//					/* Then the minutia is in a margin adjacent to the edge of */
//					/* the image.                                              */
//					/* NOTE: This is true when the image width and/or height   */
//					/* is an even multiple of blocksize.  When the image is not*/
//					/* an even multiple, then some minutia may not be detected */
//					/* as being in the margin of "the image" (not the block).  */
//					/* In practice, I don't think this will impact performance.*/
//					if ((ret = remove_minutia(i, minutiae)))
//						/* If system error occurred while removing minutia, */
//						/* then return error code.                          */
//						return(ret);
//					/* Set remove flag to TURE. */
//					removed = 1;
//					/* Break out of neighboring block loop. */
//					break;
//				}
//				/* If the neighboring block has INVALID direction ... */
//				else if (*(direction_map + (nby*mw) + nbx) == INVALID_DIR) 
//				{
//					/* Count the number of valid blocks neighboring */
//					/* the current neighbor.                        */
//					nvalid = num_valid_8nbrs(direction_map, nbx, nby, mw, mh);
//					/* If the number of valid neighbors is < threshold */
//					/* (ex. 7)...                                      */
//					if (nvalid < RM_VALID_NBR_MIN) 
//					{
//						/* Then remove the current minutia from the list. */
//						if ((ret = remove_minutia(i, minutiae)))
//							/* If system error occurred while removing minutia, */
//							/* then return error code.                          */
//							return(ret);
//						/* Set remove flag to TURE. */
//						removed = 1;
//						/* Break out of neighboring block loop. */
//						break;
//					}
//					/* Otherwise enough valid neighbors, so don't remove minutia */
//					/* based on this neighboring block.                          */
//				}
//				/* Otherwise neighboring block has valid direction,         */
//				/* so don't remove minutia based on this neighboring block. */
//			}
//		} /* Otherwise not in margin, so skip to next minutia in list. */
//		  /* If current minutia not removed ... */
//		if (!removed)
//			/* Advance to the next minutia in the list. */
//			i++;
//		/* Otherwise the next minutia has slid into the spot where current */
//		/* minutia was removed, so don't bump minutia index.               */
//	} /* End minutia loop */

//	  /* Return normally. */
//	return(0);
//}

//int num_valid_8nbrs(int *imap, const int mx, const int my,const int mw, const int mh)
//{
//	int e_ind, w_ind, n_ind, s_ind;
//	int nvalid;

//	/* Initialize VALID IMAP counter to zero. */
//	nvalid = 0;

//	/* Compute neighbor coordinates to current IMAP direction */
//	e_ind = mx + 1;  /* East index */
//	w_ind = mx - 1;  /* West index */
//	n_ind = my - 1;  /* North index */
//	s_ind = my + 1;  /* South index */

//					 /* 1. Test NW IMAP value.  */
//					 /* If neighbor indices are within IMAP boundaries and it is VALID ... */
//	if ((w_ind >= 0) && (n_ind >= 0) && (*(imap + (n_ind*mw) + w_ind) >= 0))
//		/* Bump VALID counter. */
//		nvalid++;

//	/* 2. Test N IMAP value.  */
//	if ((n_ind >= 0) && (*(imap + (n_ind*mw) + mx) >= 0))
//		nvalid++;

//	/* 3. Test NE IMAP value. */
//	if ((n_ind >= 0) && (e_ind < mw) && (*(imap + (n_ind*mw) + e_ind) >= 0))
//		nvalid++;

//	/* 4. Test E IMAP value. */
//	if ((e_ind < mw) && (*(imap + (my*mw) + e_ind) >= 0))
//		nvalid++;

//	/* 5. Test SE IMAP value. */
//	if ((e_ind < mw) && (s_ind < mh) && (*(imap + (s_ind*mw) + e_ind) >= 0))
//		nvalid++;

//	/* 6. Test S IMAP value. */
//	if ((s_ind < mh) && (*(imap + (s_ind*mw) + mx) >= 0))
//		nvalid++;

//	/* 7. Test SW IMAP value. */
//	if ((w_ind >= 0) && (s_ind < mh) && (*(imap + (s_ind*mw) + w_ind) >= 0))
//		nvalid++;

//	/* 8. Test W IMAP value. */
//	if ((w_ind >= 0) && (*(imap + (my*mw) + w_ind) >= 0))
//		nvalid++;

//	/* Return number of neighbors with VALID IMAP values. */
//	return(nvalid);
//}

int remove_or_adjust_side_minutiae_bin(MINUTIAE_ *minutiae,unsigned char *bdata, const int iw, const int ih,
	unsigned char *direction_map)
{
	int i, j, ret;
	MINUTIA_ *minutia;
	int theta, sin_theta, cos_theta;
	int *contour_x, *contour_y, *contour_ex, *contour_ey, ncontour;
	int *rot_y, minloc;
	int *minmax_val, *minmax_i, *minmax_type, minmax_alloc, minmax_num;
	int drot_y;
	int bx, by;


	/* Allocate working memory for holding rotated y-coord of a */
	/* minutia's contour.                                       */
	rot_y = (int *)malloc(((SIDE_HALF_CONTOUR << 1) + 1) * sizeof(int));
	if (rot_y == (int *)NULL) 
	{
		return(-630);
	}

	/* Compute factor for converting integer directions to radians. */
	//pi_factor = M_PI / (double)lfsparms->num_directions;

	i = 0;
	/* Foreach minutia remaining in list ... */
	while (i < minutiae->num) 
	{
		/* Assign a temporary pointer. */
		minutia = minutiae->list[i];

		/* Extract a contour centered on the minutia point (ex. 7 pixels */
		/* in both directions).                                          */
		ret = get_centered_contour(&contour_x, &contour_y,&contour_ex, &contour_ey, &ncontour,
			SIDE_HALF_CONTOUR,minutia->x, minutia->y, minutia->ex, minutia->ey,bdata, iw, ih);

		/* If system error occurred ... */
		if (ret < 0)
		{
			/* Deallocate working memory. */
			free(rot_y);
			/* Return error code. */
			return(ret);
		}

		/* If we didn't succeed in extracting a complete contour for any */
		/* other reason ...                                              */
		if ((ret == LOOP_FOUND) ||(ret == IGNORE) ||(ret == INCOMPLETE)) 
		{
			/* Remove minutia from list. */
			if ((ret = remove_minutia(i, minutiae))) 
			{
				/* Deallocate working memory. */
				free(rot_y);
				/* Return error code. */
				return(ret);
			}
			/* No need to advance because next minutia has "slid" */
			/* into position pointed to by 'i'.                   */
		}
		/* Otherwise, a complete contour was found and extracted ... */
		else
		{
			/* Rotate contour points by negative angle of feature's direction. */
			/* The contour of a well-formed minutia point will form a bowl     */
			/* shape concaved in the direction of the minutia.  By rotating    */
			/* the contour points by the negative angle of feature's direction */
			/* the bowl will be transformed to be concaved upwards and minima  */
			/* and maxima of the transformed y-coords can be analyzed to       */
			/* determine if the minutia is "well-formed" or not.  If well-     */
			/* formed then the position of the minutia point is adjusted.  If  */
			/* not well-formed, then the minutia point is removed altogether.  */

			/* Normal rotation of T degrees around the origin of */
			/*      the point (x,y):                             */
			/*         rx = x*cos(T) - y*sin(T)                  */
			/*         ry = x*cos(T) + y*sin(T)                  */
			/*      The rotation here is for -T degrees:         */
			/*         rx = x*cos(-T) - y*sin(-T)                */
			/*         ry = x*cos(-T) + y*sin(-T)                */
			/*      which can be written:                        */
			/*         rx = x*cos(T) + y*sin(T)                  */
			/*         ry = x*sin(T) - y*cos(T)                  */

			/* Convert minutia's direction to radians. */
			theta = minutia->direction * 180 / NUM_DIRECTIONS;
			/* Compute sine and cosine values at theta for rotation. */
			sin_theta = sin_int_table[theta];
			cos_theta = cos_int_table[theta];

			for (j = 0; j < ncontour; j++) 
			{
				/* We only need to rotate the y-coord (don't worry     */
				/* about rotating the x-coord or contour edge pixels). */
				drot_y = ((contour_x[j] * sin_theta) -(contour_y[j] * cos_theta))>> SIN_COS_SCAL_BIT;
				/* Need to truncate precision so that answers are consistent */
				/* on different computer architectures when rounding doubles. */
				//drot_y = trunc_dbl_precision(drot_y, TRUNC_SCALE);
				rot_y[j] = drot_y;// sround(drot_y);
			}

			/* Locate relative minima and maxima in vector of rotated */
			/* y-coords of current minutia's contour.                 */
			if ((ret = minmaxs(&minmax_val, &minmax_type, &minmax_i,&minmax_alloc, &minmax_num,rot_y, ncontour))) 
			{
				/* If system error, then deallocate working memories. */
				free(rot_y);
				free_contour(contour_x, contour_y, contour_ex, contour_ey);
				/* Return error code. */
				return(ret);
			}

			/* If one and only one minima was found in rotated y-coord */
			/* of contour ...                                          */
			if ((minmax_num == 1) && (minmax_type[0] == -1)) 
			{
				/* Reset loation of minutia point to contour point at minima. */
				minutia->x = contour_x[minmax_i[0]];
				minutia->y = contour_y[minmax_i[0]];
				minutia->ex = contour_ex[minmax_i[0]];
				minutia->ey = contour_ey[minmax_i[0]];

				/* Must check if adjusted minutia is now in INVALID block ... */
				bx = minutia->x;// / lfsparms->blocksize;
				by = minutia->y;// / lfsparms->blocksize;
				if (*(direction_map + (by*iw) + bx) == INVALID_DIR)
				{
					/* Remove minutia from list. */
					if ((ret = remove_minutia(i, minutiae))) 
					{
						/* Deallocate working memory. */
						free(rot_y);
						free_contour(contour_x, contour_y, contour_ex, contour_ey);
						if (minmax_alloc > 0) 
						{
							free(minmax_val);
							free(minmax_type);
							free(minmax_i);
						}
						/* Return error code. */
						return(ret);
					}
					/* No need to advance because next minutia has "slid" */
					/* into position pointed to by 'i'.                   */
				}
				else 
				{
					/* Advance to the next minutia in the list. */
					i++;
				}

			}
			/* If exactly 3 min/max found and they are min-max-min ... */
			else if ((minmax_num == 3) &&(minmax_type[0] == -1)) {
				/* Choose minima location with smallest rotated y-coord. */
				if (minmax_val[0] < minmax_val[2])
					minloc = minmax_i[0];
				else
					minloc = minmax_i[2];

				/* Reset loation of minutia point to contour point at minima. */
				minutia->x = contour_x[minloc];
				minutia->y = contour_y[minloc];
				minutia->ex = contour_ex[minloc];
				minutia->ey = contour_ey[minloc];

				/* Must check if adjusted minutia is now in INVALID block ... */
//				int blocksize = 1;
				bx = minutia->x;
				by = minutia->y;
				if (*(direction_map + (by*iw) + bx) == INVALID_DIR)
				{
					/* Remove minutia from list. */
					if ((ret = remove_minutia(i, minutiae)))
					{
						/* Deallocate working memory. */
						free(rot_y);
						free_contour(contour_x, contour_y, contour_ex, contour_ey);
						if (minmax_alloc > 0) 
						{
							free(minmax_val);
							free(minmax_type);
							free(minmax_i);
						}
						/* Return error code. */
						return(ret);
					}
					/* No need to advance because next minutia has "slid" */
					/* into position pointed to by 'i'.                   */
				}
				else 
				{
					/* Advance to the next minutia in the list. */
					i++;
				}
			}
			/* Otherwise, ... */
			else 
			{
				/* Remove minutia from list. */
				if ((ret = remove_minutia(i, minutiae))) 
				{
					/* If system error, then deallocate working memories. */
					free(rot_y);
					free_contour(contour_x, contour_y, contour_ex, contour_ey);
					if (minmax_alloc > 0) 
					{
						free(minmax_val);
						free(minmax_type);
						free(minmax_i);
					}
					/* Return error code. */
					return(ret);
				}
				/* No need to advance because next minutia has "slid" */
				/* into position pointed to by 'i'.                   */
			}

			/* Deallocate contour and min/max buffers. */
			free_contour(contour_x, contour_y, contour_ex, contour_ey);
			if (minmax_alloc > 0) 
			{
				free(minmax_val);
				free(minmax_type);
				free(minmax_i);
			}
		} /* End else contour extracted. */
	} /* End while not end of minutiae list. */

	  /* Deallocate working memory. */
	free(rot_y);

	/* Return normally. */
	return(0);
}

int get_centered_contour(int **ocontour_x, int **ocontour_y,int **ocontour_ex, int **ocontour_ey, 
	int *oncontour,const int half_contour,const int x_loc, const int y_loc,const int x_edge, 
	const int y_edge,unsigned char *bdata, const int iw, const int ih)
{
	int max_contour;
	int *half1_x, *half1_y, *half1_ex, *half1_ey, nhalf1;
	int *half2_x, *half2_y, *half2_ex, *half2_ey, nhalf2;
	int *contour_x, *contour_y, *contour_ex, *contour_ey, ncontour;
	int i, j, ret;

	/* Compute maximum length of complete contour */
	/* (2 half contours + feature point).         */
	max_contour = (half_contour << 1) + 1;

	/* Initialize output contour length to 0. */
	*oncontour = 0;

	/* Get 1st half contour with clockwise neighbor trace. */
	ret = trace_contour(&half1_x, &half1_y, &half1_ex, &half1_ey, &nhalf1,
		half_contour, x_loc, y_loc, x_loc, y_loc, x_edge, y_edge,SCAN_CLOCKWISE, bdata, iw, ih);

	/* If system error occurred ... */
	if (ret < 0) 
	{
		/* Return error code. */
		return(ret);
	}

	/* If trace was not possible ... */
	if (ret == IGNORE)
		/* Return IGNORE, with nothing allocated. */
		return(IGNORE);

	/* If 1st half contour forms a loop ... */
	if (ret == LOOP_FOUND) 
	{
		/* Deallocate loop's contour. */
		free_contour(half1_x, half1_y, half1_ex, half1_ey);
		/* Return LOOP_FOUND, with nothing allocated. */
		return(LOOP_FOUND);
	}

	/* If 1st half contour not complete ... */
	if (nhalf1 < half_contour)
	{
		/* Deallocate the partial contour. */
		free_contour(half1_x, half1_y, half1_ex, half1_ey);
		/* Return, with nothing allocated and contour length equal to 0. */
		return(INCOMPLETE);
	}

	/* Otherwise, we have a complete 1st half contour...           */
	/* Get 2nd half contour with counter-clockwise neighbor trace. */
	/* Use the last point from the first contour trace as the      */
	/* point to test for a loop when tracing the second contour.   */
	ret = trace_contour(&half2_x, &half2_y, &half2_ex, &half2_ey, &nhalf2,half_contour,half1_x[nhalf1 - 1], 
		half1_y[nhalf1 - 1],x_loc, y_loc, x_edge, y_edge,SCAN_COUNTER_CLOCKWISE, bdata, iw, ih);

	/* If system error occurred on 2nd trace ... */
	if (ret < 0)
	{
		/* Return error code. */
		return(ret);
	}

	/* If 2nd trace was not possible ... */
	if (ret == IGNORE) 
	{
		/* Deallocate the 1st half contour. */
		free_contour(half1_x, half1_y, half1_ex, half1_ey);
		/* Return, with nothing allocated and contour length equal to 0. */
		return(IGNORE);
	}

	/* If 2nd trace forms a loop ... */
	if (ret == LOOP_FOUND) 
	{
		/* Deallocate 1st and 2nd half contours. */
		free_contour(half1_x, half1_y, half1_ex, half1_ey);
		free_contour(half2_x, half2_y, half2_ex, half2_ey);
		/* Return LOOP_FOUND, with nothing allocated. */
		return(LOOP_FOUND);
	}

	/* If 2nd half contour not complete ... */
	if (nhalf2 < half_contour)
	{
		/* Deallocate 1st and 2nd half contours. */
		free_contour(half1_x, half1_y, half1_ex, half1_ey);
		free_contour(half2_x, half2_y, half2_ex, half2_ey);
		/* Return, with nothing allocated and contour length equal to 0. */
		return(INCOMPLETE);
	}

	/* Otherwise we have a full 1st half contour and a 2nd half contour */
	/* that do not form a loop and are complete.  We now need to        */
	/* concatenate the two half contours into one longer contour.       */

	/* Allocate output contour list. */
	if ((ret = allocate_contour(&contour_x, &contour_y,&contour_ex, &contour_ey, max_contour)))
	{
		/* If allcation error, then deallocate memory allocated to */
		/* this point in this routine.                             */
		free_contour(half1_x, half1_y, half1_ex, half1_ey);
		free_contour(half2_x, half2_y, half2_ex, half2_ey);
		/* Return error code. */
		return(ret);
	}

	/* Set the current contour point counter to 0 */
	ncontour = 0;

	/* Copy 1st half contour into output contour buffers.      */
	/* This contour was collected clockwise, so it's points    */
	/* are entered in reverse order of the trace.  The result  */
	/* is the first point in the output contour if farthest    */
	/* from the starting feature point.                        */
	for (i = 0, j = nhalf1 - 1; i < nhalf1; i++, j--)
	{
		contour_x[i] = half1_x[j];
		contour_y[i] = half1_y[j];
		contour_ex[i] = half1_ex[j];
		contour_ey[i] = half1_ey[j];
		ncontour++;
	}

	/* Deallocate 1st half contour. */
	free_contour(half1_x, half1_y, half1_ex, half1_ey);

	/* Next, store starting feature point into output contour buffers. */
	contour_x[nhalf1] = x_loc;
	contour_y[nhalf1] = y_loc;
	contour_ex[nhalf1] = x_edge;
	contour_ey[nhalf1] = y_edge;
	ncontour++;

	/* Now, append 2nd half contour to permanent contour buffers.  */
	for (i = 0, j = nhalf1 + 1; i < nhalf2; i++, j++) 
	{
		contour_x[j] = half2_x[i];
		contour_y[j] = half2_y[i];
		contour_ex[j] = half2_ex[i];
		contour_ey[j] = half2_ey[i];
		ncontour++;
	}

	/* Deallocate 2nd half contour. */
	free_contour(half2_x, half2_y, half2_ex, half2_ey);

	/* Assign outputs contour to output ponters. */
	*ocontour_x = contour_x;
	*ocontour_y = contour_y;
	*ocontour_ex = contour_ex;
	*ocontour_ey = contour_ey;
	*oncontour = ncontour;

	/* Return normally. */
	return(0);
}

int trace_contour(int **ocontour_x, int **ocontour_y,int **ocontour_ex, int **ocontour_ey, int *oncontour,
	const int max_len, const int x_loop, const int y_loop,const int x_loc, const int y_loc,
	const int x_edge, const int y_edge,const int scan_clock,unsigned char *bdata, const int iw, const int ih)
{
	int *contour_x, *contour_y, *contour_ex, *contour_ey, ncontour;
	int cur_x_loc, cur_y_loc;
	int cur_x_edge, cur_y_edge;
	int next_x_loc, next_y_loc;
	int next_x_edge, next_y_edge;
	int i, ret;

	/* Check to make sure that the feature and edge values are opposite. */
	if (*(bdata + (y_loc*iw) + x_loc) ==
		*(bdata + (y_edge*iw) + x_edge))
		/* If not opposite, then the trace will not work, so return IGNORE. */
		return(IGNORE);

	/* Allocate contour buffers. */
	if ((ret = allocate_contour(&contour_x, &contour_y, &contour_ex, &contour_ey, max_len))) 
	{
		/* If allocation error, return code. */
		return(ret);
	}

	/* Set pixel counter to 0. */
	ncontour = 0;

	/* Set up for finding first contour pixel. */
	cur_x_loc = x_loc;
	cur_y_loc = y_loc;
	cur_x_edge = x_edge;
	cur_y_edge = y_edge;

	/* Foreach pixel to be collected on the feature's contour... */
	for (i = 0; i < max_len; i++) {
		/* Find the next contour pixel. */
		if (next_contour_pixel(&next_x_loc, &next_y_loc,&next_x_edge, &next_y_edge,
			cur_x_loc, cur_y_loc,cur_x_edge, cur_y_edge,scan_clock, bdata, iw, ih)) 
		{

			/* If we trace back around to the specified starting */
			/* feature location...                               */
			if ((next_x_loc == x_loop) && (next_y_loc == y_loop)) {
				/* Then we have found a loop, so return what we */
				/* have traced to this point.                   */
				*ocontour_x = contour_x;
				*ocontour_y = contour_y;
				*ocontour_ex = contour_ex;
				*ocontour_ey = contour_ey;
				*oncontour = ncontour;
				return(LOOP_FOUND);
			}

			/* Otherwise, we found another point on our feature's contour, */
			/* so store the new contour point.                             */
			contour_x[i] = next_x_loc;
			contour_y[i] = next_y_loc;
			contour_ex[i] = next_x_edge;
			contour_ey[i] = next_y_edge;
			/* Bump the number of points stored. */
			ncontour++;

			/* Set up for finding next contour pixel. */
			cur_x_loc = next_x_loc;
			cur_y_loc = next_y_loc;
			cur_x_edge = next_x_edge;
			cur_y_edge = next_y_edge;
		}
		/* Otherwise, no new contour point found ... */
		else 
		{
			/* So, stop short and return the number of pixels found */
			/* on the contour to this point.                        */
			*ocontour_x = contour_x;
			*ocontour_y = contour_y;
			*ocontour_ex = contour_ex;
			*ocontour_ey = contour_ey;
			*oncontour = ncontour;
			/* Return normally. */
			return(0);
		}
	}

	/* If we get here, we successfully found the maximum points we    */
	/* were looking for on the feature contour, so assign the contour */
	/* buffers to the output pointers and return.                     */
	*ocontour_x = contour_x;
	*ocontour_y = contour_y;
	*ocontour_ex = contour_ex;
	*ocontour_ey = contour_ey;
	*oncontour = ncontour;

	/* Return normally. */
	return(0);
}

int minmaxs(int **ominmax_val, int **ominmax_type, int **ominmax_i,int *ominmax_alloc, int *ominmax_num,
	const int *items, const int num)
{
	int i, diff, state, start, loc;
	int *minmax_val, *minmax_type, *minmax_i, minmax_alloc, minmax_num;

	/* Determine maximum length for allocation of buffers. */
	/* If there are fewer than 3 items ...                */
	if (num < 3)
	{
		/* Then no min/max is possible, so set allocated length */
		/* to 0 and return.                                     */
		*ominmax_alloc = 0;
		*ominmax_num = 0;
		return(0);
	}
	/* Otherwise, set allocation length to number of items - 2    */
	/* (one for the first item in the list, and on for the last). */
	/* Every other intermediate point can potentially represent a */
	/* min or max.                                                */
	minmax_alloc = num - 2;
	/* Allocate the buffers. */
	minmax_val = (int *)malloc(minmax_alloc * sizeof(int));
	if (minmax_val == (int *)NULL) 
	{
		return(-290);
	}
	minmax_type = (int *)malloc(minmax_alloc * sizeof(int));
	if (minmax_type == (int *)NULL) 
	{
		free(minmax_val);
		return(-291);
	}
	minmax_i = (int *)malloc(minmax_alloc * sizeof(int));
	if (minmax_i == (int *)NULL) 
	{
		free(minmax_val);
		free(minmax_type);
		return(-292);
	}

	/* Initialize number of min/max to 0. */
	minmax_num = 0;

	/* Start witht the first item in the list. */
	i = 0;

	/* Get starting state between first pair of items. */
	diff = items[1] - items[0];
	if (diff > 0) state = 1;
	else if (diff < 0) state = -1;
	else state = 0;

	/* Set start location to first item in list. */
	start = 0;

	/* Bump to next item in list. */
	i++;

	/* While not at the last item in list. */
	while (i < num - 1) 
	{
		/* Compute difference between next pair of items. */
		diff = items[i + 1] - items[i];
		/* If items are increasing ... */
		if (diff > 0) 
		{
			/* If previously increasing ... */
			if (state == 1) 
			{
				/* Reset start to current location. */
				start = i;
			}
			/* If previously decreasing ... */
			else if (state == -1) 
			{
				/* Then we have incurred a minima ... */
				/* Compute midpoint of minima. */
				loc = (start + i) >> 1;
				/* Store value at minima midpoint. */
				minmax_val[minmax_num] = items[loc];
				/* Store type code for minima. */
				minmax_type[minmax_num] = -1;
				/* Store location of minima midpoint. */
				minmax_i[minmax_num++] = loc;
				/* Change state to increasing. */
				state = 1;
				/* Reset start location. */
				start = i;
			}
			/* If previously level (this state only can occur at the */
			/* beginning of the list of items) ...                   */
			else 
			{
				/* If more than one level state in a row ... */
				if (i - start > 1) 
				{
					/* Then consider a minima ... */
					/* Compute midpoint of minima. */
					loc = (start + i) >> 1;
					/* Store value at minima midpoint. */
					minmax_val[minmax_num] = items[loc];
					/* Store type code for minima. */
					minmax_type[minmax_num] = -1;
					/* Store location of minima midpoint. */
					minmax_i[minmax_num++] = loc;
					/* Change state to increasing. */
					state = 1;
					/* Reset start location. */
					start = i;
				}
				/* Otherwise, ignore single level state. */
				else 
				{
					/* Change state to increasing. */
					state = 1;
					/* Reset start location. */
					start = i;
				}
			}
		}
		/* If items are decreasing ... */
		else if (diff < 0) 
		{
			/* If previously decreasing ... */
			if (state == -1) 
			{
				/* Reset start to current location. */
				start = i;
			}
			/* If previously increasing ... */
			else if (state == 1) 
			{
				/* Then we have incurred a maxima ... */
				/* Compute midpoint of maxima. */
				loc = (start + i) >> 1;
				/* Store value at maxima midpoint. */
				minmax_val[minmax_num] = items[loc];
				/* Store type code for maxima. */
				minmax_type[minmax_num] = 1;
				/* Store location of maxima midpoint. */
				minmax_i[minmax_num++] = loc;
				/* Change state to decreasing. */
				state = -1;
				/* Reset start location. */
				start = i;
			}
			/* If previously level (this state only can occur at the */
			/* beginning of the list of items) ...                   */
			else 
			{
				/* If more than one level state in a row ... */
				if (i - start > 1) 
				{
					/* Then consider a maxima ... */
					/* Compute midpoint of maxima. */
					loc = (start + i) >> 1;
					/* Store value at maxima midpoint. */
					minmax_val[minmax_num] = items[loc];
					/* Store type code for maxima. */
					minmax_type[minmax_num] = 1;
					/* Store location of maxima midpoint. */
					minmax_i[minmax_num++] = loc;
					/* Change state to decreasing. */
					state = -1;
					/* Reset start location. */
					start = i;
				}
				/* Otherwise, ignore single level state. */
				else 
				{
					/* Change state to decreasing. */
					state = -1;
					/* Reset start location. */
					start = i;
				}
			}
		}
		/* Otherwise, items are level, so continue to next item pair. */
		/* Advance to next item pair in list. */
		i++;
	}
	/* Set results to output pointers. */
	*ominmax_val = minmax_val;
	*ominmax_type = minmax_type;
	*ominmax_i = minmax_i;
	*ominmax_alloc = minmax_alloc;
	*ominmax_num = minmax_num;

	/* Return normally. */
	return(0);
}

int allocate_contour(int **ocontour_x, int **ocontour_y,int **ocontour_ex, int **ocontour_ey, 
	const int ncontour)
{
		int *contour_x, *contour_y, *contour_ex, *contour_ey;

		/* Allocate contour's x-coord list. */
		contour_x = (int *)malloc(ncontour * sizeof(int));
		/* If allocation error... */
		if (contour_x == (int *)NULL)
		{
			return(-180);
		}

		/* Allocate contour's y-coord list. */
		contour_y = (int *)malloc(ncontour * sizeof(int));
		/* If allocation error... */
		if (contour_y == (int *)NULL) 
		{
			/* Deallocate memory allocated to this point in this routine. */
			free(contour_x);
			return(-181);
		}

		/* Allocate contour's edge x-coord list. */
		contour_ex = (int *)malloc(ncontour * sizeof(int));
		/* If allocation error... */
		if (contour_ex == (int *)NULL) 
		{
			/* Deallocate memory allocated to this point in this routine. */
			free(contour_x);
			free(contour_y);
			return(-182);
		}

		/* Allocate contour's edge y-coord list. */
		contour_ey = (int *)malloc(ncontour * sizeof(int));
		/* If allocation error... */
		if (contour_ey == (int *)NULL) 
		{
			/* Deallocate memory allocated to this point in this routine. */
			free(contour_x);
			free(contour_y);
			free(contour_ex);
			return(-183);
		}

		/* Otherwise, allocations successful, so assign output pointers. */
		*ocontour_x = contour_x;
		*ocontour_y = contour_y;
		*ocontour_ex = contour_ex;
		*ocontour_ey = contour_ey;

		/* Return normally. */
		return(0);
	}

void free_contour(int *contour_x, int *contour_y,int *contour_ex, int *contour_ey)
{
	free(contour_x);
	free(contour_y);
	free(contour_ex);
	free(contour_ey);
}



/***************************************************************************/
/*                         ��ϸ��ͼ���в���������                          */
/***************************************************************************/

//#ifndef PI
//#define PI 3.14159265f
//#endif // !PI

typedef enum { None, RidgeEnd, Bifurcation } MinutiaType;

typedef struct Point {
	int x;
	int y;
}Point;

typedef struct Minutia
{
	unsigned char Valid;
	unsigned char minutiaType;
	Point position;
	Point around[3];
}Minutia;

/******************************************���ܺ�������****************************************************/
/*n = 1 �����˵�λ��, n = 3 �������λ��*/
static void GetPointsWithNNeighbors(int n, unsigned char* image, binaryMap *innerMask,
	int width, int height, List* minutiae);

/*������x y Ϊ���ĵ�8������01ת���ĸ���*/
static int CountNeighbors(int x, int y, unsigned char* image, int width, int height);

/*�������pin��8�����в���ֵΪval�ĵ�,���Ϊpout*/
static int searchNeighbors(Point pin, unsigned char* image, int width, int height, unsigned char val, Point *pout);

/******************************************�ӿں���ʵ��*****************************************************/
void Hybrid_FindMinutiae(unsigned char *thin_img, binaryMap *Mask, int width, int height, void *feature)
{
	int deritionStep = 5;
	FEATURE *feat = (FEATURE *)feature;
	int ftNum = feat->MinutiaNum;
	List result = List_Construct();
	int dy = 0, dx = 0;

	GetPointsWithNNeighbors(1, thin_img, Mask, width, height, &result);
	GetPointsWithNNeighbors(3, thin_img, Mask, width, height, &result);

	for (ListElement * p = result.head; p != NULL; p = p->next)
	{
		Minutia * minutia;
		minutia = (Minutia *)p->data;
		//unsigned char maskval = Mask[minutia->position.x + minutia->position.y * width];

		if (minutia->minutiaType == RidgeEnd /*&& maskval == 255*/)
		{
			Point pout;
			Point pin = minutia->position;
			int stepNum = 0;
			thin_img[minutia->position.x + minutia->position.y * width] = 1;
			for (int i = 0; i < deritionStep; i++)
			{
				pout = pin;
				int ret = searchNeighbors(pin, thin_img, width, height, 0, &pout);
				stepNum += ret;
				pin = pout;
				thin_img[pin.x + pin.y * width] = 1;
			}

			if (stepNum >= 3 && ftNum < MAXMINUTIANUM)
			{
				minutia->around[0] = pin;
				feat->MinutiaArr[ftNum].x = minutia->position.x;
				feat->MinutiaArr[ftNum].y = minutia->position.y;
				//feat->MinutiaArr[ftNum].Type = minutia->minutiaType;
				dy = pin.y - minutia->position.y;
				dx = pin.x - minutia->position.x;
				if (dy + 128 < 0 || dy + 128 > 257 || dx + 128 < 0 || dx + 128 > 257) continue;
				feat->MinutiaArr[ftNum].Direction = search_atan_table(dy,dx);//atan_int_table_angle2[dy + 128][ dx + 128];
				ftNum++;
			}
			else
			{
				minutia->Valid = 0;
			}
		}
		else if (minutia->minutiaType == Bifurcation/* && maskval == 255*/)
		{
			thin_img[minutia->position.x + minutia->position.y * width] = 3;

			
			Point pin = minutia->position;
			Point pout = pin; 
			int ret = searchNeighbors(pin, thin_img, width, height, 0, &pout);
			thin_img[pout.x + pout.y * width] = 1;
			ret = searchNeighbors(pin, thin_img, width, height, 0, &pout);
			thin_img[pout.x + pout.y * width] = 2;
			ret = searchNeighbors(pin, thin_img, width, height, 0, &pout);
			thin_img[pout.x + pout.y * width] = 3;

			for (int m = 0; m < 3; m++)
			{
				pin = minutia->position;
				pout = pin;
				ret = searchNeighbors(pin, thin_img, width, height, m + 1, &pout);
				pin = pout;
				int stepNum = 0;

				for (int i = 0; i < deritionStep; i++)
				{
					pout = pin;
					ret = searchNeighbors(pin, thin_img, width, height, 0, &pout);
					stepNum += ret;
					pin = pout;
					thin_img[pin.x + pin.y * width] = m + 1;
				}
				if (stepNum >= 3)
				{
					minutia->around[m] = pin;
				}
				else
				{
					minutia->Valid = 0;
				}
			}

			if (minutia->Valid && ftNum < MAXMINUTIANUM)
			{
				feat->MinutiaArr[ftNum].x = minutia->position.x;
				feat->MinutiaArr[ftNum].y = minutia->position.y;
				//feat->MinutiaArr[ftNum].Type = minutia->minutiaType;

				Point p0 = minutia->around[0];
				Point p1 = minutia->around[1];
				Point p2 = minutia->around[2];
				Point pdir;

				int dist01 = (p0.x - p1.x)*(p0.x - p1.x) + (p0.y - p1.y)*(p0.y - p1.y);
				int dist12 = (p1.x - p2.x)*(p1.x - p2.x) + (p1.y - p2.y)*(p1.y - p2.y);
				int dist20 = (p2.x - p0.x)*(p2.x - p0.x) + (p2.y - p0.y)*(p2.y - p0.y);
				if (dist01 <= dist12 && dist01 <= dist20) pdir = p2;
				else if (dist12 <= dist01 && dist12 <= dist20) pdir = p0;
				else pdir = p1;

				dy = pdir.y - minutia->position.y;
				dx = pdir.x - minutia->position.x;
				if (dy + 128 < 0 || dy + 128 > 257 || dx + 128 < 0 || dx + 128 > 257) continue;
				feat->MinutiaArr[ftNum].Direction = search_atan_table(dy, dx); //atan_int_table_angle2[dy + 128][dx + 128];
				ftNum++;
			}
		}
	}
	feat->MinutiaNum = ftNum;
	List_Destruct(&result);
}

/******************************************���ܺ���ʵ��*****************************************************/
/*����ϸ�ڵ����� �˵�/���*/
static MinutiaType GetMinutiaType(int numberOfNeighbors) {
	switch (numberOfNeighbors) {
	case 1: return RidgeEnd;
	case 3: return Bifurcation;
	default: return None;
	}
}

/*����ϸ�ڵ�
@n [in] n = 1 �����˵�λ��, n = 3 �������λ��
@image [in] ϸ����ͼ��, 0 Ϊ�Ǽܲ���, 255Ϊ��������
@Mask [in]
@width [in]
@height [in]
@minutiae [in] �ҵ���ϸ�ڵ��б�
*/
void GetPointsWithNNeighbors(int n, unsigned char* image, binaryMap *Mask,
	int width, int height, List* minutiae)
{
	for (int i = 1; i < width - 1; i++)
	{
		for (int j = 1; j < height - 1; j++)
		{
			if (CountNeighbors(i, j, image, width, height) == n
				&& image[i + j * width] == 0
				&& binaryMap_GetBit(Mask,i,j))//Mask[i + j * width] == 255)
			{
				Minutia * minutia = malloc(sizeof(Minutia));
				minutia->Valid = 1;
				minutia->minutiaType = GetMinutiaType(n);
				minutia->position = (Point) { .x = i, .y = j };
				List_AddData(minutiae, minutia);
				//image[i + j * width] = n;
			}
		}
	}

}

/*
x y Ϊ���ĵ�8������01ת���ĸ���
@x y [in] 8������������
@image [in]
@width [in]
@height [in]
*/
int CountNeighbors(int x, int y, unsigned char* image, int width, int height)
{
	const int imageWidth = width;
	const int imageHeight = height;
	int acc = 0;
	unsigned char A1 = 0, A2 = 0, A3 = 0, A4 = 0, A5 = 0, A6 = 0, A7 = 0, A8 = 0;

	if (x > 0)								         A1 = image[x - 1 + y * width];
	if (x > 0 && y < imageHeight - 1)			     A2 = image[x - 1 + (y + 1) * width];
	if (y <  imageHeight - 1)                        A3 = image[x + (y + 1) * width];
	if (x < imageWidth - 1 && y < imageHeight - 1)   A4 = image[x + 1 + (y + 1) * width];
	if (x < imageWidth - 1)                          A5 = image[x + 1 + y * width];
	if (x < imageWidth - 1 && y > 0)                 A6 = image[x + 1 + (y - 1) * width];
	if (y > 0)                                       A7 = image[x + (y - 1) * width];
	if (x > 0 && y > 0)                              A8 = image[x - 1 + (y - 1) * width];

	acc = ((!A1) && A2) + ((!A2) && A3) + ((!A3) && A4) +
		((!A4) && A5) + ((!A5) && A6) + ((!A6) && A7) +
		((!A7) && A8) + ((!A8) && A1);

	return acc;
}

/*
��8�����в���ֵΪval�ĵ������,�ҵ���һ���󷵻�
@pin [in] 8������������
@image [in]
@width [in]
@height [in]
@val [in] Ҫ���ҵ�ֵ
@pout [out] �ҵ��ĵ�
@return �ҵ�����1,û�ҵ�����0
*/
int searchNeighbors(Point pin, unsigned char* image, int width, int height, unsigned char val, Point *pout)
{
	const int imageWidth = width;
	const int imageHeight = height;
	int x = pin.x;
	int y = pin.y;
	unsigned char A[8] = { 0,0,0,0,0,0,0,0 };
	Point psift[8];

	psift[0].x = psift[1].x = psift[7].x = -1;
	psift[3].x = psift[4].x = psift[5].x = 1;
	psift[2].x = psift[6].x = 0;
	psift[5].y = psift[6].y = psift[7].y = -1;
	psift[1].y = psift[2].y = psift[3].y = 1;
	psift[0].y = psift[4].y = 0;

	if (x > 0)								         A[0] = image[x - 1 + y * width];
	if (x > 0 && y < imageHeight - 1)			     A[1] = image[x - 1 + (y + 1) * width];
	if (y <  imageHeight - 1)                        A[2] = image[x + (y + 1) * width];
	if (x < imageWidth - 1 && y < imageHeight - 1)   A[3] = image[x + 1 + (y + 1) * width];
	if (x < imageWidth - 1)                          A[4] = image[x + 1 + y * width];
	if (x < imageWidth - 1 && y > 0)                 A[5] = image[x + 1 + (y - 1) * width];
	if (y > 0)                                       A[6] = image[x + (y - 1) * width];
	if (x > 0 && y > 0)                              A[7] = image[x - 1 + (y - 1) * width];

	for (int i = 0; i < 8; i++)
	{
		if (A[i] == val)
		{
			pout->x = x + psift[i].x;
			pout->y = y + psift[i].y;
			return 1;
		}
	}

	return 0;
}

/*	True if pixel neighbor map indicates the pixel is 8-simple and	*/
/*	not an end point and thus can be deleted.  The neighborhood	*/
/*	map is defined as an integer of bits abcdefghi with a non-zero	*/
/*	bit representing a non-zero pixel.  The bit assignment for the	*/
/*	neighborhood is:					*/
/*										  */
/*				a b c					*/
/*				d e f					*/
/*				g h i					*/
unsigned char	delet[512] = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 1, 0, 0, 1, 1, 0, 1, 1, 1, 0, 0, 1, 1,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	1, 0, 1, 1, 1, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 1, 1,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1 };

//thinning algorithm using Rosenfeld's parallel method
//输入输出:
//输入图像&输出结果: unsigned char* imageData
//宽度: int IMGW
//高度: int IMGH
//ref.[A Characterization of parallel thinning algorithm, Azriel Rosenfeld,1975]
int Hybrid_thinning(unsigned char *imageData, int IMGW, int IMGH)
{
	/* Direction masks:			*/
	/*   N	   S	 W     E	*/
	int	masks[] = { 0200, 0002, 0040, 0010 };
	
	int		xsize, ysize;	/* Image resolution		*/
	int		x, y;			/* Pixel location		*/
	int		i;				/* Pass index			*/
	int		pc = 0;			/* Pass count			*/
	int		count = 1;		/* Deleted pixel count	*/
	int		p, q;			/* Neighborhood maps of adjacent cells*/
	unsigned char	*qb;	/* Neighborhood maps of previous scanline*/
	int		m;				/* Deletion direction mask*/

	xsize = IMGW;
	ysize = IMGH;
	qb = (unsigned char *)malloc(xsize * sizeof(unsigned char));
	qb[xsize - 1] = 0;		/* Used for lower-right pixel*/
	int iterator = 0;

	while (count) {		/* Scan image while deletions*/
		pc++;
		iterator++;
		count = 0;
		if (pc >= xsize * ysize) break;
		if (iterator > 20) break;

		for (i = 0; i < 4; i++) {
			m = masks[i];

			/* Build initial previous scan buffer.*/
			p = imageData[0] != 255;
			for (x = 0; x < xsize - 1; x++)
				qb[x] = p = ((p << 1) & 0006) | (imageData[x + 1] != 255);

			/* Scan image for pixel deletion candidates.*/
			for (y = 0; y < ysize - 1; y++) {

				q = qb[0];
				p = ((q << 3) & 0110) | (imageData[(y + 1)*xsize] != 255);

				for (x = 0; x < xsize - 1; x++) {
					q = qb[x];
					p = ((p << 1) & 0666) | ((q << 3) & 0110) |
						(imageData[(y + 1)*xsize + x + 1] != 255);
					qb[x] = p;
					if (((p&m) == 0) && delet[p]) {
						count++;
						imageData[y*xsize + x] = 255;
					}
				}

				/* Process right edge pixel.*/
				p = (p << 1) & 0666;
				if ((p&m) == 0 && delet[p]) {
					count++;
					imageData[y*xsize + xsize - 1] = 255;
				}
			}

			/* Process bottom scan line.*/
			for (x = 0; x < xsize; x++) {
				q = qb[x];
				p = ((p << 1) & 0666) | ((q << 3) & 0110);
				if ((p&m) == 0 && delet[p]) {
					count++;
					imageData[(ysize - 1)*xsize + x] = 255;
				}
			}
		}
	}
	free(qb);
	return 0;
}

