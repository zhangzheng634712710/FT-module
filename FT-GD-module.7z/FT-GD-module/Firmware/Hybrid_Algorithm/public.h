#pragma once

#include <stdint.h>

#define min(a,b) (((a)<(b))?(a):(b))
#define max(a,b) (((a)>(b))?(a):(b))

#define PC_IMAGE_DEBUG         					0
#define TIME_COUNTER										1
#define WHOLE_TIME_COUNTER							0
#define IMAGE_MASK											1

typedef struct {
	uint8_t orgmean;
	uint32_t var;
	uint32_t coeff;
}NOMALIZE_PARA;	
	
typedef struct {
		uint32_t image_quality_test;
		uint32_t image_nomalize_test;
		uint32_t image_smooth_filter1;
		uint32_t image_smooth_filter2;
		uint32_t image_smooth_filter3;
		
		uint32_t hybrid_equalize;
		uint32_t hybird_get_mask;
		uint32_t hybird_nomalize;
		uint32_t hybird_smooth_filter;
	  uint32_t hybrid_getfeaturepoint_getort;
	  uint32_t hybrid_getfeaturepoint_binarize;
	  uint32_t hybrid_getfeaturepoint_erosion;
	  uint32_t hybrid_getfeaturepoint_firstthinning;
	  uint32_t hybrid_getfeaturepoint_firstfindminutiae;
	  uint32_t hybrid_getfeaturepoint_secondthinning;
	  uint32_t hybrid_getfeaturepoint_secondfindminutiae;
		uint32_t hybrid_gausssmooth;
		uint32_t others;
	  uint32_t wholetime;
	
		uint32_t first_get_feature;	
		uint32_t second_get_feature;
		uint32_t match ;	
}PROCESS_TIME;


#if PC_IMAGE_DEBUG
  #include "custom_hid_core.h"
	extern usbd_core_handle_struct  usb_device_dev ;
	extern NOMALIZE_PARA nomalize_para;	
#endif
	
#if TIME_COUNTER | WHOLE_TIME_COUNTER
  extern volatile uint32_t time;
	extern PROCESS_TIME process_time;
#endif
	

