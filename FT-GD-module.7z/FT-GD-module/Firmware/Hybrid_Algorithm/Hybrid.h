#pragma once

#define USE_FLOAT_DOUBLE 0

#include "type_def.h"
#include "binaryMap.h"

/**********************************************************************************
                                         整形运算
***********************************************************************************/

#define SAMPLE_POINT_NUM  3/*以细节点为中心的采样点数*/
#define NUM_IN_ONE_GROUP  4/*细节点加周围采样点的总点数*/

/*特征匹配参数*/
#define MAX_EU_DIST 900000  /*查找最近距离点时，两点距离最近且距离不大于此值*/
#define EU_DIST_THR 30000    /*2点不是最近点但距离小于此值，加入匹配对中*/
#define MINUTIA_MATCH_THR 2 /*2个特征点与其周围4个点共 5 vs 5的比对, 匹配数超过此阈值,两特征点才算匹配*/

#define USE_LOW_DIST 0

/*匹配特征对筛选参数*/
#define FILTER_FEATER_LINE_ERR 3          /*匹配点对连线长度差异小于此值*/
#define FILTER_FEATER_ANGLE_ERR 10        /*匹配对连线夹角差异小于此值*/
#define FILTER_FEATER_THR 20              /*筛选特征数大于此值，结束筛选*/
#define FILTER_FEATER_WRAP_MAX 12/10      /*防止旋转平移矩阵变形过大的门限上限 1.1*/
#define FILTER_FEATER_WRAP_MIN 8/10       /*防止旋转平移矩阵变形过大的门限上限 0.9*/
#define FILTER_FEATER_MATCH_DIST 3        /*变换后匹配的点距离必须小于此值*/
#define MOSAIC_THR 50                     /*两组特征match值大于此值才进行mosaic*/

extern int Hybrid_enroll_fp_int(unsigned char *imgdata, int width, int height,
	void *feat1, void *feat2, unsigned char *desc1[NUM_IN_ONE_GROUP], unsigned char *desc2[NUM_IN_ONE_GROUP]);

int Hybrid_save_tmp_to_file(char* fpath, void *feat1, void *feat2, unsigned char *desc1[NUM_IN_ONE_GROUP],
	unsigned char *desc2[NUM_IN_ONE_GROUP]);

int Hybrid_read_tmp_from_file(char* fpath, void *feat1, void *feat2, unsigned char *desc1[NUM_IN_ONE_GROUP],
	unsigned char *desc2[NUM_IN_ONE_GROUP]);

extern int Hybrid_match_fp_int(unsigned char *imgdata, int width, int height,
	void *feat11, void *feat12, unsigned char *desc11[NUM_IN_ONE_GROUP], unsigned char *desc12[NUM_IN_ONE_GROUP]);

extern int Hybrid_enroll_match_fp_int(unsigned char *imgdata1, int width1, int height1,
	unsigned char *imgdata2, int width2, int height2);

extern int Hybrid_match_desc_int(void *feat11, void *feat12, unsigned char *desc11[NUM_IN_ONE_GROUP], unsigned char *desc12[NUM_IN_ONE_GROUP],
	void *feat21, void *feat22, unsigned char *desc21[NUM_IN_ONE_GROUP], unsigned char *desc22[NUM_IN_ONE_GROUP],
	unsigned char* resultpair1, unsigned char* resultpair2, int *matchnum1, int *matchnum2,
	int iA[6], int *Det);

int Hybrid_match_desc_int_V2(void *feat11, void *feat12, unsigned char *desc11[NUM_IN_ONE_GROUP], unsigned char *desc12[NUM_IN_ONE_GROUP],
	void *feat21, void *feat22, unsigned char *desc21[NUM_IN_ONE_GROUP], unsigned char *desc22[NUM_IN_ONE_GROUP]);

int Hybrid_match_desc_int_2(void *feat11, void *feat12, unsigned char *desc11[NUM_IN_ONE_GROUP], unsigned char *desc12[NUM_IN_ONE_GROUP],
	void *feat21, void *feat22, unsigned char *desc21[NUM_IN_ONE_GROUP], unsigned char *desc22[NUM_IN_ONE_GROUP]);

int Hybrid_match_desc_int_3(void *feat11, void *feat12, unsigned char *desc11[NUM_IN_ONE_GROUP], unsigned char *desc12[NUM_IN_ONE_GROUP],
	void *feat21, void *feat22, unsigned char *desc21[NUM_IN_ONE_GROUP], unsigned char *desc22[NUM_IN_ONE_GROUP]);

int Hybrid_match_desc_int_4(void *feat11, void *feat12, unsigned char *desc11[NUM_IN_ONE_GROUP], unsigned char *desc12[NUM_IN_ONE_GROUP],
	void *feat21, void *feat22, unsigned char *desc21[NUM_IN_ONE_GROUP], unsigned char *desc22[NUM_IN_ONE_GROUP]);

extern void Hybrid_FindMinutiae(unsigned char *thin_img, binaryMap *Mask, int width, int height, void *feature);

extern int Hybrid_thinning(unsigned char *imageData, int IMGW, int IMGH);

extern void Hybrid_binarize(unsigned char *idata, int width, int height, unsigned char *direction_map, unsigned char *bdata);

extern int Hybrid_FindMinutiae_bin(unsigned char *bin_img, unsigned char *direction_map, int width, int height, void *feature, int if_recaldir);

extern int Hybrid_mosaic(void *baseft1, void *baseft2, unsigned char *basedesc1[NUM_IN_ONE_GROUP], unsigned char *basedesc2[NUM_IN_ONE_GROUP],
	void *addft1, void *addft2, unsigned char *adddesc1[NUM_IN_ONE_GROUP], unsigned char *adddesc2[NUM_IN_ONE_GROUP]);

int INT_GaussSmooth(unsigned char *pUnchImg, unsigned char *pUnchSmthdImg, int nWidth, int nHeight);

int Hybrid_filter_feat_int(void *match_kp, int pair_num, int A[6], int *oDet, int* resultPair);

int Hybrid_filter_feat_int_fast(void *match_kpi, int pair_num, int A[6], int *oDet, int* resultPair);

