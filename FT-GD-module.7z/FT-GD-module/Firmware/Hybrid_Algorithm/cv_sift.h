#pragma once

#define descriptorSize 8

// default width of descriptor histogram array
#define SIFT_DESCR_WIDTH 1

// default number of bins per histogram in descriptor array
#define SIFT_DESCR_HIST_BINS  8

// assumed gaussian blur for input image
#define SIFT_INIT_SIGMA  0.5f

// width of border in which to ignore keypoints
#define SIFT_IMG_BORDER  5

// maximum steps of keypoint interpolation before failure
#define SIFT_MAX_INTERP_STEPS  5

// default number of bins in histogram for orientation assignment
#define SIFT_ORI_HIST_BINS  36

// determines gaussian sigma for orientation assignment
#define SIFT_ORI_SIG_FCTR  1.5f

// determines the radius of the region used in orientation assignment
#define SIFT_ORI_RADIUS  3 * SIFT_ORI_SIG_FCTR

// orientation magnitude relative to max that results in new feature
#define SIFT_ORI_PEAK_RATIO  0.8f

// determines the size of a single descriptor orientation histogram
#define SIFT_DESCR_SCL_FCTR  3.f

// threshold on magnitude of elements of descriptor vector
#define SIFT_DESCR_MAG_THR  0.2f

// factor used to convert floating-point descriptor to unsigned char
#define SIFT_INT_DESCR_FCTR  512.f

#define FLT_EPSILON      1.192092896e-07F        // smallest such that 1.0+FLT_EPSILON != 1.0

#ifndef PI
#define PI   3.14159265f
#endif
/* threshold on squared ratio of distances between NN and 2nd NN */
#define NN_SQ_DIST_RATIO_THR 0.6   //0.49 Խ��Խ��

/*����ƥ���ŷ�Ͼ���С�ڴ�ֵ �� ��Сֵ��Сֵ��С��NN_SQ_DIST_RATIO_THR*/
#define MATCH_POINT_DIST_THR 5000

typedef struct KeyPoint_
{
	float x;
	float y;
	float size;
	float angle; /*[0~360]*/
	float response;
	int octave;
	int class_id;
}KeyPoint;

typedef struct SIFT_DET_
{
	double contrastThreshold;
	double edgeThreshold;
	double sigma;
	int nfeatures;
	int nOctaveLayers;
}SIFT_DET;


/*����keypoint��ȡsift������*/
int SIFT_DescriptorExtractor(SIFT_DET* self,unsigned char* image, unsigned char* mask,int w,int h, KeyPoint* keypoints,int keypoint_num,float* desc);

