#pragma once

#define USE_FLOAT_DOUBLE_ 0

#define descriptorSize 8

#define descriptorSize_int 8 /*������ά��*/

// default width of descriptor histogram array
#define SIFT_DESCR_WIDTH_INT 1 /*ֵ�޸�ʱҪͬʱ�޸�W_table���ֵ*/

// default number of bins per histogram in descriptor array
#define SIFT_DESCR_HIST_BINS_INT  8

#define NORMALIZE_MAX 16 /*��� / NORMALIZE_MAX*/

#define SIFT_DESCR_SCL_FCTR_INT  3

#define SIFT_DESCR_MAG_THR_INT  1/5

// factor used to convert floating-point descriptor to unsigned char
#define SIFT_INT_DESCR_FCTR_INT  512

#define BINS_PER_RAD   SIFT_DESCR_HIST_BINS_INT/360
#define EXP_SCALE      (-2)/(SIFT_DESCR_WIDTH_INT*SIFT_DESCR_WIDTH_INT)
/*sigma 4.8 �� SIFT_SIZE = 4.8 ��Ӧ��hist_width �� radius �Ĵ�С */
/*sigma ֵ�޸�ʱҪͬʱ�޸����ǵ�ֵ�Լ� W_table���ֵ*/
#define HIST_WIDTH     5 / 36 // 1/7.2 = 5/36 /*3 * SIFT_SIZE / 2,SIFT_SIZE = 4.8*/
#define RADIUS_SCAL    10     /* hist_width * 1.4142135623730951f = 10*/


// default number of bins in histogram for orientation assignment
#define SIFT_ORI_HIST_BINS  36

#if USE_FLOAT_DOUBLE_
typedef struct KeyPoint_int
{
	int x;
	int y;
	int Direction;     /*[0~360]*/
	int Type;
}KeyPoint_int;
#else
typedef struct KeyPoint_int
{
	short x;
	short y;
	short Direction;     /*[0~360]*/
}KeyPoint_int;
#endif

/*����keypoint��ȡsift������*/
int SIFT_DescriptorExtractor_int(unsigned char* image,int w, int h, KeyPoint_int* keypoints, int keypoint_num, unsigned char* desc);

/*�Ƕ�����,��������Ҷ�����ϸ�ڵ�Ƕ�*/
int Adjust_Angle(unsigned char* img, int w, int h, int ptx, int pty, int ori);
