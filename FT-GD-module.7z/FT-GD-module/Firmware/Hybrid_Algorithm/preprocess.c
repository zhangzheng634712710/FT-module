#include "preprocess.h"
#include "table_int.h"
#include <stdio.h>
#include <stdlib.h>
#include "string.h"
#include "math.h"
#include "public.h"
#include "myFPA.h"

#include "custom_hid_core.h"

const unsigned short g_p_off_11x11[121] = {
	0   , 1   , 2   , 3   , 4   , 5   , 6   , 7   , 8   , 9   , 10  ,
	192 , 193 , 194 , 195 , 196 , 197 , 198 , 199 , 200 , 201 , 202 ,
	384 , 385 , 386 , 387 , 388 , 389 , 390 , 391 , 392 , 393 , 394 ,
  576 , 577 , 578 , 579 , 580 , 581 , 582 , 583 , 584 , 585 , 586 ,
  768 , 769 , 770 , 771 , 772 , 773 , 774 , 775 , 776 , 777 , 778 ,
  960 , 961 , 962 , 963 , 964 , 965 , 966 , 967 , 968 , 969 , 970 ,
  1152, 1153, 1154, 1155, 1156, 1157, 1158, 1159, 1160, 1161, 1162,
  1344,	1345, 1346, 1347, 1348, 1349, 1350, 1351, 1352, 1353, 1354,
	1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544, 1545, 1546,
	1728, 1729, 1730, 1731, 1732, 1733, 1734, 1735, 1736, 1737, 1738,
	1920, 1921, 1922, 1923, 1924, 1925, 1926, 1927, 1928, 1929, 1930,
};

const unsigned short g_p_off_9x9[9] = {
	   0,  192,  384,  576,  768,  960, 1152, 1344, 1536
};

const unsigned short g_p_off_9x9_5x5[25] = {
  0   , 2   , 4   , 6   , 8   ,  
  384 , 386 , 388 , 390 , 392 , 
  768 , 770 , 772 , 774 , 776 ,  
  1152, 1154, 1156, 1158, 1160, 
  1536, 1538, 1540, 1542, 1544, 
};
const unsigned short g_p_off_4x4[16] = {
  0   , 1   , 2   , 3   ,
  192 , 193 , 194 , 195 ,
  384 , 385 , 386 , 387 , 
  576 , 577 , 578 , 579 , 
};
const signed int g_p_l_9[9] = {
	-1, 191, 383, 575, 767, 959, 1151, 1343, 1535,
};
const signed int g_p_r_9[9] = {
	8, 200, 392, 584, 776, 968, 1160, 1352, 1544,
};
const signed int g_p_u_9[9] = {
	-192, -191, -190, -189, -188, -187, -186, -185, -184,
};
const signed int g_p_d_9[9] = {
	1536, 1537, 1538, 1539, 1540, 1541, 1542, 1543, 1544,
};
//7*7分成8个方向，坐标在左上
const unsigned short  g_D_778[8][7] = {
  576 , 577 , 578 , 579 , 580 , 581 , 582 ,
  960 ,	769 , 770 , 579 , 388 , 389 , 198 ,
  1152, 961 , 770 , 579 , 388 , 197 , 6   ,
  1153, 962 , 770 , 579 , 388 , 196 , 5   ,
  3   , 195 , 387 , 579 , 771 , 963 , 1155,
  1   , 194 , 386 , 579 , 772 , 964 , 1157,
  0   , 193 , 386 , 579 , 772 , 965 , 1158,
  192 , 385 , 386 , 579 , 772 , 773 , 966
};

//牛顿迭代开平方根
static int SqrtNiudun(unsigned int intx)
{
	int pre = 1;
	int tempz = 1;
	unsigned char flag = 0;
	while (abs(tempz - pre) > 1 || flag == 0)
	{
		flag = 1;
		pre = tempz;
		tempz = (pre + intx / pre) / 2;
	}
	return tempz;
}

//改进的灰度均衡
//输入参数：
//	输入图像 unsigned char* lpInBuffer
//	图像宽度int IMGW
//	图像高度int IMGH
//输出参数：
//	输出图像 unsigned char* lpOutBuffer
//备注:
//  ref.[改进的直方图均衡算法.Network information technique,2006,vol.25,no.7]
static int ImproveEqualize(unsigned char *lpInBuffer, unsigned char *lpOutBuffer, int IMGW, int IMGH)
{
	// 指向源图像的指针
	unsigned char*	lpSrc = NULL;
	unsigned char*	lpRst = NULL;
	int dataLen = IMGH * IMGW;
	// 临时变量
	int	i = 0;
	int	j = 0;
	// 灰度直方图
	int	lHist[256] = { 0 };
	int sumHist = 0;
	//直方图指数平滑参数
	int a = 4;
	int b = 6;
	int c = a + b;
	//灰度间距均匀处理参数
	int validN = 0;
	int upRate = 0;
	int lowRate = 0;

	// 重置计数为0
	memset(lHist,0,256*sizeof(int));

	// 统计灰度分布
	lpSrc = lpInBuffer;
	for (int i = 0; i < dataLen; i++)
	{
		lHist[*(lpSrc)]++;
		lpSrc++;
	}

	//直方图指数平滑，pixel的总的数量会发生变化，另外平滑的参数的选择的依据是什么？
	sumHist = lHist[0];
	for (i = 1; i < 256; i++)
	{
		lHist[i] = (a*lHist[i] + b * lHist[i - 1]) / c;
		sumHist += lHist[i];
	}
	
	//均衡--概率密度函数
	//lHist[0] = lHist[0]/sumHist;
	for (i = 1; i < 256; i++)
	{
		//lHist[i] = lHist[i]/sumHist;
		lHist[i] = lHist[i] + lHist[i - 1];      //求直方图累计分布
	}
	
	//取0.05~0.95部分
	lowRate = 2; //0%
	upRate = 90; //99%
	for (i = 0; i < 256; i++)
	{
		int ratec = 100 * lHist[i] / sumHist;    //求小于等于当前灰度值的pixel的数量占整体数量的百分比
		if (ratec < lowRate)
		{
			lHist[i] = 0;
		}
		else if (ratec >= upRate)
		{
			lHist[i] = sumHist;
		}		
		else
		{
			//lHist[i] = sumHist * ((100 * lHist[i] / sumHist) - lowRate)/(upRate - lowRate)/100; //(lHist[i]-0.1)/(0.9 - 0.1)
			lHist[i] = (100 * lHist[i] - lowRate * sumHist) / (upRate - lowRate);
		}
	}
	
  // 直方图均衡
	lpSrc = lpInBuffer;
	lpRst = lpOutBuffer;
	for (int i = 0; i < dataLen; i++)
	{
		*(lpRst) = lHist[*(lpSrc)] * 255 / sumHist;
		lpSrc++;
		lpRst++;
	}

	//直方图灰度间距均匀处理
	// 重新计算各个灰度值的计数得到直方图
	memset(lHist,0,256*sizeof(int));

	lpRst = lpOutBuffer;
	for (int i = 0; i < dataLen; i++)
	{
		lHist[*(lpRst)]++;
		lpRst++;
	}
  // 计算数量不为0的灰度的级数
	validN = 0;
	for (i = 0; i < 256; i++)
	{
		if (lHist[i] != 0)
		{
			lHist[i] = validN;
			validN++;
		}
	}
  // 将数量不为0的灰度均匀的分布在整个灰度范围内
	for (i = 0; i < 256; i++)
	{
		lHist[i] = lHist[i] * 255 / validN;
	}

	lpRst = lpOutBuffer;
	for (int i = 0; i < dataLen; i++)
	{
		*(lpRst) = lHist[*(lpRst)];
		lpRst++;
	}
	
	return 0;
}

//中值滤波器
//输入参数：
//	输入图像 unsigned char* lpInBuffer
//	图像宽度int IMGW
//	图像高度int IMGH
//  窗口大小winSize
//输出参数：
//	输出图像 unsigned char* lpOutBuffer
//备注:
//static int MediaFilter(unsigned char *lpInBuffer, unsigned char *lpOutBuffer, int IMGW, int IMGH, int winSize)
//{
//	int index = 0;
//	int r = winSize >> 1;
//	int windatalen = winSize * winSize;
//	int half_windatalen = (winSize * winSize) >> 1;
//	int tmpval = 0;
//	unsigned char *lpCenter = NULL;
//	int offset = 0;
//	int *g_p_off_3 = (int*)malloc(windatalen * sizeof(int));
//	int *tmp = (int*)malloc(windatalen * sizeof(int));
//	if(g_p_off_3 == NULL) 
//		return -1;
//	if(tmp == NULL) 
//	{
//		free(g_p_off_3);
//		return -1;
//	}
//	// 计算相对位置
//	index = 0;
//	for (int m = -r; m <= r; m++)
//	{
//		for (int n = -r; n <= r; n++)
//		{
//			g_p_off_3[index++] = m * IMGW + n;
//		}
//	}
//  // 填充整张图像到输出buffer，其实是为了填充边缘的位置，中间的位置在后面会被更改
//	memcpy(lpOutBuffer,lpInBuffer,IMGW*IMGH);
//	
//	for (int i = r; i < IMGH-r; i++)
//	{
//		for (int j = r; j< IMGW-r; j++)
//		{
//			index = 0;
//			offset = i * IMGW + j;
//			lpCenter = lpInBuffer + offset;
//			
//			for (int n = 0; n <= windatalen; n++)
//			{
//				tmp[index++] = *(lpCenter + g_p_off_3[n]);
//			}

//			for (int m = 0; m <= half_windatalen; m++)             // 取中间值
//			{
//				for (int n = m + 1; n < windatalen; n++)
//				{
//					if (tmp[m] > tmp[n])
//					{
//						tmpval = tmp[n];
//						tmp[n] = tmp[m];
//						tmp[m] = tmpval;
//					}
//				}
//			}
//			
//			*(lpOutBuffer + offset) = tmp[half_windatalen];
//		}
//	}

//	free(tmp);
//	free(g_p_off_3);
//	return 0;
//}
static int MediaFilter(unsigned char *lpInBuffer, unsigned char *lpOutBuffer, int IMGW, int IMGH, int winSize)
{
	int index = 0;
	int r = winSize >> 1;
	int windatalen = winSize * winSize;
	int half_windatalen = (winSize * winSize) >> 1;
	int tmpval = 0;
	unsigned char *lpCenter = NULL;
	int *tmp = (int*)malloc(winSize*winSize * sizeof(int));
	if(tmp == NULL) 
		return -1;
	memset(tmp, 0, winSize*winSize * sizeof(int));

	for (int i = 0; i < IMGH; i++)
	{
		for (int j = 0; j< IMGW; j++)
		{

			index = 0;
			
			lpCenter = lpInBuffer + i * IMGW + j;

			if (i - r < 0 || i + r >= IMGH || j - r <0 || j + r >= IMGW)
			{
				*(lpOutBuffer + i * IMGW + j) = *lpCenter;
				continue;
			}
			
			for (int m = -r; m <= r; m++)
			{
				for (int n = -r; n <= r; n++)
				{
					tmp[index++] = *(lpCenter + m * IMGW + n);
				}
			}

			for (int m = 0; m <= half_windatalen; m++)             // 取中间值
			{
				for (int n = m + 1; n < windatalen; n++)
				{
					if (tmp[m] > tmp[n])
					{
						tmpval = tmp[n];
						tmp[n] = tmp[m];
						tmp[m] = tmpval;
					}
				}
			}
			*(lpOutBuffer + i * IMGW + j) = tmp[winSize*winSize / 2];
		}
	}

	free(tmp);
	return 0;
}


//动态灰度均衡，将图片分为几个区域，分别调用改进的灰度均衡算法
//输入参数：
//	输入图像 unsigned char* lpInBuffer
//	图像宽度int IMGW
//	图像高度int IMGH
//输出参数：
//	输出图像 unsigned char* lpOutBuffer
//备注:
int Hybrid_DynamicEqualize(unsigned char *lpInBuffer, unsigned char *lpOutBuffer, int IMGW, int IMGH)
{
//	unsigned char *tmpBuffer = (unsigned char*)malloc(IMGW*IMGH * sizeof(unsigned char));
//	if (tmpBuffer == NULL) 
//		return -1;
//	memset(tmpBuffer, 0, IMGW*IMGH * sizeof(unsigned char));

	ImproveEqualize(lpInBuffer, lpOutBuffer, IMGW, IMGH);

//	MediaFilter(tmpBuffer, lpOutBuffer, IMGW, IMGH, 3);

//	free(tmpBuffer);

	return 0;
}

//从方差和均值计算MASK
//unsigned char *pInput 输入图像
//unsigned char *pMask  mask
//int IMGW             
//int IMGH
//unsigned char tM      均值门限
//unsigned char tsigma  标准差门限
//int w                 格子大小  固定为4,192/4=48,为整数，不用判断边界
int Hybrid_GetMask(unsigned char *pInput, unsigned char *pMask, int IMGW, int IMGH, unsigned char tM, unsigned char tstd)
{
	int w = 4;
	int nWGrid = 0, nHGrid = 0;
	int x, y;

	memset(pMask, 0, IMGW*IMGH * sizeof(unsigned char));

	int mean = 0;
	int std = 0;
	int c = w*w;
	int k = 0;

	
	unsigned char *src = NULL;
	unsigned char *temp = NULL;
	
	for (y = 0; y < IMGH; y+=w)
	{
		for (x = 0; x < IMGW; x+=w)
		{
			mean = 0;
			src = temp = pInput + (y * IMGW + x);  // 确定原始图像数组中起始点的位置
			for (k = 0; k < w; k++)
			{
				mean += *temp;
				mean += *(temp+1);
				mean += *(temp+2);
				mean += *(temp+3);
				temp += IMGW; 
			}
			mean /= c;
			
			if(mean > tM) continue;

			std = 0;	
			temp = src;
			for (k = 0; k < w; k++)
			{
				std += ((*temp) - mean)*((*temp) - mean);
				std += ((*temp+1) - mean)*((*temp+1) - mean);
				std += ((*temp+2) - mean)*((*temp+2) - mean);
				std += ((*temp+3) - mean)*((*temp+3) - mean);
				temp += IMGW;
			}		
			std = SqrtNiudun(std / c);

			if (std >= tstd)
			{
				temp = pMask + (y * IMGW + x);  // 确定mask数组中起始点的位置
				for (k = 0; k < w; k++)
				{
					*temp = 255;
					*(temp+1) = 255;
					*(temp+2) = 255;
					*(temp+3) = 255;
					temp += IMGW;                       
				}				
			}
			
		}
	}
	return 1;
}

//int Hybrid_GetMask(unsigned char *pInput, unsigned char *pMask, int IMGW, int IMGH, unsigned char tM, unsigned char tstd, int w)
//{
//	int nWGrid = 0, nHGrid = 0;
//	int x, y;
//	if (IMGW % w == 0)
//		nWGrid = IMGW / w;
//	else
//		nWGrid = IMGW / w + 1;
//	
//	if (IMGH % w == 0)
//		nHGrid = IMGH / w;
//	else
//		nHGrid = IMGH / w + 1;

//	memset(pMask, 0, IMGW*IMGH * sizeof(unsigned char));

//	int mean = 0;
//	int std = 0;
//	int c = 0;
//	int j, i;
//	int yy, xx;
//	for (y = 0; y < nHGrid; y++)
//	{
//		for (x = 0; x < nWGrid; x++)
//		{
//			c = 0;
//			mean = 0;
//			for (j = 0; j < w; j++)
//			{
//				for (i = 0; i < w; i++)
//				{
//					yy = y * w + j;
//					xx = x * w + i;
//					if (yy < IMGH && xx < IMGW)
//					{
//						mean += pInput[yy*IMGW + xx];
//						c++;
//					}
//				}
//			}
//			mean /= c;

//			c = 0;
//			std = 0;
//			for (j = 0; j < w; j++)
//			{
//				for (i = 0; i < w; i++)
//				{
//					yy = y * w + j;
//					xx = x * w + i;
//					if (yy < IMGH && xx < IMGW)
//					{
//						std += (pInput[yy*IMGW + xx] - mean)*(pInput[yy*IMGW + xx] - mean);
//						c++;
//					}
//				}
//			}
//			std = SqrtNiudun(std / c);

//			if (std >= tstd && mean <= tM)
//			{
//				for (j = 0; j < w; j++)
//				{
//					for (i = 0; i < w; i++)
//					{
//						yy = y * w + j;
//						xx = x * w + i;
//						if (yy < IMGH && xx < IMGW)
//						{
//							pMask[yy * IMGW + xx] = 255;
//						}
//					}
//				}
//			}
//		}
//	}
//	return 1;
//}

//求图像方向场
//输入参数：
//	输入图像 unsigned char* lpTemp
//	图像宽度int IMGW
//	图像高度int IMGH
//	求导窗半径long r
//  滤波器大小int nFilterSize
//输出参数：
//	输出方向场图像 unsigned char* lpOrient 
//备注：
//  输出的大小为 (Size :IMGW*IMGH) 返回的方向为角度(0~180)
void Hybrid_GetOrt(unsigned char* lpTemp, unsigned char* lpOrient, binaryMap* lpMask, int IMGW, int IMGH, int r, int nFilterSize, int nBlockSize)
{
	int  x, y, i, j;
	int  vx, vy, lvx, lvy, tmplvx,tmplvy;
	unsigned char *lpSrc = NULL;
	int	angle;
	//int fAngle;
	int nx = 0;
	int ny = 0;
	int idx = 0;
	int *pPhix = NULL;
	int *pPhiy = NULL;
	int *pFilter = NULL;
	int fltLen = 0;
	int BlockH = IMGH / nBlockSize;
	int BlockW = IMGW / nBlockSize;
	int FilterSum = 0;

	memset(lpOrient, 255, IMGW*IMGH);

	for (y = 0; y < IMGH; y = y + nBlockSize)
	{
		for (x = 0; x < IMGW; x = x + nBlockSize)
		{
			if (binaryMap_GetBit(lpMask,x,y))
			{
        //求x y方向偏导数和，根据偏大求方向角
				lvx = 0; lvy = 0;
				for (i = -r; i <= r; i+=2)	                          // 纵向8*2+1=17个点的宽度                              
				{
					if (y + i < 1 || y + i >= IMGH - 1)
					{
						continue;
					}
					tmplvx = tmplvy = 0;
					for (j = -r; j <= r; j+=2)	                        // 横向8*2+1=17个点的宽度   
					{
						if (x + j < 1 || x + j >= IMGW - 1)
						{
							continue;
						}
						lpSrc = lpTemp + (y + i)*IMGW + x + j;
						//3*3的sobel算子求偏导
						//sobel算子[-1 0 1; -2 0 2; -1 0 1]
						//求x方向偏导
						vx = *(lpSrc + IMGW + 1) - *(lpSrc + IMGW - 1) +
							   *(lpSrc + 1) * 2    - *(lpSrc - 1) * 2 +
							   *(lpSrc - IMGW + 1) - *(lpSrc - IMGW - 1);
						//求y方向偏导
						vy = *(lpSrc + IMGW - 1) - *(lpSrc - IMGW - 1) +          // 在某一个点的周围17*17的方框内求每一点 x、y方向上的偏导
							   *(lpSrc + IMGW) * 2 - *(lpSrc - IMGW) * 2 +
							   *(lpSrc + IMGW + 1) - *(lpSrc - IMGW + 1);

						tmplvx += vx * vy * 2;           //sin(2sita)
						tmplvy += (vx * vx - vy * vy);   //cos(2sita)     
					}
					lvx += tmplvx >> 5; /*防止值过大溢出*/
					lvy += tmplvy >> 5; /*防止值过大溢出*/
				}
				lvx >>= 7; /*防止值过大溢出*/
				lvy >>= 7; /*防止值过大溢出*/ 

				angle = atan_Angle(lvy, lvx);
				angle >>= 1; //2sita --> sita
				// 因为采用sobel算子，所以角度偏转了度，所以要旋转求得的角度
				angle -= 135;
				// 角度变换到（0-180）
				if (angle < 0) angle += 180;

//				lpSrc = lpOrient + (y + i)*IMGW + x + j;				
				for (i = 0; i < nBlockSize; i++)
				{
					for (j = 0; j < nBlockSize; j++)
					{
						if (y + i < IMGH && x + i < IMGW)
						{
							*(lpOrient + (y + i) * IMGW + x + j) = (unsigned char)angle;
						}
					}
//					*lpSrc = (unsigned char)angle;
//					*(lpSrc+1) = (unsigned char)angle;
//					*(lpSrc+2) = (unsigned char)angle;
//					*(lpSrc+3) = (unsigned char)angle;
//					lpSrc += IMGW;
				}
			}
		}
	}
}
//void Hybrid_GetOrt(unsigned char* lpTemp, unsigned char* lpOrient, binaryMap* lpMask, int IMGW, int IMGH, int r, int nFilterSize, int nBlockSize)
//{
//	int  x, y, i, j;
//	int  vx, vy, lvx, lvy, tmplvx,tmplvy;
//	unsigned char   *lpSrc = NULL;
//	int	angle;
//	//int fAngle;
//	int nx = 0;
//	int ny = 0;
//	int idx = 0;
//	int *pPhix = NULL;
//	int *pPhiy = NULL;
//	int *pFilter = NULL;
//	int fltLen = 0;
//	int BlockH = IMGH / nBlockSize;
//	int BlockW = IMGW / nBlockSize;
//	int FilterSum = 0;
////生成一个加权的低通滤波器数组
////数组大小(nFilterSize*2+1)*(nFilterSize*2+1)
//	memset(lpOrient, 255, IMGW*IMGH);
////	if (nFilterSize>0)
////	{
////		fltLen = nFilterSize * 2 + 1;

////		pPhix = (int*)malloc(BlockH * BlockW * sizeof(int));
////		if (pPhix == NULL) 
////			return;
////		pPhiy = (int*)malloc(BlockH * BlockW * sizeof(int));
////		if (pPhiy == NULL)
////		{
////			free(pPhix);
////			return;
////		}
////		pFilter = (int*)malloc(fltLen*fltLen * sizeof(int));
////		if (pFilter == NULL)
////		{
////			free(pPhix);
////			free(pPhiy);
////			return;
////		}
////		memset(pPhix, 0, BlockH * BlockW * sizeof(int));
////		memset(pPhiy, 0, BlockH * BlockW * sizeof(int));
////		memset(pFilter, 0, fltLen*fltLen * sizeof(int));
////		nx = 0;
////		for (j = 0; j<fltLen; j++)
////		{
////			for (i = 0; i<fltLen; i++)
////			{
////				pFilter[j*fltLen + i] = fltLen - (abs(nFilterSize - i) + abs(nFilterSize - j));
////				FilterSum += pFilter[j*fltLen + i];
////			}
////		}
////	}
//	for (y = 0; y < IMGH; y = y + nBlockSize)
//	{
//		for (x = 0; x < IMGW; x = x + nBlockSize)
//		{
//			//if (binaryMap_GetBit(lpMask,x,y))
//			{
//        //求x y方向偏导数和，根据偏大求方向角
//				lvx = 0; lvy = 0;
//				for (i = -r; i <= r; i++)	// 
//				{
//					if (y + i < 1 || y + i >= IMGH - 1)
//					{
//						continue;
//					}
//					tmplvx = tmplvy = 0;
//					for (j = -r; j <= r; j++)	//
//					{
//						if (x + j < 1 || x + j >= IMGW - 1)
//						{
//							continue;
//						}
//						lpSrc = lpTemp + (y + i)*IMGW + x + j;
//						//3*3的sobel算子求偏导
//						//sobel算子[-1 0 1; -2 0 2; -1 0 1]
//						//求x方向偏导
//						vx = *(lpSrc + IMGW + 1) - *(lpSrc + IMGW - 1) +
//							*(lpSrc + 1) * 2 - *(lpSrc - 1) * 2 +
//							*(lpSrc - IMGW + 1) - *(lpSrc - IMGW - 1);
//						//求y方向偏导
//						vy = *(lpSrc + IMGW - 1) - *(lpSrc - IMGW - 1) +
//							*(lpSrc + IMGW) * 2 - *(lpSrc - IMGW) * 2 +
//							*(lpSrc + IMGW + 1) - *(lpSrc - IMGW + 1);

//						tmplvx += vx * vy * 2;           //sin(2sita)
//						tmplvy += (vx * vx - vy * vy);   //cos(2sita)
//					}
//					lvx += tmplvx >> 5; /*防止值过大溢出*/
//					lvy += tmplvy >> 5; /*防止值过大溢出*/
//				}
//				lvx >>= 7; /*防止值过大溢出*/
//				lvy >>= 7; /*防止值过大溢出*/
//				//if (nFilterSize == 0)
//				{
//					angle = atan_Angle(lvy, lvx);
//					angle >>= 1; //2sita --> sita
//					// 因为采用sobel算子，所以角度偏转了度，所以要旋转求得的角度
//					angle -= 135;
//					// 角度变换到（0-180）
//					if (angle < 0) angle += 180;

//					for (i = 0; i < nBlockSize; i++)
//					{
//						for (j = 0; j < nBlockSize; j++)
//						{
//							if (y + i < IMGH && x + i < IMGW)
//							{
//								*(lpOrient + (y + i) * IMGW + x + j) = (unsigned char)angle;
//							}
//						}
//					}
//				}
////				else
////				{
////					idx = x / nBlockSize + y / nBlockSize * BlockW;
////					pPhix[idx] = lvx;
////					pPhiy[idx] = lvy;
////				}
//			}
//		}
//	}
////	if (nFilterSize>0)
////	{
////		// 低通滤波后再求方向角
////		for (y = 0; y<IMGH; y = y + nBlockSize)
////		{
////			for (x = 0; x<IMGW; x = x + nBlockSize)
////			{
////				if (binaryMap_GetBit(lpMask, x, y))
////				{  
////					nx = 0;
////					ny = 0;
////					//滤波
////					for (j = -nFilterSize; j <= nFilterSize; j++)
////					{
////						if (j*nBlockSize + y < 0 || j * nBlockSize + y >= IMGH)
////						{
////							continue;
////						}
////						for (i = -nFilterSize; i <= nFilterSize; i++)
////						{
////							if (x + i * nBlockSize < 0 || x + i * nBlockSize >= IMGW)
////							{
////								continue;
////							}
////							idx = (x / nBlockSize + i) + (j + y / nBlockSize)*BlockW;
////							nx += pFilter[(j + nFilterSize)*fltLen + i + nFilterSize] * pPhix[idx];
////							ny += pFilter[(j + nFilterSize)*fltLen + i + nFilterSize] * pPhiy[idx];
////						}
////					}
////					nx /= FilterSum;
////					ny /= FilterSum;

////					angle = atan_Angle(ny, nx);
////					angle >>= 1; //2sita --> sita
////					// 因为采用sobel算子，所以角度偏转了度，所以要旋转求得的角度
////					angle -= 135;
////					// 角度变换到（0-180）
////					if (angle < 0) angle += 180;

////					for (i = 0; i < nBlockSize; i++)
////					{
////						for (j = 0; j < nBlockSize; j++)
////						{
////							if (y + i < IMGH && x + i < IMGW)
////							{
////								*(lpOrient + (y + i) * IMGW + x + j) = (unsigned char)angle;
////							}
////						}
////					}
////				}
////			}
////		}
////		if (pPhix != NULL)
////		{
////			free(pPhix);
////		}
////		if (pPhiy != NULL)
////		{
////			free(pPhiy);
////		}
////		if (pFilter != NULL)
////		{
////			free(pFilter);
////		}
////	}
//}

//判断图片质量,同时返回图片的信息
int ImageQuality(unsigned char* image, unsigned short height, unsigned short width, unsigned char *reVal)
{
	signed short i = 0, j = 0, k = 0;

	unsigned char* lpSrc = NULL;
	
	unsigned char nblk = 4;
	
	unsigned int mean[8] = { 0 };                //存储7*7矩阵中八条线的灰度平均值
	unsigned int var[8]  = { 0 };                //存储7*7矩阵中八条线的灰度方差 
	
	unsigned int varmax = 0, varmin = 0, meanmax = 0 ;// meanmin = 0;

	unsigned int varRange = 0, RangeCnt = 0;
	unsigned int count = 0;
	unsigned int AreaRatio = 0;

	if((!image)||(!reVal)) return Param_error;
	
	#if TIME_COUNTER
		time = 0;
	#endif
	
	for (j = 0; j < height-nblk; j = j + nblk)
	{
		for (i = 0; i < width-nblk; i = i + nblk)
		{
			lpSrc = image + (j*width) + i;
			for (k = 0; k < 8; k++)
			{
				mean[k] = 0;
				var[k] = 0;
				mean[k] += *(lpSrc+g_D_778[k][0]);
				mean[k] += *(lpSrc+g_D_778[k][1]);
				mean[k] += *(lpSrc+g_D_778[k][2]);
				mean[k] += *(lpSrc+g_D_778[k][3]);
				mean[k] += *(lpSrc+g_D_778[k][4]);
				mean[k] += *(lpSrc+g_D_778[k][5]);
				mean[k] += *(lpSrc+g_D_778[k][6]);
				mean[k] = mean[k] / 7;                                                                       //求像素点在7x7的矩阵内的八个方向上各自的均值 （注意起始点的位置）

				var[k] += ((*(lpSrc+g_D_778[k][0]))-mean[k]) * ((*(lpSrc+g_D_778[k][0]))-mean[k]);
				var[k] += ((*(lpSrc+g_D_778[k][1]))-mean[k]) * ((*(lpSrc+g_D_778[k][1]))-mean[k]);
				var[k] += ((*(lpSrc+g_D_778[k][2]))-mean[k]) * ((*(lpSrc+g_D_778[k][2]))-mean[k]);
				var[k] += ((*(lpSrc+g_D_778[k][3]))-mean[k]) * ((*(lpSrc+g_D_778[k][3]))-mean[k]);
				var[k] += ((*(lpSrc+g_D_778[k][4]))-mean[k]) * ((*(lpSrc+g_D_778[k][5]))-mean[k]);
				var[k] += ((*(lpSrc+g_D_778[k][5]))-mean[k]) * ((*(lpSrc+g_D_778[k][5]))-mean[k]);
				var[k] += ((*(lpSrc+g_D_778[k][6]))-mean[k]) * ((*(lpSrc+g_D_778[k][6]))-mean[k]);
				var[k] = var[k] / 7;                                                                         //求像素点在7x7的矩阵内的八个方向上各自的方差 （注意起始点的位置）
			}
			varmax = var[0];
			varmin = var[0];
			meanmax = mean[0]; 
//			meanmin = mean[0];
			
			for (k = 1; k < 8; k++)
			{
				if (var[k] > varmax)
					varmax = var[k];
				if (var[k] < varmin)
					varmin = var[k];
				if (mean[k] > meanmax)
					meanmax = mean[k];
//				if (mean[k] < meanmin)
//					meanmin = mean[k];
			}                                                                                                  //求像素点在7x7的矩阵内的八个方向上最大及最小的均值和方差 （注意起始点的位置）

			if (meanmax < 252 || varmax - varmin > 2)
			{
				varRange = varRange + varmax - varmin;
				RangeCnt++;
				count+=16;
			}
		}		
	}

	AreaRatio = count * 100 / (height*width);                                                                   //求面积比
	varRange = varRange / RangeCnt;                                                                           //求所有点最大方差和最小方差的平均值                                                                                                       //求直方图中点数最多的灰度值

	reVal[1] = AreaRatio;  //面积比例
//	reVal[2] = varRange;   //方向场方差范围，清晰程度

	if ((AreaRatio < AreaTH)||(varRange < DirVarTh))
	{
		reVal[0] = 0xff;
	}
	else
	{
		reVal[0] = 0x01;
	}
	
	#if TIME_COUNTER
		process_time.image_quality_test = time;
	#endif
	
	return Func_success;
}

//归一化到指定的均值方差范围内
//输入参数：
//	输入图像 unsigned char* origindata
//输出参数：
//	输出图像 unsigned char* origindata  归一化图像数据(直接在原图像上做修改）
//备注:
int Hybrid_ImageNormalize(unsigned char *origindata, unsigned short height, unsigned short width)
{
	// 临时变量
	unsigned short i = 0, j = 0;
	
	unsigned char orgMean = 0;
	signed int    val = 0;
	
	unsigned int coeff = 0;
	
	unsigned int count = 0;

	// 灰度映射表
	unsigned short lCount[256] = { 0 };

	// 图像归一后的均值和方差
	unsigned char destMean = 128;                                        //输出图像每一个pixel为8个bit，灰度范围为0到255，要将图像的均值归一到中值128，
	unsigned int  destVar = 10000;                                       //方差归一到10000（经验值）
	
	signed short temp = 0;
	
	if(!origindata) return Param_error;
	
	#if TIME_COUNTER
		time = 0;
	#endif	

	// 重置计数为0
	memset(lCount,0,256*sizeof(unsigned short));

	// 计算各个灰度值的数量
	i = height * width;
	for (j = 0; j < i; j++)
	{
		(lCount[(*(origindata+j))])++;
	}                                                                  //求直方图lCount[256]

	val = 0;count = 0;
	// 当前图像均值orgMean
	for (i = 0; i<252; i++)
	{
		val += i * lCount[i];
		count += lCount[i];
	}
	val = val / count;
	orgMean = (unsigned char)val;                                                               //求图像均值

	// 当前图像标准差orgSigma
	val = 0;
	for (i = 0; i<252; i++)
	{
		val += lCount[i] * (i - orgMean)*(i - orgMean);
	}
	val = val / count;                                                             							//求图像的方差                                                                         

	coeff = (signed int)sqrt(destVar / val);                                                           //为什么要用(destVar / val)？  //将图像扩展到方差为destVar的范围
	
	if(coeff<2)
		coeff = 2;                          // coeff = 0 图片会变成纯色
																				// coeff = 1 图片会在原来的灰度基础上整体做偏移
	                                      // 要有归一的效果，coeff至少要大于等于2

	i = height * width;
	for (j = 0; j < i; j++)
	{
		if((*(origindata+j))<252)
		{
			temp = destMean + coeff * ((*(origindata+j)) - orgMean);
			if(temp<0)
				*(origindata+j) = 0;
			else if(temp>255)
				*(origindata+j) = 255;
			else
				*(origindata+j) = (unsigned char)temp;                                       //扩大图像的细节？在destMean上下浮动？
		}
		else
		{
				*(origindata+j) = 255;
		}
	}
	
	#if TIME_COUNTER
		process_time.image_nomalize_test = time;	
	#endif	
	
	#if PC_IMAGE_DEBUG
		nomalize_para.orgmean = orgMean;
		nomalize_para.var = val;
		nomalize_para.coeff = coeff;
	#endif
	
	return Func_success;
}

/*************************************************************************************/
//均值滤波 逐点均衡化 得到高频信息图//
//输入参数：
//	输入图像   unsigned char *guiyihuaBmp 归一化图像数据
//  滤波器大小 unsigned int varfilter
//输出参数：
//	输出图像   unsigned char *guiyihuaBmp 均衡化图像数据(直接在原图上做修改)
int Hybrid_SmoothFilter(unsigned char *guiyihuaBmp, unsigned short height, unsigned short width, unsigned int varfilter)
{
	signed int i = 0;
	signed int j = 0;
	signed int ii = 0;
	unsigned int tpnum = varfilter*varfilter;
	unsigned int sum = 0;
	unsigned int sum_temp = 0;
	int min_value = 0;
	int value_num = 0;
	int temp = 0;
	int historam_num = 0;
	unsigned char *pOutput=NULL;
	unsigned char *pSrc = NULL;	
	unsigned char *pDes = NULL;
	unsigned char *temp_p = NULL;
	unsigned short tempaver = 0;

	if(!guiyihuaBmp) return Param_error;
	
	#if TIME_COUNTER
		time = 0;
	#endif	
	
	pOutput = (unsigned char *)malloc(height*width);
	if(!pOutput)
	{
		return Malloc_failed;
	}
	memset(pOutput,255,height*width);
	
	pSrc = guiyihuaBmp;	
	pDes = pOutput+ ((4 * width) + 4);
	
	// 计算第一个方框的值
	sum_temp = 0;
	
	for(i=0;i<varfilter;i++)
	{
		  temp_p = guiyihuaBmp+g_p_off_9x9[i];

			sum_temp += *(temp_p);
			sum_temp += *(temp_p+1);
			sum_temp += *(temp_p+2);
			sum_temp += *(temp_p+3);
			sum_temp += *(temp_p+4);
			sum_temp += *(temp_p+5);
			sum_temp += *(temp_p+6);
			sum_temp += *(temp_p+7);	
			sum_temp += *(temp_p+8);			
	}
	sum = sum_temp;	
	(*pDes) = (sum_temp + (tpnum >> 1)) / tpnum;
	pSrc++;	
	pDes++;

	// 计算第一行所有方框的值，并求均值
	for(j=1;j<width-varfilter;j++)
	{
		sum_temp += *(pSrc+g_p_r_9[0]);
		sum_temp += *(pSrc+g_p_r_9[1]);
		sum_temp += *(pSrc+g_p_r_9[2]);
		sum_temp += *(pSrc+g_p_r_9[3]);
		sum_temp += *(pSrc+g_p_r_9[4]);
		sum_temp += *(pSrc+g_p_r_9[5]);
		sum_temp += *(pSrc+g_p_r_9[6]);
		sum_temp += *(pSrc+g_p_r_9[7]);
		sum_temp += *(pSrc+g_p_r_9[8]);
		
		sum_temp -= *(pSrc+g_p_l_9[0]);
		sum_temp -= *(pSrc+g_p_l_9[1]);
		sum_temp -= *(pSrc+g_p_l_9[2]);
		sum_temp -= *(pSrc+g_p_l_9[3]);
		sum_temp -= *(pSrc+g_p_l_9[4]);
		sum_temp -= *(pSrc+g_p_l_9[5]);
		sum_temp -= *(pSrc+g_p_l_9[6]);
		sum_temp -= *(pSrc+g_p_l_9[7]);
		sum_temp -= *(pSrc+g_p_l_9[8]);

		(*pDes) = (sum_temp + (tpnum >> 1)) / tpnum;
		pSrc++;	
		pDes++;
	}
	
	// 计算第二行以后所有方框的值，并求均值
	for (i = 1; i < height-varfilter; i++)
	{
		// 将指针更新到guiyihuaBmp图像和pOutput图像每一行的起点
		pSrc += varfilter;
		pDes += varfilter;
		
		// 利用上一行第一个方框的和求取本行第一个方框的和及均值
		sum += *(pSrc+g_p_d_9[0]);
		sum += *(pSrc+g_p_d_9[1]);
		sum += *(pSrc+g_p_d_9[2]);
		sum += *(pSrc+g_p_d_9[3]);
		sum += *(pSrc+g_p_d_9[4]);
		sum += *(pSrc+g_p_d_9[5]);
		sum += *(pSrc+g_p_d_9[6]);
		sum += *(pSrc+g_p_d_9[7]);
		sum += *(pSrc+g_p_d_9[8]);
		
		sum -= *(pSrc+g_p_u_9[0]);
		sum -= *(pSrc+g_p_u_9[1]);
		sum -= *(pSrc+g_p_u_9[2]);
		sum -= *(pSrc+g_p_u_9[3]);
		sum -= *(pSrc+g_p_u_9[4]);
		sum -= *(pSrc+g_p_u_9[5]);
		sum -= *(pSrc+g_p_u_9[6]);
		sum -= *(pSrc+g_p_u_9[7]);
		sum -= *(pSrc+g_p_u_9[8]);
		
		sum_temp = sum;	
		(*pDes) = (sum_temp + (tpnum >> 1)) / tpnum;
		pSrc++;	
		pDes++;
		
		// 计算本行剩余所有方框的值，并求均值
		for (j = 1; j < width-varfilter; j++)
		{
			sum_temp += *(pSrc+g_p_r_9[0]);
			sum_temp += *(pSrc+g_p_r_9[1]);
			sum_temp += *(pSrc+g_p_r_9[2]);
			sum_temp += *(pSrc+g_p_r_9[3]);
			sum_temp += *(pSrc+g_p_r_9[4]);
			sum_temp += *(pSrc+g_p_r_9[5]);
			sum_temp += *(pSrc+g_p_r_9[6]);
			sum_temp += *(pSrc+g_p_r_9[7]);
			sum_temp += *(pSrc+g_p_r_9[8]);
			
			sum_temp -= *(pSrc+g_p_l_9[0]);
			sum_temp -= *(pSrc+g_p_l_9[1]);
			sum_temp -= *(pSrc+g_p_l_9[2]);
			sum_temp -= *(pSrc+g_p_l_9[3]);
			sum_temp -= *(pSrc+g_p_l_9[4]);
			sum_temp -= *(pSrc+g_p_l_9[5]);
			sum_temp -= *(pSrc+g_p_l_9[6]);
			sum_temp -= *(pSrc+g_p_l_9[7]);
			sum_temp -= *(pSrc+g_p_l_9[8]);

			(*pDes) = (sum_temp + (tpnum >> 1)) / tpnum;
			pSrc++;	
			pDes++;			
		}
	}
	
	#if TIME_COUNTER
		process_time.image_smooth_filter1 = time;	
	#endif
	
//	#if PC_IMAGE_DEBUG
//		custom_hid_report_recive(&usb_device_dev);
//		custom_hid_report_send(&usb_device_dev, pOutput, 192*192);
//		custom_hid_report_recive(&usb_device_dev);
//	#endif	

	#if TIME_COUNTER
		time = 0;
	#endif	
	
	//求取最小值
	min_value = 255;
	i = height*width;
	for (j = 0; j < i; j++)
	{
		  temp = (signed int)(*(guiyihuaBmp+j)) - (signed int)(*(pOutput+j)) ;
			if(temp < min_value)
				min_value = temp;
	}
	for (j = 0; j < i; j++)
	{
		temp = (((signed int)(*(guiyihuaBmp+j)) - (signed int)(*(pOutput+j))) - min_value);
		//所有的数据调整到0以上
		if(temp>255) 
			*(pOutput + j) = 255;
		else
		  *(pOutput + j) = (unsigned char)temp;
	}

	#if TIME_COUNTER
		process_time.image_smooth_filter2 = time;
	#endif
	
//	#if PC_IMAGE_DEBUG
//		custom_hid_report_recive(&usb_device_dev);
//		custom_hid_report_send(&usb_device_dev, pOutput, 192*192);
//		custom_hid_report_recive(&usb_device_dev);
//	#endif		
	
	#if TIME_COUNTER
		time = 0;
	#endif	

	//逐点均衡化//
	value_num = varfilter * varfilter;
	temp = (varfilter/2)*width + (varfilter/2);
	
	pSrc = pOutput;	
	pDes = guiyihuaBmp+ ((4 * width) + 4);
	
	memset(guiyihuaBmp,255,height*width);
	
	for (i = 0; i < height-varfilter; i++)
	{
		for (j = 0; j < width-varfilter; j++)
		{
			tempaver = *(pSrc+temp);
			historam_num = 0;
			
			for (ii = 0; ii < 9; ii++)
			{
				temp_p = pSrc+g_p_off_9x9[ii];
//				historam_num += ((tempaver - (*temp_p))>>31);
//				historam_num += ((tempaver - (*(temp_p+1)))>>31);
//				historam_num += ((tempaver - (*(temp_p+2)))>>31);
//				historam_num += ((tempaver - (*(temp_p+3)))>>31);
//				historam_num += ((tempaver - (*(temp_p+4)))>>31);
//				historam_num += ((tempaver - (*(temp_p+5)))>>31);
//				historam_num += ((tempaver - (*(temp_p+6)))>>31);
//				historam_num += ((tempaver - (*(temp_p+7)))>>31);
//				historam_num += ((tempaver - (*(temp_p+8)))>>31);
				if (*temp_p <= tempaver) historam_num++;
				if (*(temp_p+1) <= tempaver) historam_num++;				
				if (*(temp_p+2) <= tempaver) historam_num++;				
				if (*(temp_p+3) <= tempaver) historam_num++;				
				if (*(temp_p+4) <= tempaver) historam_num++;				
				if (*(temp_p+5) <= tempaver) historam_num++;				
				if (*(temp_p+6) <= tempaver) historam_num++;				
				if (*(temp_p+7) <= tempaver) historam_num++;
				if (*(temp_p+8) <= tempaver) historam_num++;
			}	
//			for (ii = 0; ii < value_num; ii++)
//			{
//				if (*(pSrc+g_p_off_9x9[ii]) <= tempaver)
//				{
//					historam_num++;
//				}
//			}                                                                              //统计9x9的方框中比某像素点灰度值低的点的数量
			*pDes = (historam_num * 255 + (value_num >> 1)) / value_num ;
			pSrc++;
			pDes++;
		}
		pSrc += varfilter;
		pDes += varfilter;
	}
	
	#if TIME_COUNTER
		process_time.image_smooth_filter3 = time;
	#endif	
	
	free(pOutput);
	return Func_success;
}

