#pragma once
#include "binaryMap.h"

#define Func_success         1
#define Image_quality_low	  -2
#define Malloc_failed		    -3
#define Param_error         -4 

int Hybrid_DynamicEqualize(unsigned char *lpInBuffer, unsigned char *lpOutBuffer, int IMGW, int IMGH);

int Hybrid_GetMask(unsigned char *pInput, unsigned char *pMask, int IMGW, int IMGH, unsigned char tM, 
	unsigned char tstd);//, int w

void Hybrid_GetOrt(unsigned char* lpTemp, unsigned char* lpOrient, binaryMap* lpMask, int IMGW,
	int IMGH, int r, int nFilterSize, int nBlockSize);

int ImageQuality(unsigned char* image, unsigned short height, unsigned short width, unsigned char *reVal);

int Hybrid_ImageNormalize(unsigned char *origindata, unsigned short height, unsigned short width);
	
int Hybrid_SmoothFilter(unsigned char *guiyihuaBmp, unsigned short height, unsigned short width, unsigned int varfilter);
