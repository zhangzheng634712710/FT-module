#ifndef TABLE_INT_H_
#define TABLE_INT_H_

extern const int squaredec_table[1025];
extern const int sin_int_table[361];
extern const int cos_int_table[361];
extern const unsigned char atan_int_table_angle[129][129];
extern const unsigned char matan1[131];
extern const unsigned char matan2[159];
extern const unsigned char matan3[218];
extern const unsigned short square_root_table_short_8[192][192];
extern const int W_table_int[129][129];

#define SIN_COS_SCAL_BIT 14    //sin cos 扩大2^14, 化为整形
#define W_SCAL_BIT 10          //w 扩大2^10, 化为整形

/*atan2f查表atan_int_table_angle[i][j] = atan2f(i,j) * 180 / PI, i,j ( 0 ~ 128)*/
int search_atan_table(int y, int x);

/*用下面3个表格计算反tan函数*/
int atan_Angle(int y, int x);

#endif
