#ifndef TABLE_DEF_H_
#define TABLE_DEF_H_

#define USE_FLOAT_DOUBLE_ 0

#if USE_FLOAT_DOUBLE_

#define     MAXMINUTIANUM			200			// 最大特征点数
typedef struct tagMinutiae {
	int    x;				// 横坐标
	int    y;				// 纵坐标
	int    Direction;		// 方向
	int    Type;		    // 类型
} MINUTIA, *MINUTIAPTR;

// 指纹特征(模板)结构
typedef struct tagFeature {
	int		    MinutiaNum;					    // 特征点数
	MINUTIA		MinutiaArr[MAXMINUTIANUM];	// 特征点数组V
} FEATURE, *FEATUREPTR;
#else

#define  MAXMINUTIANUM	50	// 最大特征点数
typedef struct tagMinutiae {
	short      x;				// 横坐标
	short      y;				// 纵坐标
	short      Direction;		// 方向
	//int  Type;            // 类型
} MINUTIA, *MINUTIAPTR;

// 指纹特征(模板)结构
typedef struct tagFeature {
	unsigned char	        MinutiaNum;		// 特征点数
	MINUTIA		            MinutiaArr[MAXMINUTIANUM];	// 特征点数组
} FEATURE, *FEATUREPTR;

#endif

#endif
