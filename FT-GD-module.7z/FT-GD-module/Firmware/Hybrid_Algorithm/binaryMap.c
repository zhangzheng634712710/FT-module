#include "binaryMap.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "public.h"

#define WORD_WIDTH 8
#define WORD_WIDTH_BIT 3
#define WORD_WIDTH_1 7 // 8 - 1 = 7

binaryMap binaryMap_Construct(int width, int height)
{
	binaryMap me;
	int datalen = 0;
	me.width = width;
	me.height = height;
	me.wordWidth = WORD_WIDTH;
	if ((width % me.wordWidth) == 0)
	{
		me.LineSift = width / me.wordWidth;
	}
	else
	{
		me.LineSift = 1 + width / me.wordWidth;
	}
	datalen = me.LineSift * height * sizeof(unsigned char);
	me.bindata = (unsigned char*)malloc(datalen);
	memset(me.bindata, 0, datalen);
	return me;
}

void binaryMap_Destruct(binaryMap *me)
{
	free(me->bindata);
}

int binaryMap_GetBit(const binaryMap *me, int x, int y)
{
	int x_word_num = x >> WORD_WIDTH_BIT;
	int x_bit_num = x & WORD_WIDTH_1;  /*x % me->wordWidth*/
	unsigned char word_data = *(me->bindata + y * me->LineSift + x_word_num);
	word_data &= 1 << x_bit_num;
	if (word_data) return 1;
	return 0;
}

void binaryMap_SetBit(const binaryMap *me, int x, int y, int val)
{
	int x_word_num = x >> WORD_WIDTH_BIT;
	int x_bit_num = x & WORD_WIDTH_1;  /*x % me->wordWidth*/
	unsigned char *word_data = me->bindata + y * me->LineSift + x_word_num;
	if (val)
	{
		*word_data |= (1 << x_bit_num);
	}
	else 
	{
		*word_data &= (~(1 << x_bit_num));
	}
}

void binaryMap_CopyData(binaryMap *src, binaryMap *dst)
{
	if (src->width != dst->width || src->height != dst->height) return;

	int datalen = src->LineSift * src->height * sizeof(unsigned char);
	memcpy(dst->bindata, src->bindata, datalen);
}

