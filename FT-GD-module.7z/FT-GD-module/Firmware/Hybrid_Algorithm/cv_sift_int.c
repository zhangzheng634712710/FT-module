#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "table_int.h"
#include "cv_sift_int.h"
#include "public.h"

static void calcSIFTDescriptor_int(unsigned char* img, int w, int h, int ptxf, int ptyf, int ori, int d, int n, unsigned char* dst);

//ţ�ٵ�����ƽ����
static int SqrtNiudun(unsigned int intx)
{
	int pre = 1;
	int tempz = 1;
	unsigned char flag = 0;
	while (abs(tempz - pre) > 1 || flag == 0)
	{
		flag = 1;
		pre = tempz;
		tempz = (pre + intx / pre) / 2;
	}
	return tempz;
}

/*����keypoint��ȡsift������*/
int SIFT_DescriptorExtractor_int(unsigned char* image, int w, int h, KeyPoint_int* keypoints, int keypoint_num, unsigned char* desc)
{
	if (NULL == image || NULL == desc) return -1;

	int dsize = descriptorSize_int;

	int d = SIFT_DESCR_WIDTH_INT, n = SIFT_DESCR_HIST_BINS_INT;

	for (int i = 0; i < keypoint_num; i++)
	{
		KeyPoint_int kpt = keypoints[i];

		int ptxf = kpt.x;
		int ptyf = kpt.y;
		int angle = 360 - kpt.Direction;
	
		calcSIFTDescriptor_int(image, w, h, ptxf, ptyf, angle,d, n, (desc + i * dsize));
	}

	return 0;
}


void calcSIFTDescriptor_int(unsigned char* img, int w, int h, int ptxf, int ptyf, int ori, int d, int n, unsigned char* dst)
{
	int ptx = ptxf;
	int pty = ptyf;

	int cos_t = cos_int_table[ori]; //cosf(ori * PI / 180.f);/*���*/
	int sin_t = sin_int_table[ori]; //sinf(ori * PI / 180.f);/*���*/
	//float bins_per_rad = n / 360.f;
//	int hist_width = HIST_WIDTH;
	//int radius = (int)(hist_width * 1.4142135623730951f * (d + 1) * 0.5f + 0.5f);
	int radius = (RADIUS_SCAL * (d + 1) + 1) / 2;
	radius = min(radius, SqrtNiudun(w*w + h * h));
	cos_t = cos_t* HIST_WIDTH;
	sin_t = sin_t* HIST_WIDTH;

	int i, j, k, len = (radius * 2 + 1)*(radius * 2 + 1), histlen = (d + 2) * (d + 2) * (n + 2);
	int rows = h, cols = w;

	int *buf = (int*)malloc((len * 6 + histlen) * sizeof(int));
	int *X = buf, *Y = X + len, *Mag = Y, *Ori = Mag + len, *W = Ori + len;
	int *RBin = W + len, *CBin = RBin + len, *hist = CBin + len;

	memset(hist, 0, (d + 2) * (d + 2) * (n + 2) * sizeof(int));

	int int_scal = 128;   /*Ϊ���������㣬��ֵ�Ŵ�128��*/
	int int_scal_bit = 7; /*128 = 2^7*/
	int min_rbin_cbin = (-1 << int_scal_bit);          /*ֵ�Ŵ�*/
	int max_rbin_cbin = (d << int_scal_bit);           /*ֵ�Ŵ�*/
	int HALF_SIN_COS_SCAL_BIT = SIN_COS_SCAL_BIT - 1;  /*sin cos �Ŵ�����һ��*/
	int d_half_scal_bit = d << HALF_SIN_COS_SCAL_BIT;  /*ֵ�Ŵ�*/
	int one_half_scal_bit = 1 << HALF_SIN_COS_SCAL_BIT;/*���Ŵ�*/
	int SIN_COS_SCAL_BIT_int_scal_bit = SIN_COS_SCAL_BIT - int_scal_bit;

	for (i = -radius, k = 0; i <= radius; i++)
	{
		for (j = -radius; j <= radius; j++)
		{
			int c_rot = (j * cos_t - i * sin_t);
			int r_rot = (j * sin_t + i * cos_t);
			int rbin = (r_rot + d_half_scal_bit - one_half_scal_bit) >> SIN_COS_SCAL_BIT_int_scal_bit;
			int cbin = (c_rot + d_half_scal_bit - one_half_scal_bit) >> SIN_COS_SCAL_BIT_int_scal_bit;
			int r = pty + i, c = ptx + j;

			if (rbin > min_rbin_cbin && rbin < max_rbin_cbin && cbin > min_rbin_cbin && cbin < max_rbin_cbin &&
				r > 0 && r < rows - 1 && c > 0 && c < cols - 1)
			{
				int dx = img[r * cols + c + 1] - img[r * cols + c - 1];
				int dy = img[(r - 1) * cols + c] - img[(r + 1) * cols + c];
				X[k] = dx; Y[k] = dy; RBin[k] = rbin; CBin[k] = cbin;

				W[k] = W_table_int[i + 64][j + 64]; /*(c_rot * c_rot + r_rot * r_rot)*exp_scale;*//*���*/
				Ori[k] = search_atan_table((dy+1)>>1,(dx+1)>>1);//atan_int_table_angle2[(dy + 256 + 1) >> 1][(dx + 256 + 1) >> 1];/*���*/
				Mag[k] = square_root_table_short_8[abs(dx)][abs(dy)] >>3;/*���*/
				k++;
			}
		}
	}
	len = k;

	int int_scal_1 = int_scal - 1;
	for (k = 0; k < len; k++)
	{
		int rbin = RBin[k], cbin = CBin[k];
		int obin = ((Ori[k] - ori)<<int_scal_bit)*BINS_PER_RAD;
		int mag = Mag[k] * W[k];

		//int r0 = (int)floor(rbin / int_scal);
		//int c0 = (int)floor(cbin / int_scal);
		//int o0 = (int)floor(obin / int_scal);
		/*�����int_scal ������λ��������,����λ����СֵΪ-1,��������0*/
		int r0 = rbin / int_scal;
		if(rbin < 0)
		{
			int r1 = rbin & int_scal_1;
			if (r1 != 0) r0 -= 1;
		}
		int c0 = cbin / int_scal;
		if (cbin < 0)
		{
			int c1 = cbin & int_scal_1;
			if (c1 != 0) c0 -= 1;
		}

		int o0 = obin / int_scal;
		if (obin < 0)
		{
			int o1 = obin & int_scal_1;
			if (o1 != 0) o0 -= 1;
		}
	
		rbin -= (r0 << int_scal_bit);
		cbin -= (c0 << int_scal_bit);
		obin -= (o0 << int_scal_bit);

		if (o0 < 0) o0 += n;
		else if (o0 >= n) o0 -= n;

		// histogram update using tri-linear interpolation
		//float v_r1 = mag * rbin, v_r0 = mag - v_r1;
		//float v_rc11 = v_r1 * cbin, v_rc10 = v_r1 - v_rc11;
		//float v_rc01 = v_r0 * cbin, v_rc00 = v_r0 - v_rc01;
		//float v_rco111 = v_rc11 * obin, v_rco110 = v_rc11 - v_rco111;
		//float v_rco101 = v_rc10 * obin, v_rco100 = v_rc10 - v_rco101;
		//float v_rco011 = v_rc01 * obin, v_rco010 = v_rc01 - v_rco011;
		//float v_rco001 = v_rc00 * obin, v_rco000 = v_rc00 - v_rco001;

		//int v_rco000 = ((mag * (int_scal - rbin)/ int_scal)*(int_scal - cbin)/ int_scal)*(int_scal - obin)/ int_scal;
		// >> int_scal_bit ��С128��,��ֵֹ�������
		int v_rco000 = (mag * (int_scal - rbin)) >> int_scal_bit;
		v_rco000 = (v_rco000 * (int_scal - cbin)) >> int_scal_bit;
		v_rco000 = (v_rco000 * (int_scal - obin)) >> int_scal_bit;
		//int v_rco001 = ((mag * (int_scal - rbin)/ int_scal)*(int_scal - cbin)/ int_scal)*obin/ int_scal;
		int v_rco001 = (mag * (int_scal - rbin)) >> int_scal_bit;
		v_rco001 = (v_rco001 *(int_scal - cbin)) >> int_scal_bit;
		v_rco001 = (v_rco001 * obin) >> int_scal_bit;
		//int v_rco010 = ((mag * (int_scal - rbin)/ int_scal)*cbin/ int_scal)*(int_scal - obin)/ int_scal;
		int v_rco010 = (mag * (int_scal - rbin)) >> int_scal_bit;
		v_rco010 = (v_rco010 * cbin) >> int_scal_bit;
		v_rco010 = (v_rco010 * (int_scal - obin)) >> int_scal_bit;
		//int v_rco011 = ((mag * (int_scal - rbin)/ int_scal)*cbin/ int_scal)*obin/ int_scal;
		int v_rco011 = (mag * (int_scal - rbin)) >> int_scal_bit;
		v_rco011 = (v_rco011 * cbin) >> int_scal_bit;
		v_rco011 = (v_rco011 * obin) >> int_scal_bit;
		//int v_rco100 = ((mag * rbin/ int_scal)*(int_scal - cbin)/ int_scal)*(int_scal - obin)/ int_scal;
		int v_rco100 = (mag * rbin) >> int_scal_bit;
		v_rco100 = (v_rco100 * (int_scal - cbin)) >> int_scal_bit;
		v_rco100 = (v_rco100 * (int_scal - obin)) >> int_scal_bit;
		//int v_rco101 = ((mag * rbin/ int_scal)*(int_scal - cbin)/ int_scal)*obin/ int_scal;
		int v_rco101 = (mag * rbin) >> int_scal_bit;
		v_rco101 = (v_rco101 * (int_scal - cbin)) >> int_scal_bit;
		v_rco101 = (v_rco101 *obin) >> int_scal_bit;
		//int v_rco110 = ((mag * rbin/ int_scal)*cbin/ int_scal)*(int_scal - obin)/ int_scal;
		int v_rco110 = (mag * rbin) >> int_scal_bit;
		v_rco110 = (v_rco110 * cbin) >> int_scal_bit;
		v_rco110 = (v_rco110 * (int_scal - obin)) >> int_scal_bit;
		//int v_rco111 = ((mag * rbin/ int_scal)*cbin/ int_scal)*obin/ int_scal;
		int v_rco111 = (mag * rbin) >> int_scal_bit;
		v_rco111 = (v_rco111 * cbin) >> int_scal_bit;
		v_rco111 = (v_rco111 * obin) >> int_scal_bit;

		int idx = ((r0 + 1)*(d + 2) + c0 + 1)*(n + 2) + o0;
		// >> 4 ��С16��,��ֵֹ�������
		hist[idx] += (v_rco000 >> 4);
		hist[idx + 1] += (v_rco001 >> 4);
		hist[idx + (n + 2)] += (v_rco010 >> 4);
		hist[idx + (n + 3)] += (v_rco011 >> 4);
		hist[idx + (d + 2)*(n + 2)] += (v_rco100 >> 4);
		hist[idx + (d + 2)*(n + 2) + 1] += (v_rco101 >> 4);
		hist[idx + (d + 3)*(n + 2)] += (v_rco110 >> 4);
		hist[idx + (d + 3)*(n + 2) + 1] += (v_rco111 >> 4);
	}

	int tmpret[128] = { 0 };
	
	for (i = 0; i < d; i++)
	{
		for (j = 0; j < d; j++)
		{
			int idx = ((i + 1)*(d + 2) + (j + 1))*(n + 2);
			hist[idx] += hist[idx + n];
			hist[idx + 1] += hist[idx + n + 1];
			//for (k = 0; k < n; k++) /*n = 8, k = 0~7,��ѭ��չ��*/
			//	dst[(i*d + j)*n + k] = hist[idx + k];
			// >> 4 ��С64��,��ֹ��������ֵ�������
			tmpret[(i*d + j)*n + 0] = hist[idx + 0] >> 8;
			tmpret[(i*d + j)*n + 1] = hist[idx + 1] >> 8;
			tmpret[(i*d + j)*n + 2] = hist[idx + 2] >> 8;
			tmpret[(i*d + j)*n + 3] = hist[idx + 3] >> 8;
#if (SIFT_DESCR_HIST_BINS_INT==8)
			tmpret[(i*d + j)*n + 4] = hist[idx + 4] >> 8;
			tmpret[(i*d + j)*n + 5] = hist[idx + 5] >> 8;
			tmpret[(i*d + j)*n + 6] = hist[idx + 6] >> 8;
			tmpret[(i*d + j)*n + 7] = hist[idx + 7] >> 8;
#endif
		}
	}
	int nrm2 = 0;

	len = d * d * n;
	for (k = 0; k < len; )/*len = 128,��ѭ������չ��*/
	{
		//nrm2 += /*squaredec_table[(int)(dst[k] + 512 + 0.5f)];*/ dst[k] * dst[k];
		nrm2 += tmpret[k] * tmpret[k]; k++;
		nrm2 += tmpret[k] * tmpret[k]; k++;
		nrm2 += tmpret[k] * tmpret[k]; k++;
		nrm2 += tmpret[k] * tmpret[k]; k++;
		nrm2 += tmpret[k] * tmpret[k]; k++;
		nrm2 += tmpret[k] * tmpret[k]; k++;
		nrm2 += tmpret[k] * tmpret[k]; k++;
		nrm2 += tmpret[k] * tmpret[k]; k++;
	}
	int thr = SqrtNiudun(nrm2)*SIFT_DESCR_MAG_THR_INT;

	for (i = 0, nrm2 = 0; i < k; i++)
	{
		int val = min(tmpret[i], thr);
		tmpret[i] = val;
		nrm2 += val * val;
	}

	nrm2 = max(SqrtNiudun(nrm2), 1);

	for (k = 0; k < len; k++)
	{
		tmpret[k] = tmpret[k] * SIFT_INT_DESCR_FCTR_INT / nrm2;
		tmpret[k] = max(tmpret[k], 0);
		dst[k] = (unsigned char)min(tmpret[k], 255)/ NORMALIZE_MAX;
	}

	free(buf);
}

int Adjust_Angle(unsigned char* img, int w, int h, int ptx, int pty, int ori)
{
	int n = SIFT_ORI_HIST_BINS;
	float hist[SIFT_ORI_HIST_BINS];
	int radius = 10;
	float candidate_angle[SIFT_ORI_HIST_BINS];
	int candidate_num = 0;

	int i,j,k,len = (radius * 2 + 1)*(radius * 2 + 1);

	float sigma = 2.4f * 1.5f;
	float expf_scale = -1.f / (2.f * sigma * sigma);
	float *buf = (float*)malloc((len * 4 + n + 4)*sizeof(float));
	float *X = buf, *Y = X + len, *Mag = X, *Ori = Y + len, *W = Ori + len;
	float* temphist = W + len + 2;

	for (i = 0; i < n; i++)
		temphist[i] = 0.f;

	for (i = -radius, k = 0; i <= radius; i++)
	{
		int y = pty + i;
		if (y <= 0 || y >= h - 1) continue;
		for (j = -radius; j <= radius; j++)
		{
			int x = ptx + j;
			if (x <= 0 || x >= w - 1) continue;

			float dx = (float)(img[y * w + x + 1] - img[y * w + x - 1]);
			float dy = (float)(img[(y - 1) * w + x] - img[(y + 1) * w + x]);

			X[k] = dx; Y[k] = dy; W[k] = (i*i + j * j)*expf_scale;
			k++;
		}
	}

	len = k;
	for (int i = 0; i < len; i++)
	{
		W[i] = expf(W[i]);
	}
	for (int i = 0; i < len; i++)
	{
		Ori[i] = atan2f(Y[i], X[i]) * 180.f / 3.1415926f;
		if (Ori[i] < 0) Ori[i] += 360.f;
	}
	for (int i = 0; i < len; i++)
	{
		float x0 = X[i], y0 = Y[i];
		Mag[i] = sqrtf(x0 * x0 + y0 * y0);
	}

	for (k = 0; k < len; k++)
	{
		int bin = (int)((n / 360.f)*Ori[k] + 0.5f);
		if (bin >= n)
			bin -= n;
		if (bin < 0)
			bin += n;
		temphist[bin] += W[k] * Mag[k];
	}

	// smooth the histogram
	temphist[-1] = temphist[n - 1];
	temphist[-2] = temphist[n - 2];
	temphist[n] = temphist[0];
	temphist[n + 1] = temphist[1];
	for (i = 0; i < n; i++)
	{
		hist[i] = (temphist[i - 2] + temphist[i + 2])*(1.f / 16.f) +
			(temphist[i - 1] + temphist[i + 1])*(4.f / 16.f) +
			temphist[i] * (6.f / 16.f);
	}

	float maxval = hist[0];
	for (i = 1; i < n; i++)
		maxval = max(maxval, hist[i]);

	free(buf);

	float mag_thr = (float)(maxval * 0.8f);

	for (int j = 0; j < n; j++)
	{
		int l = j > 0 ? j - 1 : n - 1;
		int r2 = j < n - 1 ? j + 1 : 0;

		if (hist[j] > hist[l] && hist[j] > hist[r2] && hist[j] >= mag_thr)
		{
			float bin = j + 0.5f * (hist[l] - hist[r2]) / (hist[l] - 2 * hist[j] + hist[r2]);
			bin = bin < 0 ? n + bin : bin >= n ? bin - n : bin;
			float angle = 360.f - (float)((360.f / n) * bin);
			candidate_angle[candidate_num*2] = angle;
			candidate_num++;
		}
	}

	for (int i = 0; i < candidate_num; i++)
	{
		candidate_angle[i * 2 + 1] = candidate_angle[i * 2] + 90;
		candidate_angle[i * 2] -= 90;

		if (candidate_angle[i * 2] < 0) candidate_angle[i * 2] += 360;
		else if (candidate_angle[i * 2] >= 360) candidate_angle[i * 2] -= 360;

		if (candidate_angle[i * 2 + 1] < 0) candidate_angle[i * 2 + 1] += 360;
		else if (candidate_angle[i * 2 + 1] >= 360) candidate_angle[i * 2 + 1] -= 360;
	}
	int mindiff = 361;
	int retAngle = 0;
	for (int i = 0; i < candidate_num*2; i++)
	{
		int diff = abs((int)(candidate_angle[i] - ori));
		diff = min(diff, 360 - diff);

		if (diff < mindiff)
		{
			mindiff = diff;
			retAngle = (int)candidate_angle[i];
		}
	}
	return retAngle;
}

