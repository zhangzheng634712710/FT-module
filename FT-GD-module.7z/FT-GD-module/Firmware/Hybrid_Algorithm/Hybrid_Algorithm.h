#pragma once

#if USE_FLOAT_DOUBLE
int main_ii();
#else
int FingerPrintEnroll(unsigned char *ImageData, unsigned short ImageHeight, unsigned short ImageWidth, unsigned short ftid);

int FingerPrintMatch(unsigned char *ImageData, unsigned short ImageHeight, unsigned short ImageWidth, unsigned short ftid);
#endif

