#pragma once

typedef struct binaryMap
{
	int width;
	int height;
	int wordWidth;
	int LineSift;
	unsigned char *bindata;
}binaryMap;

binaryMap binaryMap_Construct(int width, int height);

void binaryMap_Destruct(binaryMap *me);

int binaryMap_GetBit(const binaryMap *me, int x, int y);

void binaryMap_SetBit(const binaryMap *me, int x, int y, int val);

void binaryMap_CopyData(binaryMap *src, binaryMap *dst);
