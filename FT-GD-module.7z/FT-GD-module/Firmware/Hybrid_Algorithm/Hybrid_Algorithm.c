#include "public.h"
#include <stdio.h>
#include <stdlib.h>
#include "Hybrid.h"
#include "Hybrid_Algorithm.h"
#include "type_def.h"
#include "table_int.h"
#include "math.h"

//#define MAXPATH 								255
//#define MAXIMAGESIZE 							192*192

//int Load_gray256tif(FILE* fp, BOOL Upright);
//int Load_gray256bmp(FILE* fp, BOOL Upright);
//int Load_Image(char *imagefile, BOOL Upright);
//int matchmcc(FEATURE *feature1, FEATURE *feature2);




#if USE_FLOAT_DOUBLE
int main_ii()
#else
int FingerPrintEnroll(unsigned char *ImageData, unsigned short ImageHeight, unsigned short ImageWidth, unsigned short ftid)
#endif
{
	FEATURE feature11;
	FEATURE feature12;
	unsigned char *desc11[NUM_IN_ONE_GROUP];
	unsigned char *desc12[NUM_IN_ONE_GROUP];

	Hybrid_enroll_fp_int(ImageData, ImageHeight, ImageWidth,&feature11, &feature12, desc11, desc12);

  // 存储得到的描述值

	free(desc11[0]);
	free(desc12[0]);

	return 0;
}

#if USE_FLOAT_DOUBLE
int main_ii()
#else
int FingerPrintMatch(unsigned char *ImageData, unsigned short ImageHeight, unsigned short ImageWidth, unsigned short ftid)
#endif
{
	unsigned short i;
	
	FEATURE feature11;
	FEATURE feature12;
	unsigned char *desc11[NUM_IN_ONE_GROUP];
	unsigned char *desc12[NUM_IN_ONE_GROUP];
	
	FEATURE feature21;
	FEATURE feature22;
	unsigned char *desc21[NUM_IN_ONE_GROUP];
	unsigned char *desc22[NUM_IN_ONE_GROUP];

	memset(ImageData,0,192*192);
	detect_and_capture_image(ImageData,192*192);
	for(i=0;i<192*192;i++)
		*(ImageData+i) = 255 - *(ImageData+i);
	
	#if PC_IMAGE_DEBUG
		custom_hid_report_recive(&usb_device_dev);
		custom_hid_report_send(&usb_device_dev, ImageData, 192*192);
		custom_hid_report_recive(&usb_device_dev);
	#endif	

	#if WHOLE_TIME_COUNTER
		time = 0;
	#endif	
	
	Hybrid_enroll_fp_int(ImageData, ImageHeight, ImageWidth,&feature11, &feature12, desc11, desc12);
	
	#if WHOLE_TIME_COUNTER
		process_time.first_get_feature = time;	
	#endif	

	//等待指令启动第二次扫描
	#if PC_IMAGE_DEBUG
		custom_hid_report_recive(&usb_device_dev);
	#endif	

  memset(ImageData,0,192*192);
	detect_and_capture_image(ImageData,192*192);
	for(i=0;i<192*192;i++)
		*(ImageData+i) = 255 - *(ImageData+i);	

	#if WHOLE_TIME_COUNTER
		time = 0;
	#endif

	Hybrid_enroll_fp_int(ImageData, ImageHeight, ImageWidth, &feature21, &feature22, desc21, desc22);

	#if WHOLE_TIME_COUNTER
		process_time.second_get_feature = time;	
	#endif

	#if WHOLE_TIME_COUNTER
		time = 0;
	#endif
	
	volatile int matchret2 = Hybrid_match_desc_int_V2(&feature11, &feature12, desc11, desc12, &feature21, &feature22, desc21, desc22);
	
	#if WHOLE_TIME_COUNTER
		process_time.match = time;	
	#endif	
				
	free(desc21[0]);
	free(desc22[0]);
	free(desc11[0]);
	free(desc12[0]); 
				
	return 0;
}

///* ----------------------- */
///*    Auxiliary routines
///* ----------------------- */

//BYTE buffer[512];

//DWORD in_dword(DWORD i)
//{
//	DWORD v = 0;

//	v = v | (buffer[i]);
//	v = v | (buffer[i + 1] << 8);
//	v = v | (buffer[i + 2] << 16);
//	v = v | (buffer[i + 3] << 24);
//	return v;
//}

//WORD in_word(DWORD i)
//{
//	WORD v = 0;

//	v = v | (buffer[i]);
//	v = v | (buffer[i + 1] << 8);
//	return v;
//}

//// Load a 256 gray-scale uncompressed TIF image into the global array IMAGE
//int Load_gray256tif(FILE* fp, BOOL Upright)
//{
//	DWORD ifd_offset;
//	WORD directory_entry_count;
//	WORD offset;
//	DWORD strip_offset, data_offset;
//	BOOL strip_based = FALSE;
//	BYTE* pimage;
//	int i;

//	if (fread(buffer, 8, 1, fp) != 1) return 1;
//	if (in_word(0) != 0x4949) return 2;
//	if (in_word(2) != 0x002a) return 3;
//	ifd_offset = in_dword(4);
//	if (fseek(fp, ifd_offset, SEEK_SET)) return 1;
//	if (fread(buffer, 2, 1, fp) != 1) return 1;
//	directory_entry_count = in_word(0);
//	if (fread(buffer, directory_entry_count * 12, 1, fp) != 1) return 1;
//	offset = 0;
//	while (directory_entry_count >0)
//	{
//		switch (in_word(offset))
//		{
//		case 0x00fe: if (in_word(offset + 8) != 0) return 4; break;
//		case 0x0100: IMAGE_X = in_word(offset + 8); break;
//		case 0x0101: IMAGE_Y = in_word(offset + 8); break;
//		case 0x0102: if (in_word(offset + 8) != 8) return 5; break;
//		case 0x0103: if (in_word(offset + 8) != 1) return 6; break;
//		case 0x0106: if (in_word(offset + 8) != 1) return 7; break;
//		case 0x0111: strip_offset = in_word(offset + 8); break;
//		case 0x0115: if (in_word(offset + 8) != 1) return 8; break;
//		case 0x0116: if (in_word(offset + 8) != IMAGE_Y) strip_based = TRUE; break;
//		case 0x011c: if (in_word(offset + 8) != 1) return 11; break;
//		}
//		offset += 12;
//		directory_entry_count -= 1;
//	}

//	if (strip_based)
//	{
//		if (fseek(fp, strip_offset, SEEK_SET)) return 1;
//		if (fread(buffer, 4, 1, fp) != 1) return 1;
//		data_offset = in_dword(0);
//	}
//	else data_offset = strip_offset;
//	if (fseek(fp, data_offset, SEEK_SET)) return 1;

//	if (Upright)
//	{
//		pimage = IMAGE;
//		for (i = 0; i<IMAGE_Y; i++)
//		{
//			if (fread(pimage, IMAGE_X, 1, fp) != 1) return 1;
//			pimage += IMAGE_X;
//		}
//	}
//	else
//	{
//		pimage = IMAGE + IMAGE_X * (IMAGE_Y - 1);
//		for (i = 0; i<IMAGE_Y; i++)
//		{
//			if (fread(pimage, IMAGE_X, 1, fp) != 1) return 1;
//			pimage -= IMAGE_X;
//		}
//	}
//	return 0;
//}
////----------------------------------------------------------------------------------

//int Load_gray256bmp(FILE* fp, BOOL Upright)
//{
//	BITMAPFILEHEADER bfh;
//	BITMAPINFOHEADER bih;
//	int pad_row,
//		i;
//	BYTE tmp[4];
//	BYTE* pimage;


//	if (fread(&bfh, sizeof(BITMAPFILEHEADER), 1, fp) != 1)	return 4;

//	if (memcmp(&(bfh.bfType), "BM", 2) != 0) return 4; // non ?una bmp

//	if (fread(&bih, sizeof(BITMAPINFOHEADER), 1, fp) != 1)	return 4;

//	if (bih.biCompression != BI_RGB || bih.biBitCount != 8 || bih.biPlanes != 1) return 4;	// Formato non valido

//																							//Parameters initialization
//	IMAGE_X = bih.biWidth;
//	IMAGE_Y = bih.biHeight;
//	pad_row = (4 - (IMAGE_X % 4)) % 4;

//	fseek(fp, bfh.bfOffBits, SEEK_SET);

//	if (Upright)
//	{
//		pimage = IMAGE + IMAGE_X * (IMAGE_Y - 1);
//		for (i = 0; i<IMAGE_Y; i++)
//		{
//			if (fread(pimage, IMAGE_X, 1, fp) != 1) return 4;

//			if (pad_row>0)
//			{
//				if (fread(tmp, pad_row, 1, fp) != 1) return 4;
//			}

//			pimage -= IMAGE_X;
//		}
//	}
//	else
//	{
//		pimage = IMAGE;
//		for (i = 0; i<IMAGE_Y; i++)
//		{
//			if (fread(pimage, IMAGE_X, 1, fp) != 1) return 4;

//			if (pad_row>0)
//			{
//				if (fread(tmp, pad_row, 1, fp) != 1) return 4;
//			}

//			pimage += IMAGE_X;
//		}
//	}

//	return 0;
//}
////----------------------------------------------------------------------------------
//int Load_Image(char *imagefile, BOOL Upright)
//{
//	FILE *fp;
//	int err;


//	fp = fopen(imagefile, "rb");

//	if (fp == NULL) return 3;

//	if (_strnicmp(&imagefile[strlen(imagefile) - 3], "bmp", 3) == 0)
//	{
//		err = Load_gray256bmp(fp, Upright);
//	}
//	else
//		if (_strnicmp(&imagefile[strlen(imagefile) - 3], "tif", 3) == 0)
//		{
//			err = Load_gray256tif(fp, Upright);
//		}
//		else
//		{
//			err = 3;
//		}

//	fclose(fp);
//	return err;
//}

//#if 0
//int matchmcc(FEATURE *feature1, FEATURE *feature2)
//{
//	/*begin MCC*/
//	int flag = 0;
//	int Ns = 16; //MCC ����������
//	int	Nd = 5;  //MCC �߶�
//	int	MCLen = Ns * Ns*Nd; //MCC ����
//	int	MBLen = Ns * Ns*Nd / 8; //������MCC����

//	double *Cm1, *Cm2, *smlMtrx;
//	unsigned char *MccMap1, *MccMap2;
//	double similarity = 0.0;

//	Cm1 = (double*)malloc(MCLen*feature1->MinutiaNum * sizeof(double));
//	Cm2 = (double*)malloc(MCLen*feature2->MinutiaNum * sizeof(double));

//	MccMap1 = (unsigned char*)malloc(feature1->MinutiaNum * sizeof(unsigned char));
//	MccMap2 = (unsigned char*)malloc(feature2->MinutiaNum * sizeof(unsigned char));

//	int NumMCC1 = 0, NumMCC2 = 0;

//	//myMCC(double *Cm, void *Feature, int* NumMCC, unsigned char* map);
//	myMCC(Cm1, feature1, &NumMCC1, MccMap1);
//	myMCC(Cm2, feature2, &NumMCC2, MccMap2);

//	smlMtrx = (double*)malloc(NumMCC1*NumMCC2 * sizeof(double));

//	if (flag == 0)
//		MccMatch(feature1, Cm1, NumMCC1, MccMap1, feature2, Cm2, NumMCC2, MccMap2, smlMtrx, &similarity, 0x00);
//	else if (flag == 1)
//		MccMatch(feature1, Cm1, NumMCC1, MccMap1, feature2, Cm2, NumMCC2, MccMap2, smlMtrx, &similarity, 0x02);

//	int match_score = (int)(similarity * 100);
//	free(Cm1);
//	free(Cm2);
//	free(MccMap1);
//	free(MccMap2);
//	free(smlMtrx);
//	/*end MCC*/
//	return match_score;
//}
//#endif



////#define HEAP_ALLOC(var,size) \
////    lzo_align_t __LZO_MMODEL var [ ((size) + (sizeof(lzo_align_t) - 1)) / sizeof(lzo_align_t) ]
////static HEAP_ALLOC(wrkmem, LZO1X_1_MEM_COMPRESS);


////ţ�ٵ�����ƽ����
//static int SqrtNiudun(unsigned int intx)
//{
//	int pre = 1;
//	int tempz = 1;
//	unsigned char flag = 0;
//	while (abs(tempz - pre) > 1 || flag == 0)
//	{
//		flag = 1;
//		pre = tempz;
//		tempz = (pre + intx / pre) >> 1;
//	}
//	return tempz;
//}

////static int Get_sqrt_root_from_table(int dx, int dy)
////{
////	if (abs(dx) <= 128 && abs(dy) <= 128)
////		return square_root_table_uc[dx + 128][dy + 128];
////	else
////	{
////		return (square_root_table_uc[(dx >> 1) + 128][(dy >> 1) + 128] << 1);
////	}
////}

//static int fast_sqrt_root(int dx, int dy)
//{
//	unsigned int M = (dx * dx + dy * dy)<<6;

//	unsigned int N, i;
//	unsigned int tmp, ttp;   // �����ѭ������ 
//	if (M == 0)               // �����������������ҲΪ0 
//		return 0;
//	M++;
//	N = 0;
//	tmp = (M >> 30);          // ��ȡ���λ��B[m-1] 
//	M <<= 2;
//	if (tmp > 1)              // ���λΪ1 
//	{
//		N++;                 // �����ǰλΪ1������ΪĬ�ϵ�0 
//		tmp -= N;
//	}
//	for (i = 15; i>0; i--)      // ��ʣ���15λ 
//	{
//		N <<= 1;              // ����һλ

//		tmp <<= 2;
//		tmp += (M >> 30);     // ����

//		ttp = N;
//		ttp = (ttp << 1) + 1;

//		M <<= 2;
//		if (tmp >= ttp)       // ������� 
//		{
//			tmp -= ttp;
//			N++;
//		}
//	}

//	return N;
//}

//static int u32_sqrt(int dx, int dy)
//{
//	int val = dx * dx + dy * dy;
//	if (val == 0) return 0;
//	val++;
//	int r = 0;
//	for (int shift = 0; shift<32; shift += 2)
//	{
//		int x = 0x40000000l >> shift;

//		if (x + r <= val)
//		{
//			val -= x + r;
//			r = (r >> 1) | x;
//		}
//		else
//		{
//			r = r >> 1;
//		}
//	}

//	return r;
//};


