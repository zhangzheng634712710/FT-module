#pragma once
/*
 * Light Matrix: C code implementation for basic matrix operation
 *
 * Copyright (C) 2017 Jiachi Zou
 *
 * This code is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 *
 * This code is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with code.  If not, see <http:#www.gnu.org/licenses/>.
 */

#ifndef __LIGHT_MATRIX__
#define __LIGHT_MATRIX__

typedef struct  {
	int row, col;
	float **element;
}Matrix;

Matrix* MatCreate(Matrix* mat, int row, int col);
void MatDelete(Matrix* mat);
Matrix* MatSetVal(Matrix* mat, float* val);
void MatDump(const Matrix* mat);

Matrix* MatZeros(Matrix* mat);
Matrix* MatEye(Matrix* mat);

Matrix* MatAdd(Matrix* src1, Matrix* src2, Matrix* dst);
Matrix* MatSub(Matrix* src1, Matrix* src2, Matrix* dst);
Matrix* MatMul(Matrix* src1, Matrix* src2, Matrix* dst);
Matrix* MatTrans(Matrix* src, Matrix* dst);
float MatDet(Matrix* mat);
Matrix* MatAdj(Matrix* src, Matrix* dst);
Matrix* MatInv(Matrix* src, Matrix* dst);

void MatCopy(Matrix* src, Matrix* dst);

#endif

