#pragma once
#include "binaryMap.h"


int Hybrid_FindMinutiae_bin(unsigned char *bin_img, unsigned char *direction_map, int width, int height, void *feature, int if_recaldir);

void Hybrid_FindMinutiae(unsigned char *thin_img, binaryMap *Mask, int width, int height, void *feature);

int Hybrid_thinning(unsigned char *imageData, int IMGW, int IMGH);
