#pragma once

typedef struct rotgrids {
	int pad;
	int relative2;
	int start_angle;
	int ngrids;
	int grid_w;
	int grid_h;
	int **grids;
} ROTGRIDS;

void Hybrid_binarize(unsigned char *idata, int width, int height, unsigned char *direction_map, unsigned char *bdata);

int init_rotgrids(ROTGRIDS **optr, const int iw, const int ih, const int ipad,const int start_dir_angle, 
	const int ndirs,const int grid_w, const int grid_h, const int relative2);

void free_rotgrids(ROTGRIDS *rotgrids);

int binarize_cal(unsigned char **odata, int *ow, int *oh,unsigned char *pdata, const int pw, const int ph,
	unsigned char *direction_map, const int mw, const int mh,const ROTGRIDS *dirbingrids);

int binarize_image_cal(unsigned char **odata, int *ow, int *oh,unsigned char *pdata, const int pw, const int ph,
	unsigned char *direction_map, const int mw, const int mh, const ROTGRIDS *dirbingrids);

int dir_binarize(const unsigned char *pptr, const int idir, const ROTGRIDS *dirbingrids, int pw, int ph);

void fill_holes_bin(unsigned char *bdata, const int iw, const int ih);

void bits_8to6(unsigned char *idata, const int iw, const int ih);

