#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "table.h"
#include "cv_sift.h"
#include "public.h"

//static inline void unpackOctave(const KeyPoint* kpt, int* octave, int* layer, float* scale)
//{
//	*octave = kpt->octave & 255;
//	*layer = (kpt->octave >> 8) & 255;
//	*octave = (*octave < 128) ? (*octave) : (-128|(*octave));
//	*scale = (*octave >= 0) ? 1.f /(1<< (*octave )) : (float)(1 << -(*octave));
//}

static void calcSIFTDescriptor(SIFT_DET* self,unsigned char* img, int w, int h, float ptxf, float ptyf, float ori, float scl, int d, int n, float* dst);


/*����keypoint��ȡsift������*/
int SIFT_DescriptorExtractor(SIFT_DET* self, unsigned char* image, unsigned char* mask, int w, int h, KeyPoint* keypoints, int keypoint_num, float* desc)
{
	//int firstOctave = -1, actualNOctaves = 0, actualNLayers = 0;
	if (NULL == image || NULL == desc /*|| NULL == mask */) return -1;

	//firstOctave = 0;
	//int maxOctave = -1;
	//for (int i = 0; i < keypoint_num; i++)
	//{
	//	int octave, layer;
	//	float scale;
	//	unpackOctave(&keypoints[i], &octave, &layer, &scale);
	//	firstOctave = min(firstOctave, octave);
	//	maxOctave = max(maxOctave, octave);
	//	actualNLayers = max(actualNLayers, layer - 2);
	//}
	//firstOctave = min(firstOctave, 0);
	//if (firstOctave < -1 || firstOctave > self->nOctaveLayers) return -2;
	//actualNOctaves = maxOctave - firstOctave + 1;

	int dsize = descriptorSize;

	//desc = (float*)malloc(keypoint_num*dsize*sizeof(float));

	int d = SIFT_DESCR_WIDTH, n = SIFT_DESCR_HIST_BINS;

	for (int i = 0; i < keypoint_num; i++)
	{
		KeyPoint kpt = keypoints[i];
		//int octave, layer;
		//float scale;
		//unpackOctave(&kpt, &octave, &layer, &scale);
		//if (octave < firstOctave || layer > self->nOctaveLayers + 2) continue;
		float size = kpt.size /** scale*/;
		float ptxf = kpt.x /** scale*/;
		float ptyf = kpt.y /** scale*/;
		float angle = 360.f - kpt.angle;
		if (fabs(angle - 360.f) < FLT_EPSILON) angle = 0.f;;
		calcSIFTDescriptor(self, image, w, h, ptxf, ptyf, angle, size*0.5f, d, n, (desc+i* dsize));
	}
	return 0;
}

void calcSIFTDescriptor(SIFT_DET* self,unsigned char* img, int w, int h, float ptxf, float ptyf, float ori, float scl, int d, int n, float* dst)
{
	int ptx = (int)(ptxf + 0.5f);
	int pty = (int)(ptyf + 0.5f);

	float cos_t = cosf_table[(int)(ori)]; //cosf(ori * PI / 180.f);/*���*/
	float sin_t = sinf_table[(int)(ori)]; //sinf(ori * PI / 180.f);/*���*/
	float bins_per_rad = n / 360.f;
	float exp_scale = -1.f / (d * d * 0.5f);
	float hist_width = SIFT_DESCR_SCL_FCTR * scl;
	int radius = (int)(hist_width * 1.4142135623730951f * (d + 1) * 0.5f + 0.5f);
	radius = min(radius, (int)sqrt(w*w + h * h));
	cos_t /= hist_width;
	sin_t /= hist_width;

	int i, j, k, len = (radius * 2 + 1)*(radius * 2 + 1), histlen = (d + 2) * (d + 2) * (n + 2);
	int rows = h, cols = w;

	float *buf = (float*)malloc((len * 6 + histlen) * sizeof(float));
	float *X = buf, *Y = X + len, *Mag = Y, *Ori = Mag + len, *W = Ori + len;
	float *RBin = W + len, *CBin = RBin + len, *hist = CBin + len;

	//for (i = 0; i < d + 2; i++)
	//{
	//	for (j = 0; j < d + 2; j++)
	//		for (k = 0; k < n + 2; k++)
	//			hist[(i*(d + 2) + j)*(n + 2) + k] = 0.;
	//}
	memset(hist, 0, (d + 2) * (d + 2) * (n + 2) * sizeof(float));

	for (i = -radius, k = 0; i <= radius; i++)
	{
		for (j = -radius; j <= radius; j++)
		{
			// Calculate sample's histogram array coords rotated relative to ori.
			// Subtract 0.5 so samples that fall e.g. in the center of row 1 (i.e.
			// r_rot = 1.5) have full weight placed in row 1 after interpolation.
			float c_rot = j * cos_t - i * sin_t;
			float r_rot = j * sin_t + i * cos_t;
			float rbin = r_rot + (d >> 1) - 0.5f;
			float cbin = c_rot + (d >> 1) - 0.5f;
			int r = pty + i, c = ptx + j;

			if (rbin > -1 && rbin < d && cbin > -1 && cbin < d &&
				r > 0 && r < rows - 1 && c > 0 && c < cols - 1)
			{
				float dx = (float)(img[r * cols + c + 1] - img[r * cols + c - 1]);
				float dy = (float)(img[(r - 1) * cols + c] - img[(r + 1) * cols + c]);
				X[k] = dx; Y[k] = dy; RBin[k] = rbin; CBin[k] = cbin;

				W[k] = W_table[i+64][j+64]; /*(c_rot * c_rot + r_rot * r_rot)*exp_scale;*//*���*/
				Ori[k] = atanf_table_angel[(int)(0.5f*dy + 128.0f + 0.5f)][(int)(0.5f*dx + 128.0f + 0.5f)];/*���*/
				Mag[k] = square_root_table[(int)(dx + 128.0f + 0.5f)][(int)(dy + 128.0f + 0.5f)];/*���*/
				k++;
			}
		}
	}

	len = k;
	//��ǰ�������
	//fastAtan2(Y, X, Ori, len, true);
	//for (int i = 0; i < len; i++)
	//{
		//Ori[i] = atanf_table_angel[(int)(0.5f*Y[i] + 128.0f + 0.5f)][(int)(0.5f*X[i] + 128.0f + 0.5f)];// atan2f(Y[i], X[i]) * 180.f / PI;/*���*/
		//printf("\n%d,%.3f", i, Ori[i]);
		//if (Ori[i] < 0) Ori[i] += 360.f;
	//}
	//magnitude(X, Y, Mag, len);
	//for (int i = 0; i < len; i++)
	//{
	//	float x0 = X[i], y0 = Y[i];
	//	Mag[i] = square_root_table[(int)(x0 + 128.0f + 0.5f)][(int)(y0 + 128.0f + 0.5f)];// sqrtf(x0 * x0 + y0 * y0);/*���*/
	//}
	//exp(W, W, len); 
	//for (int i = 0; i < len; i++)
	//{
	//	W[i] = expf(W[i]);
	//}

	for (k = 0; k < len; k++)
	{
		float rbin = RBin[k], cbin = CBin[k];
		float obin = (Ori[k] - ori)*bins_per_rad;
		float mag = Mag[k] * W[k];

		int r0 = (int)floor(rbin);
		int c0 = (int)floor(cbin);
		int o0 = (int)floor(obin);
		rbin -= r0;
		cbin -= c0;
		obin -= o0;

		if (o0 < 0)
			o0 += n;
		else if (o0 >= n)
			o0 -= n;

		// histogram update using tri-linear interpolation
		float v_r1 = mag * rbin, v_r0 = mag - v_r1;
		float v_rc11 = v_r1 * cbin, v_rc10 = v_r1 - v_rc11;
		float v_rc01 = v_r0 * cbin, v_rc00 = v_r0 - v_rc01;
		float v_rco111 = v_rc11 * obin, v_rco110 = v_rc11 - v_rco111;
		float v_rco101 = v_rc10 * obin, v_rco100 = v_rc10 - v_rco101;
		float v_rco011 = v_rc01 * obin, v_rco010 = v_rc01 - v_rco011;
		float v_rco001 = v_rc00 * obin, v_rco000 = v_rc00 - v_rco001;

		int idx = ((r0 + 1)*(d + 2) + c0 + 1)*(n + 2) + o0;
		hist[idx] += v_rco000;
		hist[idx + 1] += v_rco001;
		hist[idx + (n + 2)] += v_rco010;
		hist[idx + (n + 3)] += v_rco011;
		hist[idx + (d + 2)*(n + 2)] += v_rco100;
		hist[idx + (d + 2)*(n + 2) + 1] += v_rco101;
		hist[idx + (d + 3)*(n + 2)] += v_rco110;
		hist[idx + (d + 3)*(n + 2) + 1] += v_rco111;
	}

	// finalize histogram, since the orientation histograms are circular
	float tmpret[descriptorSize] = { 0.0f };
	for (i = 0; i < d; i++)
	{
		for (j = 0; j < d; j++)
		{
			int idx = ((i + 1)*(d + 2) + (j + 1))*(n + 2);
			hist[idx] += hist[idx + n];
			hist[idx + 1] += hist[idx + n + 1];
			//for (k = 0; k < n; k++) /*n = 8, k = 0~7,��ѭ��չ��*/
			//	dst[(i*d + j)*n + k] = hist[idx + k];
			tmpret[(i*d + j)*n + 0] =dst[(i*d + j)*n + 0] = hist[idx + 0];
			tmpret[(i*d + j)*n + 1] = dst[(i*d + j)*n + 1] = hist[idx + 1];
			tmpret[(i*d + j)*n + 2] = dst[(i*d + j)*n + 2] = hist[idx + 2];
			tmpret[(i*d + j)*n + 3] = dst[(i*d + j)*n + 3] = hist[idx + 3];
			tmpret[(i*d + j)*n + 4] = dst[(i*d + j)*n + 4] = hist[idx + 4];
			tmpret[(i*d + j)*n + 5] = dst[(i*d + j)*n + 5] = hist[idx + 5];
			tmpret[(i*d + j)*n + 6] = dst[(i*d + j)*n + 6] = hist[idx + 6];
			tmpret[(i*d + j)*n + 7] = dst[(i*d + j)*n + 7] = hist[idx + 7];
		}
	}
	float nrm2 = 0;
	len = d * d * n; 
	for (k = 0; k < len; )/*len = 128,��ѭ������չ��*/
	{
		//nrm2 += /*squaredec_table[(int)(dst[k] + 512 + 0.5f)];*/ dst[k] * dst[k];
		nrm2 += dst[k] * dst[k]; k++;
		nrm2 += dst[k] * dst[k]; k++;
		nrm2 += dst[k] * dst[k]; k++;
		nrm2 += dst[k] * dst[k]; k++;
		nrm2 += dst[k] * dst[k]; k++;
		nrm2 += dst[k] * dst[k]; k++;
		nrm2 += dst[k] * dst[k]; k++;
		nrm2 += dst[k] * dst[k]; k++;
	}
	float thr = sqrtf(nrm2)*SIFT_DESCR_MAG_THR;

	for (i = 0, nrm2 = 0; i < k; i++)
	{
		float val = min(dst[i], thr);
		dst[i] = val;
		nrm2 += val * val;
	}
	nrm2 = SIFT_INT_DESCR_FCTR / max(sqrtf(nrm2), FLT_EPSILON);

	for (k = 0; k < len; k++)
	{
		dst[k] = dst[k] * nrm2;
		dst[k] = max(dst[k], 0);
		dst[k] = min(dst[k], 255);
	}

	free(buf);
}


