#pragma once
//#define MATRIX_SCAL     4096 /*С����Ϊ���εķŴ���*/
//#define MATRIX_SCAL_BIT 12   /*�Ŵ�����Ӧ��λ��λ��*/

typedef struct {
	int row, col;
	int **element;
}Matrix_int;

Matrix_int* MatCreate_int(Matrix_int* mat, int row, int col);

Matrix_int* MatSetVal_int(Matrix_int* mat, int* val);

void MatDelete_int(Matrix_int* mat);

void MatDump_int(const Matrix_int* mat);

int MatDet_int(Matrix_int* mat);

Matrix_int* MatAdj_int(Matrix_int* src, Matrix_int* dst);

Matrix_int* MatInv_int(Matrix_int* src, Matrix_int* dst, int *odet);

Matrix_int* MatMul_int(Matrix_int* src1, Matrix_int* src2, Matrix_int* dst);

void MatCopy_int(Matrix_int* src, Matrix_int* dst);
