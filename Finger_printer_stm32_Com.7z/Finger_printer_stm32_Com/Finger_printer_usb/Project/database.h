#ifndef DATABASE_H
#define DATABASE_H

#include <stdint.h>
#include "flash.h"
#include <stdbool.h>

#define align_front(addr,mask)  (((addr)+(mask)-1)&(~(mask-1)))

#define DB_base_addr		    FLASH_database_start_addr
//#define DB_header_addr			database_base_addr
//#define DB_header_len			(sizeof(DB_header_typedef))
//#define DB_ft_header_addr		DB_header_addr+DB_header_len
#define DB_ft_max_number		150
//#define DB_one_ft_header_len	(sizeof(DB_ft_header_typedef))
//#define DB_ft_header_len        (DB_ft_max_number*DB_one_ft_header_len)
//#define DB_storage_map_addr		(DB_ft_header_addr+DB_ft_header_len)
//#define DB_storage_map_len		(sizeof(DB_storage_block_typedef)*DB_ft_max_number)
//#define DB_ft_data_addr			(DB_storage_map_addr+DB_storage_map_len)

#define FT_DATABASE_LEN         (sizeof(FT_DATABASE_typedef))
#define DB_ft_block_size		4096
#define FT_data_addr            align_front(DB_base_addr+FT_DATABASE_LEN,DB_ft_block_size)            
#define DATABASE_FLAG			0x55AA55AA

typedef enum
{
    FT_INFO_EMPTY = 0,
    FT_INFO_USING,
    FT_INFO_USED,
}FT_INFO_FLAG_typedef; 

typedef enum 
{
    BLOCK_EMPTY = 0,
    BLOCK_USING,
    BLOCK_USED
}DB_block_map_info_typedef; 

typedef struct DB_info_s
{
	uint32_t                DB_flag;
	uint16_t                DB_ft_number;
	struct DB_ft_info_s     *DB_first_ft_info;
    uint16_t                DB_now_ft_number;
	uint32_t                reserved1;
	uint32_t                reserved2;
}DB_info_typedef;

typedef struct DB_ft_info_s
{
    FT_INFO_FLAG_typedef    ft_info_flag;
	uint16_t                FT_id;
	uint8_t                 *FT_data;	
	uint16_t                FT_data_len;	
	struct DB_ft_info_s     *DB_prev_ft_info;
	struct DB_ft_info_s     *DB_next_ft_info;
	uint16_t                DB_ft_block_num;	
	uint32_t                DB_ft_info_param2;	
}DB_ft_info_typedef;

typedef struct 
{
    DB_info_typedef                 DB_info;
    DB_ft_info_typedef              DB_ft_info[DB_ft_max_number];
    DB_block_map_info_typedef       DB_block_map_info[DB_ft_max_number];
}FT_DATABASE_typedef;

bool database_reinit(void);
bool database_init(void);
bool database_insert(uint16_t ft_id,uint8_t *ft_data,uint16_t data_len);
bool is_ft_id_in_database(uint16_t id);
bool delete_ft_id_in_database(uint16_t id);

#endif

