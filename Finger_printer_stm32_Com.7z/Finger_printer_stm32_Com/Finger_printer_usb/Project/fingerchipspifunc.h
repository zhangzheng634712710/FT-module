#include "stm32f4xx.h"
/* Include my libraries here */
#include "stm32f4xx_gpio.h"
#include "stm32f4xx_spi.h"
#include "stm32f4xx_usart.h"

#define cs_h GPIO_SetBits(GPIOA,GPIO_Pin_4)
#define cs_l GPIO_ResetBits(GPIOA,GPIO_Pin_4)

void fingerchipspifunc_spi_init(void);
void fingerchipspifunc_uart_init(void);
void fingerchip_send_command(uint8_t command);
void fingerchip_send_data(uint8_t *dataarry,uint16_t data_number);
void fingerchip_read_column(uint8_t *dataarry,uint8_t data_number);

