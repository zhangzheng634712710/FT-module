#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include "command.h"
#include "fpc_interface.h"
#include "database.h"

static void prepare_cmd_response(uint16_t rcm);
static void prepare_data_response(uint16_t rcm);
static void deal_test_connection(void);
static void deal_set_param(void);
static void deal_get_param(void);
static void deal_get_device_info(void);
static void deal_enter_iap_mode(void);
static void deal_get_image(void);
static void deal_finger_detect(void);
static void deal_up_image(void);
static void deal_down_image(void);
static void deal_sled_ctl(void);
static void deal_store_char(void);
static void deal_load_char(void);
static void deal_up_char(void);
static void deal_down_char(void);
static void deal_delet_char(void);
static void deal_get_empty_id(void);
static void deal_get_status(void);
static void deal_get_broken_id(void);
static void deal_get_enroll_count(void);
static void deal_generate(void);
static void deal_merge(void);
static void deal_match(void);
static void deal_search(void);
static void deal_verify(void);
static void deal_set_module_sn(void);
static void deal_get_module_sn(void);
static void deal_fp_cancle(void);
static void deal_get_enrolled_id_list(void);
static void deal_enter_standy_state(void);
static void receive_down_image(void);

const char module_info[] = "DGSAE_GD_FPC1020(DB_ft_max_numberfp) V1.0";

uint8_t package_buffer[PACKAGE_BUFFER_LEN]={0};

MODULE_PARAM module_param =
{
    3,
    0,
    5,
    0,
    5,
    0,
    0,
    IMAGE_BUFFER_OFF,
    0,
    NULL,
    NULL,
};



void deal_recieved_package(void)
{
	uint16_t package_flag=*((uint16_t *)package_buffer);
	package_flag=UINT16_ORDER(package_flag);	
	if(package_flag==PACKAGE_CMD)
	{
        deal_command_package();
	}
	else if(package_flag==PACKAGE_RESPONSE)
	{
        deal_command_data_package();
	}
	else
	{}
}

void deal_command_package(void)
{
	uint16_t cmd=((command_package_def *)package_buffer)->cmd;
    cmd = UINT16_ORDER(cmd);
	switch(cmd)
	{
		case CMD_TEST_CONNECTION:
            deal_test_connection();
			break;
		case CMD_SET_PARAM:
            deal_set_param();
			break;
		case CMD_GET_PARAM:
            deal_get_param();
			break;
		case CMD_GET_DEVICE_INFO:
            deal_get_device_info();
			break;
		case CMD_ENTER_IAP_MODE:
            deal_enter_iap_mode();
			break;
		case CMD_GET_IMAGE:
            deal_get_image();
			break;
		case CMD_FINGER_DETECT:
            deal_finger_detect();
			break;
		case CMD_UP_IMAGE:
            deal_up_image();
			break;
		case CMD_DOWN_IMAGE:
            deal_down_image();
			break;
		case CMD_SLED_CTL:
            deal_sled_ctl();
			break;
		case CMD_STORE_CHAR:
            deal_store_char();
			break;
		case CMD_LOAD_CHAR:
            deal_load_char();
			break;
		case CMD_UP_CHAR:
            deal_up_char();
			break;
		case CMD_DOWM_CHAR:
            deal_down_char();
			break;
		case CMD_DELET_CHAR:
            deal_delet_char();
			break;
		case CMD_GET_EMPTY_ID:
            deal_get_empty_id();
			break;
		case CMD_GET_STATUS:
            deal_get_status();
			break;
		case CMD_GET_BROKEN_ID:
            deal_get_broken_id();
			break;
		case CMD_GET_ENROLL_COUNT:
            deal_get_enroll_count();
			break;
		case CMD_GENERATE:
            deal_generate();
			break;
		case CMD_MERGE:
            deal_merge();
			break;
		case CMD_MATCH:
            deal_match();
			break;
		case CMD_SEARCH:
            deal_search();
			break;
		case CMD_VERIFY:
            deal_verify();
			break;
		case CMD_SET_MODULE_SN:
            deal_set_module_sn();
			break;
		case CMD_GET_MODULE_SN:
            deal_get_module_sn();
			break;
		case CMD_FP_CANCLE:
            deal_fp_cancle();
			break;
		case CMD_GET_ENROLLED_ID_LIST:
            deal_get_enrolled_id_list();
			break;
		case CMD_ENTER_STANDY_STATE:
            deal_enter_standy_state();
			break;
		default:
			break;
    }
}

static void prepare_cmd_response(uint16_t rcm)
{
    memset(package_buffer,0,PACKAGE_BUFFER_LEN);
    ((response_package_def *)package_buffer)->prefix = UINT16_ORDER(PACKAGE_RESPONSE);
    ((response_package_def *)package_buffer)->sid    = DID;
    ((response_package_def *)package_buffer)->did    = 0x00;
    ((response_package_def *)package_buffer)->rcm    = UINT16_ORDER(rcm);
}    

static void prepare_data_response(uint16_t rcm)
{
    memset(package_buffer,0,PACKAGE_BUFFER_LEN);
    ((response_package_def *)package_buffer)->prefix = UINT16_ORDER(PACKAGE_RESPONSE_DATA);
    ((response_package_def *)package_buffer)->sid    = DID;
    ((response_package_def *)package_buffer)->did    = 0x00;
    ((response_package_def *)package_buffer)->rcm    = UINT16_ORDER(rcm);
}    


static void deal_test_connection(void)
{
    prepare_cmd_response(CMD_TEST_CONNECTION);
    ((response_package_def *)package_buffer)->len    = UINT16_ORDER(0x0002);
    ((response_package_def *)package_buffer)->ret    = UINT16_ORDER(ERR_SUCCESS);
    send_response_package(PACKAGE_RESPONSE_LEN);
}

static void deal_set_param(void)
{
	uint16_t  len=((command_package_def *)package_buffer)->len;
    uint8_t *data = ((command_package_def *)package_buffer)->data;
    uint32_t param = *((uint32_t *)(data+1));
    param = UINT32_ORDER(param);
    len = UINT16_ORDER(len);
    prepare_cmd_response(CMD_SET_PARAM);
    ((response_package_def *)package_buffer)->len    = UINT16_ORDER(0x0002);
    switch(*data)
    {
        case SECURITY_LEVEL:
            if(change_security_level(param))
                ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
            else
                ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_FAILURE);
            break;
        case DUPLICATION_CHECK:
            if(change_duplication_check(param))
                ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
            else
                ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_FAILURE);
            break;
        case BAUDRATE:
            if(change_baudrate(param))
                ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
            else
                ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_FAILURE);
           break;
        case AUTO_LEARN:
            if(change_auto_learn(param))
                ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
            else
                ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_FAILURE);
           break;
        case FT_TIMEOUT:
            if(change_ft_timeout(param))
                ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
            else
                ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_FAILURE);
           break;
        default:
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_INVALID_PARAM);
            break;
    }
    send_response_package(PACKAGE_RESPONSE_LEN);
}

static void deal_get_param(void)
{
    uint8_t *data = ((command_package_def *)package_buffer)->data;
    prepare_cmd_response(CMD_GET_PARAM);
    switch(*data)
    {
        case SECURITY_LEVEL:
            ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0006);
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
            *((uint32_t *)(((response_package_def *)package_buffer)->data)) = UINT32_ORDER(module_param.security_level);
            break;
        case DUPLICATION_CHECK:
            ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0006);
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
            *((uint32_t *)(((response_package_def *)package_buffer)->data)) = UINT32_ORDER(module_param.duplication_check);
            break;
        case BAUDRATE:
            ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0006);
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
            *((uint32_t *)(((response_package_def *)package_buffer)->data)) = UINT32_ORDER(module_param.baudrate);
            break;
        case AUTO_LEARN:
            ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0006);
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
            *((uint32_t *)(((response_package_def *)package_buffer)->data)) = UINT32_ORDER(module_param.auto_learn);
            break;
        case FT_TIMEOUT:
            ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0006);
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
            *((uint32_t *)(((response_package_def *)package_buffer)->data)) = UINT32_ORDER(module_param.ft_timeout);
            break;
        default:
            ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_INVALID_PARAM);
            break;
    }
    send_response_package(PACKAGE_RESPONSE_LEN);
}

static void deal_get_device_info(void)
{
    prepare_cmd_response(CMD_GET_DEVICE_INFO);
    ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0004);
    ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
    *((uint16_t *)(((response_package_def *)package_buffer)->data)) = UINT16_ORDER(sizeof(module_info));
    send_response_package(PACKAGE_RESPONSE_LEN);
    prepare_data_response(CMD_GET_DEVICE_INFO);
    ((response_package_def *)package_buffer)->len = UINT16_ORDER((2+sizeof(module_info)));
    ((response_package_def *)package_buffer)->ret = UINT16_ORDER(ERR_SUCCESS);
    memcpy(((response_package_def *)package_buffer)->data,module_info,sizeof(module_info));
    send_response_package((sizeof(module_info))+10);
}

static void deal_enter_iap_mode(void)
{
    prepare_cmd_response(CMD_ENTER_IAP_MODE);
    ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
    ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_FAILURE);
    send_response_package(PACKAGE_RESPONSE_LEN);
}

static void deal_get_image(void)
{
    if(module_param.image_buffer_flag == IMAGE_BUFFER_OFF)
        module_param.image_buffer_pointer = malloc(SENSOR_COLUMN*SENSOR_ROW);
    prepare_cmd_response(CMD_GET_IMAGE);
    ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
    if(!module_param.image_buffer_pointer)
    {
        module_param.image_buffer_flag = IMAGE_BUFFER_OFF;
        ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_FAILURE);
    }
    else
    {
        if(FPC_SENSOR_OK == DETECT_AND_READ_ONE_IMAGE(module_param.image_buffer_pointer))
        {
            module_param.image_buffer_flag = IMAGE_BUFFER_ON;
            module_param.image_buffer_offset = 0;
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
        }
        else
        {
            free(module_param.image_buffer_pointer);
            module_param.image_buffer_flag = IMAGE_BUFFER_OFF;
            module_param.image_buffer_offset = 0;
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_FAILURE);
        }
    }
    send_response_package(PACKAGE_RESPONSE_LEN);
}

static void deal_finger_detect(void)
{
    prepare_cmd_response(CMD_FINGER_DETECT);
    if(FPC_SENSOR_DETECTED == WHETHER_FINGER_IS_ON_CHIP())
    {
        ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0003);
        ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
        ((response_package_def *)package_buffer)->data[0] = 0x01;
    }
    else if(FPC_SENSOR_NOT_DETECTED == WHETHER_FINGER_IS_ON_CHIP())
    {
        ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0003);
        ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
        ((response_package_def *)package_buffer)->data[0] = 0x00;
    }
    else
    {
        ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
        ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_FAILURE);
    }
    send_response_package(PACKAGE_RESPONSE_LEN);
}

static void deal_up_image(void)
{
    uint16_t *temp = (uint16_t *)(((response_package_def *)package_buffer)->data);
    prepare_cmd_response(CMD_UP_IMAGE);
    if(module_param.image_buffer_flag==IMAGE_BUFFER_OFF)
    {
        ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
        ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_FAILURE);
        send_response_package(PACKAGE_RESPONSE_LEN);
    }
    else if(module_param.image_buffer_flag==IMAGE_BUFFER_ON)
    {

        ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0006);
        ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
        (*temp)=UINT16_ORDER(SENSOR_COLUMN);
        (*(temp+1))=UINT16_ORDER(SENSOR_ROW);
        send_response_package(PACKAGE_RESPONSE_LEN);

        {
            uint16_t full_package_number=(SENSOR_COLUMN*SENSOR_ROW)/PACKAGE_IMAGE_DATA_LEN;
            uint16_t last_package_data_number=(SENSOR_COLUMN*SENSOR_ROW)%PACKAGE_IMAGE_DATA_LEN;
            uint8_t  *temp_package_buffer =(((response_package_def *)package_buffer)->data)+2;
            uint8_t i=0;
            module_param.image_buffer_offset =0;
            prepare_data_response(CMD_UP_IMAGE);
            ((response_package_def *)package_buffer)->len = UINT16_ORDER((PACKAGE_IMAGE_DATA_LEN+4));
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
            (*temp)=UINT16_ORDER(PACKAGE_IMAGE_DATA_LEN);
            for(i=0;i<full_package_number;i++)
            {
                memcpy(temp_package_buffer,(module_param.image_buffer_pointer+module_param.image_buffer_offset),PACKAGE_IMAGE_DATA_LEN);
                module_param.image_buffer_offset += PACKAGE_IMAGE_DATA_LEN;
                send_response_package(PACKAGE_IMAGE_DATA_LEN+10);
            }
            ((response_package_def *)package_buffer)->len = UINT16_ORDER((last_package_data_number+4));
            (*temp)=UINT16_ORDER(last_package_data_number);
            memcpy(temp_package_buffer,(module_param.image_buffer_pointer+module_param.image_buffer_offset),last_package_data_number);
            send_response_package(PACKAGE_IMAGE_DATA_LEN+10);
            module_param.image_buffer_offset =0;
        }
    }
}

static void deal_down_image(void)
{
    uint16_t column,row;
    uint16_t *data;
    data = (uint16_t *)(((response_package_def *)package_buffer)->data);
    column = UINT16_ORDER(*data);
    row = UINT16_ORDER(*(data+1));
    prepare_cmd_response(CMD_DOWN_IMAGE);
    ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
    if((column==SENSOR_COLUMN)&&(row==SENSOR_ROW))
    {
        if(module_param.image_buffer_flag == IMAGE_BUFFER_ON)
        {
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
            module_param.image_buffer_offset = 0;
        }
        else
        {
            module_param.image_buffer_pointer = malloc(SENSOR_COLUMN*SENSOR_ROW);
            if(!module_param.image_buffer_pointer)
                ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_FAILURE);
            else
            {
                module_param.image_buffer_flag = IMAGE_BUFFER_ON;
                module_param.image_buffer_offset = 0;
                ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
            }
        }
    }
    else
    {
        ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_INVALID_PARAM);
    }        
    send_response_package(PACKAGE_RESPONSE_LEN);
}

static void deal_sled_ctl(void)
{
    prepare_cmd_response(CMD_SLED_CTL);
    ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
    ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
    send_response_package(PACKAGE_RESPONSE_LEN);
}

static void deal_store_char(void)
{

}

static void deal_load_char(void)
{

}

static void deal_up_char(void)
{

}

static void deal_down_char(void)
{

}

static void deal_delet_char(void)
{
    uint16_t start_id = *((uint16_t *)(((command_package_def *)package_buffer)->data));
    uint16_t stop_id = *(((uint16_t *)(((command_package_def *)package_buffer)->data))+1);
    uint16_t i,delete_number = 0;
    prepare_cmd_response(CMD_DELET_CHAR);
    ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
    if(((FT_DATABASE_typedef *)(DB_base_addr))->DB_info.DB_ft_number==0)
        ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_TMPL_EMPTY);
    else
    {
        if((start_id>0)&&(stop_id<10000)&&(start_id<=stop_id))
        {
            for(i=start_id;i<stop_id+1;i++)
            {
                if(is_ft_id_in_database(i))
                {
                    delete_ft_id_in_database(i);
                    delete_number++;
                }
            }
            if(delete_number == 0)
                ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_TMPL_EMPTY);
            else
                ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
        }
        else
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_INVALID_PARAM);
    }
    send_response_package(PACKAGE_RESPONSE_LEN);
}

static void deal_get_empty_id(void)
{
    uint16_t start_id = *((uint16_t *)(((command_package_def *)package_buffer)->data));
    uint16_t stop_id = *(((uint16_t *)(((command_package_def *)package_buffer)->data))+1);
    uint16_t i=0;
    prepare_cmd_response(CMD_GET_EMPTY_ID);
    if((start_id>0)&&(stop_id<10000)&&(start_id<=stop_id))
    {
        for(i=start_id;i<stop_id+1;i++)
        {
            if(!(is_ft_id_in_database(i)))
            {
                break;
            }
        }
        if(i == stop_id+1)
        {
            ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_EMPTY_ID_NOEXIST);
        }
        else
        {
            ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0004);
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
            *(((uint16_t *)(((response_package_def *)package_buffer)->data))) = UINT16_ORDER(i);
        }
    }
    else
    {
        ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
        ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_INVALID_PARAM);
    }
    send_response_package(PACKAGE_RESPONSE_LEN);

}

static void deal_get_status(void)
{
    uint16_t id = *((uint16_t *)(((command_package_def *)package_buffer)->data));
    prepare_cmd_response(CMD_GET_STATUS);
    if(id>=10000)
    {
        ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
        ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_INVALID_TMPL_NO);
    }
    else
    {
        ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0004);
        ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
        if(is_ft_id_in_database(id))
        {
            ((response_package_def *)package_buffer)->data[0] = 1;
        }
        else
        {
            ((response_package_def *)package_buffer)->data[0] = 0;
        }
    }
    send_response_package(PACKAGE_RESPONSE_LEN);
}

static void deal_get_broken_id(void)
{

}

static void deal_get_enroll_count(void)
{
    uint16_t start_id = *((uint16_t *)(((command_package_def *)package_buffer)->data));
    uint16_t stop_id = *(((uint16_t *)(((command_package_def *)package_buffer)->data))+1);
    uint16_t i,enrolled_number = 0;
    prepare_cmd_response(CMD_GET_ENROLL_COUNT);
    if(((FT_DATABASE_typedef *)(DB_base_addr))->DB_info.DB_ft_number==0)
    {
        ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
        ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_INVALID_PARAM);
    }
    else
    {
        if((start_id>0)&&(stop_id<10000)&&(start_id<=stop_id))
        {
            for(i=start_id;i<stop_id+1;i++)
            {
                if(is_ft_id_in_database(i))
                {
                    enrolled_number++;
                }
            }
            ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0004);
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
            *((uint16_t *)(((command_package_def *)package_buffer)->data)) = UINT16_ORDER(enrolled_number);
        }
        else
        {
            ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
            ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_INVALID_PARAM);
        }
    }
    send_response_package(PACKAGE_RESPONSE_LEN);
}

static void deal_generate(void)
{

}

static void deal_merge(void)
{

}

static void deal_match(void)
{

}

static void deal_search(void)
{

}

static void deal_verify(void)
{

}

static void deal_set_module_sn(void)
{

}

static void deal_get_module_sn(void)
{

}

static void deal_fp_cancle(void)
{

}

static void deal_get_enrolled_id_list(void)
{

}

static void deal_enter_standy_state(void)
{
    prepare_cmd_response(CMD_ENTER_STANDY_STATE);
    ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
    ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
    send_response_package(PACKAGE_RESPONSE_LEN);
}

void incorrect_command(void)
{
    prepare_cmd_response(0x00ff);
    ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
    ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
    send_response_package(PACKAGE_RESPONSE_LEN);
}

void deal_command_data_package(void)
{
	uint16_t cmd=((command_package_def *)package_buffer)->cmd;
    cmd = UINT16_ORDER(cmd);
	switch(cmd)
	{
		case CMD_ENTER_IAP_MODE:
			break;
		case CMD_DOWN_IMAGE:
            receive_down_image();
			break;
		case CMD_STORE_CHAR:
			break;
		case CMD_LOAD_CHAR:
			break;
		case CMD_UP_CHAR:
			break;
		case CMD_DOWM_CHAR:
			break;
		case CMD_DELET_CHAR:
			break;
		case CMD_GET_EMPTY_ID:
			break;
		case CMD_GET_STATUS:
			break;
		case CMD_GET_BROKEN_ID:
			break;
		case CMD_GET_ENROLL_COUNT:
			break;
		case CMD_GENERATE:
			break;
		case CMD_MERGE:
			break;
		case CMD_MATCH:
			break;
		case CMD_SEARCH:
			break;
		case CMD_VERIFY:
			break;
		case CMD_SET_MODULE_SN:
			break;
		case CMD_GET_MODULE_SN:
			break;
		case CMD_FP_CANCLE:
			break;
		case CMD_GET_ENROLLED_ID_LIST:
			break;
		case CMD_ENTER_STANDY_STATE:
			break;
		default:
			break;
    }
}

static void receive_down_image(void)
{
    uint16_t i = 0;
    uint16_t len = ((command_package_def *)package_buffer)->len;
    uint8_t *temp = (((command_package_def *)package_buffer)->data)+2;
    len = UINT16_ORDER(len);
    for(i=0;i<len-2;i++)
    {
        *(module_param.image_buffer_pointer+module_param.image_buffer_offset++) = *(temp+i);
    }
    prepare_data_response(CMD_DOWN_IMAGE);
    ((response_package_def *)package_buffer)->len = UINT16_ORDER(0x0002);
    if(module_param.image_buffer_offset <= (SENSOR_COLUMN*SENSOR_ROW))
        ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_SUCCESS);
    else
        ((response_package_def *)package_buffer)->ret = UINT16_ORDER(RESULT_FAILURE);
    send_response_package(12);
}



    
