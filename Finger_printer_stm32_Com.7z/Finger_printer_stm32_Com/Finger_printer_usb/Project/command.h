#ifndef COMMAND_H
#define COMMAND_H

#include <stdint.h> 

//package flag defines
#define PACKAGE_CMD			        ((uint16_t)0xAA55)
#define PACKAGE_RESPONSE		    ((uint16_t)0x55AA)
#define PACKAGE_CMD_DATA		    ((uint16_t)0xA55A)
#define PACKAGE_RESPONSE_DATA		((uint16_t)0x5AA5)

//package lenth define
#define PACKAGE_CMD_LEN             sizeof(command_package_def)
#define PACKAGE_RESPONSE_LEN        sizeof(response_package_def)

//command lists defines
#define CMD_TEST_CONNECTION		    ((uint16_t)0x0001)
#define CMD_SET_PARAM	    		((uint16_t)0x0002)
#define CMD_GET_PARAM	    		((uint16_t)0x0003)
#define CMD_GET_DEVICE_INFO 		((uint16_t)0x0004)
#define CMD_ENTER_IAP_MODE  		((uint16_t)0x0005)
#define CMD_GET_IMAGE	    		((uint16_t)0x0020)
#define CMD_FINGER_DETECT   		((uint16_t)0x0021)
#define CMD_UP_IMAGE	    		((uint16_t)0x0022)
#define CMD_DOWN_IMAGE	    		((uint16_t)0x0023)
#define CMD_SLED_CTL	    		((uint16_t)0x0024)
#define CMD_STORE_CHAR	    		((uint16_t)0x0040)
#define CMD_LOAD_CHAR	    		((uint16_t)0x0041)
#define CMD_UP_CHAR		        	((uint16_t)0x0042)
#define CMD_DOWM_CHAR		    	((uint16_t)0x0043)
#define CMD_DELET_CHAR		    	((uint16_t)0x0044)
#define CMD_GET_EMPTY_ID	    	((uint16_t)0x0045)
#define CMD_GET_STATUS		    	((uint16_t)0x0046)
#define CMD_GET_BROKEN_ID	    	((uint16_t)0x0047)
#define CMD_GET_ENROLL_COUNT		((uint16_t)0x0048)
#define CMD_GENERATE		        ((uint16_t)0x0060)
#define CMD_MERGE       			((uint16_t)0x0061)
#define CMD_MATCH	        		((uint16_t)0x0062)
#define CMD_SEARCH		        	((uint16_t)0x0063)
#define CMD_VERIFY		        	((uint16_t)0x0064)
#define CMD_SET_MODULE_SN	    	((uint16_t)0x0008)
#define CMD_GET_MODULE_SN	    	((uint16_t)0x0009)
#define CMD_FP_CANCLE	    		((uint16_t)0x0025)
#define CMD_GET_ENROLLED_ID_LIST	((uint16_t)0x0049)
#define CMD_ENTER_STANDY_STATE		((uint16_t)0x000c)

//response code define)
#define ERR_SUCCESS                 ((uint16_t)0x0000)
#define ERR_FAILURE                 ((uint16_t)0x0001)
#define ERR_INVALID_PARAM           ((uint32_t)0x0002)

//package buffer lenth define
#define PACKAGE_BUFFER_LEN          ((uint16_t)512)

//image package lenth define
#define PACKAGE_IMAGE_DATA_LEN      ((uint16_t)496)

//HOSE ID(SID) and DEVICE(DID) define
#define SID                         ((uint8_t)0x00)
#define DID                         ((uint8_t)0x01)

//RESULT CODE define
#define RESULT_SUCCESS              ((uint16_t)0x0000)
#define RESULT_FAILURE              ((uint16_t)0x0001)
#define RESULT_VERIFY               ((uint16_t)0x0010)
#define RESULT_IDENTIFY             ((uint16_t)0x0011)
#define RESULT_TMPL_EMPTY           ((uint16_t)0x0012)
#define RESULT_TMPL_NOT_EMPTY       ((uint16_t)0x0013)
#define RESULT_ALL_TEMP_EMPTY       ((uint16_t)0x0014)
#define RESULT_EMPTY_ID_NOEXIST     ((uint16_t)0x0015)
#define RESULT_BROKEN_ID_NOEXIT     ((uint16_t)0x0016)
#define RESULT_INVALID_TMPL_DATA    ((uint16_t)0x0017)
#define RESULT_DUPLICATION_ID       ((uint16_t)0x0018)
#define RESULT_BAD_QUALITY          ((uint16_t)0x0019)
#define RESULT_MERGE_FAIL           ((uint16_t)0x001a)
#define RESULT_NOT_AUTHONRIZED      ((uint16_t)0x001b)
#define RESULT_MEMORY               ((uint16_t)0x001c)
#define RESULT_INVALID_TMPL_NO      ((uint16_t)0x001d)
#define RESULT_INVALID_PARAM        ((uint16_t)0x0022)
#define RESULT_GEN_COUNT            ((uint16_t)0x0025)
#define RESULT_TIMEOUT              ((uint16_t)0x0023)
#define RESULT_INVALID_BUFFER_ID    ((uint16_t)0x0026)
#define RESULT_FP_NOT_DETECTED      ((uint16_t)0x0028)
#define RESULT_FP_CANCLE            ((uint16_t)0x0041) 

#define SECURITY_LEVEL              ((uint8_t)0x01)
#define DUPLICATION_CHECK           ((uint8_t)0x02)
#define BAUDRATE                    ((uint8_t)0x03)
#define AUTO_LEARN                  ((uint8_t)0x04)
#define FT_TIMEOUT                  ((uint8_t)0x05)

//correct the data order
#define UINT16_ORDER(DATA)          (((DATA&0xff)<<8)|(DATA>>8))
#define UINT32_ORDER(DATA)          (((DATA&0xff000000)>>24)|((DATA&0xff0000)>>8)\
                                    |((DATA&0xff00)<<8)|(DATA<<24))

#define IMAGE_BUFFER_ON             ((uint8_t)0x01)
#define IMAGE_BUFFER_OFF            ((uint8_t)0x00)

typedef struct
{
	uint16_t prefix;
	uint8_t	 sid;
	uint8_t  did;
	uint16_t cmd;
	uint16_t len;
	uint8_t  data[16];
	uint16_t cks;
}__attribute__ ((packed)) command_package_def;


typedef struct
{
	uint16_t prefix;
	uint8_t	 sid;
	uint8_t  did;
	uint16_t rcm;
	uint16_t len;
	uint16_t ret;
	uint8_t  data[14];
	uint16_t cks;
}__attribute__ ((packed)) response_package_def;

typedef struct
{
    uint32_t security_level;
    uint32_t duplication_check;
    uint32_t baudrate;
    uint32_t auto_learn;
    uint32_t ft_timeout;
    uint32_t reserved1;
    uint32_t reserved2;
    uint8_t  image_buffer_flag;
    uint16_t image_buffer_offset;
    uint8_t *image_buffer_pointer;
    uint8_t *template_pointer;
}MODULE_PARAM;

extern uint8_t package_buffer[PACKAGE_BUFFER_LEN];
extern MODULE_PARAM module_param;

void deal_recieved_package(void);
void deal_command_package(void);
void deal_command_data_package(void);

#endif

