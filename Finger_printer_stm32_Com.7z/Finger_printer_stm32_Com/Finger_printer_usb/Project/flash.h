#ifndef _FLASH_H
#define _FLASH_H

#include <stdint.h>

#define FLASH_database_start_addr					0x08010000

typedef enum
{
	FLASH_ERROR = 0x00,
	FLASH_OK    = 0x01
}FLASH_STATE;

FLASH_STATE Flash_read(uint8_t *buffer,uint32_t flash_addr,uint32_t len);
FLASH_STATE Flash_write(uint8_t *buffer,uint32_t flash_addr,uint32_t len);

#endif
