/**
 *	Keil project for SPI
 *
 *	Before you start, select your target, on the right of the "Load" button
 *
 *	@author		Tilen Majerle
 *	@email		tilen@majerle.eu
 *	@website	http://stm32f4-discovery.com
 *	@ide		Keil uVision 5
 *	@packs		STM32F4xx Keil packs version 2.2.0 or greater required
 *	@stdperiph	STM32F4xx Standard peripheral drivers version 1.4.0 or greater required
 */
 
/* Include core modules */
#include "stm32f4xx.h"
#include "fingerchipspifunc.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "tm_stm32f4_usb_vcp.h"

extern uint32_t APP_Rx_ptr_in;    /* Increment this pointer or roll it back to
                                     start address when writing received data
                                     in the buffer APP_Rx_Buffer. */
extern uint32_t APP_Rx_ptr_out;    /* Increment this pointer or roll it back to
                                     start address when writing received data
                                     in the buffer APP_Rx_Buffer. */
uint8_t rimg(void);

int sendonechar(int ch)
{
	while(TM_USB_VCP_Putc(ch)!=TM_USB_VCP_OK);
	return ch;
}

int getonechar(void)
{
	uint8_t c;
	while(TM_USB_VCP_Getc(&c)!=TM_USB_VCP_DATA_OK);
	return (int)c;
}

void get_command(char *buffer,uint8_t maxlen)
{
	uint8_t c;
	char *point = buffer;
	while(1)
	{
		c = getonechar();		
		if(((c>='0')&&(c<='9'))||((c>='a')&&(c<='z'))||((c>='A')&&(c<='Z'))||(c==' ')||(c=='?'))     //backspace
		{
			sendonechar(c);
			*point++ = c;
			if(point>buffer+maxlen-1)
				break;
		}
		else if(c=='\b')
		{
			sendonechar('\b');
			sendonechar(' ');
			sendonechar('\b');
			if(point > buffer)
				point--;
		}
		else if(c=='\r')
		{
		  sendonechar('\n');
			sendonechar('\r');
			*point = c;
			break;
		}
		else
		{
		}
	}	
}

int main(void) 
{
	char received_chars[50];
	char *p=0;
	uint8_t command_number = 0;
	uint8_t send_data[20];
	uint8_t i;
	
//	TM_USB_VCP_Settings_t VCP_SETTING;	
	TM_USB_VCP_Init();	
//	TM_USB_VCP_GetSettings(&VCP_SETTING);
	fingerchipspifunc_spi_init();	

	while (1) 
	{
		if(TM_USB_VCP_GetStatus()==TM_USB_VCP_CONNECTED)
		{
//			printf("Communication start ...\n\r");
			scanf("%[^\r]",received_chars);  //�޷�delete character
//			get_command(received_chars,sizeof(received_chars));
			p=strtok(received_chars," ");
			if(!(strcasecmp(p,"send")))
			{
				p=strtok(strlen(p)+p+1," ");
				command_number=(int)(strtol(p,NULL,16));
				p=strtok(strlen(p)+p+1," ");
				for(i=0;i<command_number;i++)
				{
					send_data[i] = (int)(strtol(p,NULL,16));
					p=strtok(strlen(p)+p+1," ");
				}
				fingerchip_send_data(send_data,command_number);
				if(command_number==1)
					printf("reci %x %x\r\n",command_number,send_data[0]);
				else if(command_number==2)
					printf("reci %x %x %x\r\n",command_number,send_data[0],send_data[1]);
				else if(command_number==3)
					printf("reci %x %x %x %x\r\n",command_number,send_data[0],send_data[1],send_data[2]);
				else if(command_number==4)
					printf("reci %x %x %x %x %x\r\n",command_number,send_data[0],send_data[1],send_data[2],send_data[3]);
				else if(command_number==5)
					printf("reci %x %x %x %x %x %x\r\n",command_number,send_data[0],send_data[1],send_data[2],send_data[3],send_data[4]);
				else
					printf("Command error!\r\n");
				printf(" ");
			}
			else if(!(strncasecmp(p,"rimg",4)))
			{
				if(rimg())
					printf("\r\n");
				else
					printf("error\r\n");
			}	
			else if(!(strncasecmp(p,"Z2?",4)))
			{
				printf("Yes\r\n");
			}			
			else
			{
				printf("Command error!\r\n");
			}
			
		}
//		else
//		{
//			TM_USB_VCP_Init();
//		}
	}
}

uint8_t rimg(void)
{
	uint8_t *data_arry;
	data_arry = malloc(36866);
	if(!data_arry) return 0;
	memset(data_arry,0x00,sizeof(uint8_t)*(36866));
	*(data_arry) = 0xc0;
	fingerchip_send_data(data_arry,1);
	do
	{
		*(data_arry) = 0x18;*(data_arry+1) = 0x00;
		fingerchip_send_data(data_arry,2);
	}while(((*(data_arry+1))&0x20)!=0x20);
	*(data_arry) = 0x1c;*(data_arry+1) = 0x00;
	fingerchip_send_data(data_arry,2);
  *(data_arry) = 0xc4;*(data_arry+1) = 0x00;
	fingerchip_send_data(data_arry,36866);
	APP_Rx_ptr_out = 0;
	APP_Rx_ptr_in = 0;
	TM_USB_VCP_Send(data_arry,36866);
	free(data_arry);
	return 1;
}

